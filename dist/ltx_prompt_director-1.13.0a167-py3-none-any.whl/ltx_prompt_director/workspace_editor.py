"""Settings page for portable workspace definitions."""
from __future__ import annotations
from .file_dialogs import choose_document_open

import copy
import json
import re
from pathlib import Path
from uuid import uuid4

from PySide6.QtCore import Qt, QSize
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QFormLayout, QListWidget,
                              QLineEdit, QComboBox, QCheckBox, QTextEdit, QPushButton,
                              QMessageBox, QLabel, QSpinBox, QDoubleSpinBox, QStackedWidget, QSizePolicy)

from .workspaces import WorkspaceStore, KINDS, validate_definition
from .spellcheck import install_spellcheck
from .prompt_templates import stock_prompt


class WorkspaceSectionStack(QStackedWidget):
    def sizeHint(self):
        return QSize(600, 470)

    def minimumSizeHint(self):
        return QSize(320, 180)

    def hasHeightForWidth(self):
        return self.currentIndex() == 0 and super().hasHeightForWidth()

    def heightForWidth(self, width):
        return super().heightForWidth(width) if self.currentIndex() == 0 else -1


class WorkspaceEditor(QWidget):
    def __init__(self, store: WorkspaceStore, owner, parent=None):
        super().__init__(parent)
        self.store, self.owner = store, owner
        self.current_id = None
        outer = QVBoxLayout(self)
        note = QLabel("Workspace definitions control prompt layout, references, audio and AI instructions.")
        note.setWordWrap(True); outer.addWidget(note)
        body = QHBoxLayout()
        self.list = QListWidget()
        self.list.setMinimumWidth(170)
        self.list.setMaximumWidth(220)
        self.list.currentRowChanged.connect(self.select)
        body.addWidget(self.list)
        form = QFormLayout()
        self.identifier, self.name = QLineEdit(), QLineEdit()
        self.engine = QComboBox()
        self.engine.addItem("LTX", "ltx")
        self.engine.addItem("MiniMax Frames", "minimax_frames")
        self.engine.addItem("MiniMax References", "minimax_references")
        self.engine.addItem("Generic", "generic")
        self.engine.addItem("Generic Prompt Refine", "minimax_prompt")
        self.engine.addItem("Shot Sequence", "shot_sequence")
        self.mode = QComboBox()
        self.mode.addItem("One unified prompt", "unified")
        self.mode.addItem("Per-segment prompts", "segmented")
        self.mode.addItem("Prompt refinement · annotations only", "prompt_only")
        self.mode.addItem("Completed-shot sequence", "sequence")
        self.global_prompt, self.audio = QCheckBox("Include global prompt"), QCheckBox("Supports audio generation")
        self.references = QCheckBox("Allow reference media")
        self.kinds = QLineEdit()
        self.kinds.setToolTip("Comma-separated types: " + ", ".join(sorted(KINDS)))
        self.slots = QSpinBox()
        self.slots.setRange(0, 4)
        self.no_length_limit = QCheckBox("No limit")
        self.max_length = QDoubleSpinBox()
        self.max_length.setRange(0.01, 1000000)
        self.max_length.setDecimals(2)
        self.max_length.setSuffix(" s")
        self.max_length.setToolTip("Maximum duration of the entire timeline, including all segments.")
        self.no_length_limit.toggled.connect(lambda unlimited: self.max_length.setEnabled(not unlimited))
        length_control = QWidget()
        length_layout = QHBoxLayout(length_control)
        length_layout.setContentsMargins(0, 0, 0, 0)
        length_layout.addWidget(self.max_length)
        length_layout.addWidget(self.no_length_limit)
        form.addRow("Maximum sequence length", length_control)
        self.max_shots = QSpinBox()
        self.max_shots.setRange(0, 1000000)
        self.max_shots.setSpecialValueText("Unlimited")
        self.max_shots.setToolTip("Maximum timeline segments. Set 0 for unlimited. Existing projects keep all their segments.")
        form.addRow("Maximum shots", self.max_shots)
        self.variables = QLabel()
        self.variables.setWordWrap(True)
        form.addRow("Template fields", self.variables)
        self.generate, self.refine = QTextEdit(), QTextEdit()
        install_spellcheck(self.generate)
        install_spellcheck(self.refine)
        self.generate.setAcceptRichText(False)
        self.refine.setAcceptRichText(False)
        for title, control in (("ID", self.identifier), ("Name", self.name), ("Generation engine", self.engine),
                               ("Prompt layout", self.mode), ("", self.global_prompt), ("", self.audio),
                               ("", self.references), ("Reference kinds", self.kinds), ("Untimed media slots", self.slots),
                               ("Generation instructions", self.generate), ("Refinement instructions", self.refine)):
            form.addRow(title, control)
        self.sections = WorkspaceSectionStack()
        self.sections.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)
        self.list.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Ignored)
        configuration = QWidget(); configuration.setLayout(form)
        self.sections.addWidget(configuration)
        from .template_editor import TemplateEditor
        self.output_template = TemplateEditor(owner)
        self.output_template.save_requested.connect(self.save)
        self.sections.addWidget(self.output_template)
        body.addWidget(self.sections, 1)
        outer.addLayout(body, 1)
        buttons = QHBoxLayout()
        for title, action in (("New", self.new), ("Save / rename", self.save), ("Delete", self.delete),
                              ("Import…", self.import_definition), ("Export", self.export), ("Restore stock", self.restore)):
            button = QPushButton(title)
            button.clicked.connect(action)
            buttons.addWidget(button)
        outer.insertLayout(1,buttons)
        self.status = QLabel()
        self.status.setWordWrap(True)
        outer.addWidget(self.status)
        self.reload()
        self.engine.currentIndexChanged.connect(self.engine_changed)
        self.mode.currentIndexChanged.connect(self.update_template_mode)

    def update_template_mode(self):
        self.output_template.set_available(self.mode.currentData() == 'unified')

    def engine_changed(self):
        if self.engine.currentData() in {'minimax_frames', 'minimax_references'}:
            engine = self.engine.currentData()
            from .workspaces import upgrade_h3_instructions
            value = dict(engine=engine, generation_prompts={
                'generate': self.generate.toPlainText(), 'refine': self.refine.toPlainText()})
            upgrade_h3_instructions(value)
            for kind, editor in (('generate', self.generate), ('refine', self.refine)):
                if any(editor.toPlainText() == stock_prompt(other, kind)
                       for other in ('ltx', 'minimax_frames', 'minimax_references', 'generic')):
                    editor.setPlainText(stock_prompt(engine, kind))
                else:
                    editor.setPlainText(value['generation_prompts'][kind])
            self.mode.setCurrentIndex(self.mode.findData('unified'))
            from .output_templates import default_layout
            old_layout = self.output_template.editor.toPlainText()
            self.output_template.engine = engine
            if not old_layout.strip() or any(old_layout == default_layout(other)
                    for other in ('ltx', 'generic', 'minimax_frames', 'minimax_references')):
                self.output_template.set_value(default_layout(engine))
            return
        if self.engine.currentData() == "shot_sequence":
            self.mode.setCurrentIndex(self.mode.findData("sequence"))
            self.global_prompt.setChecked(False);self.audio.setChecked(False)
            self.references.setChecked(False);self.slots.setValue(0);self.kinds.setText("video")
            self.no_length_limit.setChecked(True)
            return
        if self.engine.currentData() == "minimax_prompt":
            for kind, editor in (("generate", self.generate), ("refine", self.refine)):
                if any(editor.toPlainText() == stock_prompt(engine, kind)
                       for engine in ("ltx", "minimax_frames", "minimax_references", "generic")):
                    editor.setPlainText(stock_prompt("minimax_prompt_refinement", kind))
            self.mode.setCurrentIndex(self.mode.findData("prompt_only"))
            self.global_prompt.setChecked(False)
            self.audio.setChecked(False)
            self.references.setChecked(False)
            self.slots.setValue(0)
            self.kinds.clear()
            self.variables.setText("${current_prompt}")
            return
        if self.engine.currentData() != "generic":
            return
        # Replace only untouched stock prompts; custom instructions remain authoritative.
        for kind, editor in (("generate", self.generate), ("refine", self.refine)):
            if any(editor.toPlainText() == stock_prompt(engine, kind) for engine in ("ltx", "minimax_frames", "minimax_references")):
                editor.setPlainText(stock_prompt("generic", kind))
        self.variables.setText("${director_intent}, ${global_direction}, ${asset_map}, ${ordered_plan}, ${total_duration}, ${current_prompt}, ${refinement_instructions}, ${sound_effects}, ${dialogue}, ${music}")

    def reload(self, selected=None):
        self.values = self.store.load()
        self.list.blockSignals(True)
        self.list.clear()
        for key, value in self.values.items():
            self.list.addItem(value["name"])
            self.list.item(self.list.count() - 1).setData(Qt.ItemDataRole.UserRole, key)
        row = next((i for i in range(self.list.count()) if self.list.item(i).data(Qt.ItemDataRole.UserRole) == selected), 0)
        self.list.setCurrentRow(row)
        self.list.blockSignals(False)
        self.select(row)
        self.status.setText("\n".join(self.store.errors))

    def select(self, row):
        if row < 0 or row >= self.list.count():
            self.current_id = None
            return
        self.current_id = self.list.item(row).data(Qt.ItemDataRole.UserRole)
        self.populate(self.values[self.current_id])

    def populate(self, value):
        from .output_templates import layout_for
        self.output_template.engine = value['engine']
        if value['prompt_mode'] == 'unified':
            self.output_template.set_value(layout_for(value))
        self.output_template.set_available(value['prompt_mode'] == 'unified')
        from .timing_limits import sequence_limit, shot_limit
        self.max_shots.setValue(shot_limit(value) or 0)
        maximum = sequence_limit(value)
        self.no_length_limit.setChecked(maximum is None)
        self.max_length.setEnabled(maximum is not None)
        self.max_length.setValue(maximum if maximum is not None else 20)
        self.identifier.setText(value["id"])
        self.name.setText(value["name"])
        self.engine.blockSignals(True)
        self.engine.setCurrentIndex(self.engine.findData(value["engine"]))
        self.engine.blockSignals(False)
        self.mode.setCurrentIndex(self.mode.findData(value["prompt_mode"]))
        self.global_prompt.setChecked(value["global_prompt"])
        self.audio.setChecked(value["audio_generation"])
        self.references.setChecked(value["references"]["enabled"])
        self.kinds.setText(", ".join(value["references"]["kinds"]))
        self.slots.setValue(value["references"].get("untimed_slots", 0))
        fields = value.get("template_variables", {})
        names = sorted(set(fields.get("generate", []) + fields.get("refine", [])) | set(re.findall(r"\$\{(\w+)\}", value["generation_prompts"]["generate"] + value["generation_prompts"].get("refine", ""))))
        self.variables.setText(", ".join("${" + name + "}" for name in names) or "Plain instructions or supported ${field} substitutions")
        self.generate.setPlainText(value["generation_prompts"]["generate"])
        self.refine.setPlainText(value["generation_prompts"].get("refine", ""))

    def value(self):
        existing = self.values.get(self.current_id, {})
        return validate_definition(dict(**{key: value for key, value in existing.items() if key not in {"schema_version", "id", "name", "engine", "prompt_mode", "global_prompt", "audio_generation", "references", "generation_prompts", "max_sequence_duration", "max_shots", "output_template"}}, schema_version=1, id=self.identifier.text().strip(), name=self.name.text().strip(),
            output_template=self.output_template.value() if self.mode.currentData() == 'unified' else None,
            engine=self.engine.currentData(), prompt_mode=self.mode.currentData(), global_prompt=self.global_prompt.isChecked(),
            max_sequence_duration=None if self.no_length_limit.isChecked() else self.max_length.value(),
            max_shots=self.max_shots.value(),
            audio_generation=self.audio.isChecked(), references=dict(enabled=self.references.isChecked(),
            kinds=[kind.strip() for kind in self.kinds.text().split(",") if kind.strip()], untimed_slots=self.slots.value()),
            generation_prompts=dict(generate=self.generate.toPlainText(), refine=self.refine.toPlainText())))

    def new(self):
        value = copy.deepcopy(next(iter(self.values.values()))) if self.values else dict(schema_version=1, engine="ltx", prompt_mode="segmented", global_prompt=True, audio_generation=True, references=dict(enabled=True, kinds=["image", "video"], untimed_slots=0), generation_prompts=dict(generate="Describe the supplied timeline.", refine="Apply the requested changes."))
        value.update(id="workspace_" + uuid4().hex[:8], name="New workspace")
        self.current_id = None
        self.populate(value)
        self.name.setFocus()
        self.name.selectAll()

    def save(self):
        try:
            value = self.value()
            if self.current_id is None and value["id"] in self.values:
                raise ValueError("This ID already exists. Select it to edit or choose a new ID.")
            self.store.save(value, self.current_id)
            self.owner.reload_workspace_definitions(previous_id=self.current_id, new_id=value["id"])
            self.reload(value["id"])
            self.status.setText("Workspace saved.")
        except (ValueError, OSError) as error:
            QMessageBox.warning(self, "Workspace", str(error))

    def delete(self):
        if self.current_id:
            self.store.delete(self.current_id)
            self.owner.reload_workspace_definitions()
            self.reload()

    def restore(self):
        self.store.restore_stock()
        self.owner.reload_workspace_definitions()
        self.reload()
        self.status.setText("Stock workspaces restored. Other custom definitions were preserved.")

    def import_definition(self):
        path = choose_document_open(self, "Import workspace definition", "", "Workspace JSON (*.json)")
        if path:
            try:
                value = validate_definition(json.loads(Path(path).read_text(encoding="utf-8")))
                self.store.save(value)
                self.owner.reload_workspace_definitions()
                self.reload(value["id"])
            except (ValueError, OSError) as error:
                QMessageBox.warning(self, "Import workspace", str(error))

    def export(self):
        try:
            value = self.value()
            path = self.owner.next_export_path(value["name"] + ".workspace.json")
            path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            self.owner.record_export(path)
            self.status.setText(f"Exported {path.name}")
        except (ValueError, OSError) as error:
            QMessageBox.warning(self, "Export workspace", str(error))
