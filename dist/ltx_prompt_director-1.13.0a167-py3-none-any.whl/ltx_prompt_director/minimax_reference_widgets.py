"""Portable mixed reference-media drop targets for the MiniMax editor."""
from __future__ import annotations
from .file_dialogs import choose_document_open

import base64
import hashlib
from pathlib import Path

from PySide6.QtCore import QBuffer, QEvent, QIODevice, QMimeData, QStandardPaths, QUrl, Qt, Signal
from PySide6.QtGui import QAction, QDrag, QImage, QPixmap, QIcon
from PySide6.QtWidgets import QApplication, QCheckBox, QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton, QVBoxLayout, QSizePolicy

from .minimax_reference import REFERENCE_ROLES
from .reference_media import AUDIO_SUFFIXES, import_reference
from .media import TIMELINE_VIDEO_SUFFIXES


class MiniMaxReferenceSlot(QFrame):
    changed = Signal(object)
    error = Signal(str)
    export_requested = Signal()

    def __init__(self, number: int, owner=None):
        super().__init__()
        self.owner = owner
        self._import_serial = 0
        self.number = number
        self.value = None
        self.setAcceptDrops(True)
        self.setObjectName("referenceImageSlot")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setProperty("dropActive", False)
        self._drag_start = None
        layout = QVBoxLayout(self)
        layout.setContentsMargins(9, 6, 9, 6)
        row = QHBoxLayout()
        self.title = QLabel(f"REFERENCE {number} · untimed")
        self.title.setWordWrap(True); self.title.setMinimumWidth(0)
        self.title.setObjectName("sectionLabel")
        row.addWidget(self.title, 1)
        for text, callback in (("Browse", self.browse), ("Paste", self.paste)):
            button = QPushButton(text)
            button.setObjectName("copyButton")
            button.clicked.connect(callback)
            row.addWidget(button)
        self.export_action = QAction("Export Media", self)
        self.export_action.setEnabled(False)
        self.export_action.triggered.connect(lambda: self.export_requested.emit())
        self.clear_action = QAction("Clear", self)
        self.clear_action.setEnabled(False)
        self.clear_action.triggered.connect(self.clear)
        layout.addLayout(row)
        actions = QHBoxLayout()
        self.remove_button = QPushButton('Remove')
        self.remove_button.clicked.connect(self.clear); self.remove_button.setEnabled(False)
        actions.addWidget(self.remove_button)
        layout.addLayout(actions)
        body = QHBoxLayout()
        self.preview = QLabel()
        self._source_pixmap=QPixmap()
        self._empty_pixmap=QIcon(str(Path(__file__).parent/'assets/toolbar-open.svg')).pixmap(42,42)
        self.preview.setPixmap(self._empty_pixmap)
        self.preview.setAccessibleName('Reference media · drop image, video or audio')
        self.preview.setToolTip('Drop image, video or audio here, or use Browse or Paste.')
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setFixedSize(116, 72)
        self.preview.setObjectName("referenceImagePreview")
        self.preview.installEventFilter(self)
        self.preview.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.preview.customContextMenuRequested.connect(lambda point: self.show_image_menu(self.preview.mapToGlobal(point)))
        body.addWidget(self.preview)
        fields = QVBoxLayout()
        self.filename = QLabel("No image")
        self.filename.hide()
        self.filename.setTextFormat(Qt.TextFormat.PlainText)
        self.filename.setMaximumWidth(300)
        self.filename.setWordWrap(True); self.filename.setMinimumWidth(0)
        fields.addWidget(self.filename)
        self.role = QComboBox()
        self.role.setMinimumWidth(0); self.role.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        for key, label in REFERENCE_ROLES.items():
            self.role.addItem(label, key)
        self.role.setToolTip("What this reference image should control")
        self.role.currentIndexChanged.connect(self.metadata_changed)
        fields.addWidget(self.role)
        self.notes = QLineEdit()
        self.notes.setMinimumWidth(0)
        self.notes.setPlaceholderText("Optional: subject or reference instructions")
        self.notes.installEventFilter(self)
        fields.addWidget(self.notes)
        self.audio_only = QCheckBox("Use ref audio only")
        self.audio_only.setToolTip("Use only the uploaded video soundtrack; exclude its visual reference")
        self.audio_only.toggled.connect(self.metadata_changed)
        self.audio_only.hide()
        fields.addWidget(self.audio_only)
        body.addLayout(fields, 1)
        layout.addLayout(body)
        self.setToolTip("Reference appearance, setting or style. Reference media adds no timeline frame or duration.")

    def set_value(self, value: dict | None, label: str | None = None) -> None:
        self.title.setText(f"REFERENCE {self.number}" + (f" · {label}" if label else " · untimed"))
        if value == self.value:
            return
        self.value = dict(value) if value else None
        self.export_action.setEnabled(bool(value and (value.get("image") or value.get("path"))))
        self.clear_action.setEnabled(bool(value))
        self.remove_button.setEnabled(bool(value))
        self.preview.setCursor(Qt.CursorShape.OpenHandCursor if value else Qt.CursorShape.ArrowCursor)
        self.audio_only.blockSignals(True)
        self.audio_only.setVisible(bool(value and value.get("kind") == "video"))
        self.audio_only.setChecked(bool(value and value.get("audio_only")))
        self.audio_only.setEnabled(bool(value and value.get("audio_path")))
        self.audio_only.blockSignals(False)
        self.role.blockSignals(True)
        self.notes.blockSignals(True)
        self.role.setCurrentIndex(max(0, self.role.findData(value.get("role", "identity") if value else "identity")))
        self.notes.setText(value.get("notes", "") if value else "")
        self.role.blockSignals(False)
        self.notes.blockSignals(False)
        self.filename.setText(value["name"] if value else "No media")
        self.filename.setVisible(bool(value))
        self.filename.setToolTip(value["name"] if value else "")
        self.preview.clear()
        pixmap = QPixmap()
        if value:
            try:
                pixmap.loadFromData(base64.b64decode(value.get("image", "").split(",", 1)[1]))
            except (ValueError, IndexError, KeyError):
                pass
        if pixmap.isNull():
            if value:self.preview.setText("♫ Audio" if value.get("kind") == "audio" else "Preview unavailable")
            else:self.preview.setPixmap(self._empty_pixmap)
        else:
            self.preview.setPixmap(pixmap.scaled(self.preview.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        self._source_pixmap=pixmap

    def metadata_changed(self, *_args) -> None:
        if self.value:
            self.value = {**self.value, "role": self.role.currentData(), "notes": self.notes.text()}
            self.value["audio_only"] = self.audio_only.isChecked() if self.value.get("kind") == "video" else False
            self.changed.emit(dict(self.value))

    def load_image(self, image: QImage, name: str = "Pasted reference.png") -> bool:
        self._import_serial += 1
        if image.isNull():
            self.error.emit("That file could not be read as an image.")
            return False
        buffer = QBuffer()
        buffer.open(QIODevice.OpenModeFlag.WriteOnly)
        if not image.save(buffer, "PNG"):
            self.error.emit("Could not store the reference image.")
            return False
        value = {"name": name, "image": "data:image/png;base64," + base64.b64encode(bytes(buffer.data())).decode(),
                 "role": self.role.currentData(), "notes": self.notes.text()}
        self.set_value(value)
        self.changed.emit(value)
        return True

    def load_path(self, path: str) -> bool:
        if Path(path).suffix.lower() in TIMELINE_VIDEO_SUFFIXES | AUDIO_SUFFIXES:
            self._import_serial += 1
            serial = self._import_serial
            revision = self.owner.workspace_revision if self.owner else None
            def imported(value):
                if serial != self._import_serial or (self.owner and revision != self.owner.workspace_revision):
                    return
                self.set_value(value)
                self.changed.emit(value)
            if self.owner:
                self.filename.setText("Importing media…")
                self.owner.start_disk_job(import_reference, (path, self.role.currentData(), self.notes.text()),
                    imported, lambda message:self.error.emit(message))
            else:
                try:
                    imported(import_reference(path,self.role.currentData(),self.notes.text()))
                except Exception as error:
                    self.error.emit(str(error))
                    return False
            return True
        from PySide6.QtGui import QImageReader
        reader = QImageReader(path)
        reader.setAutoTransform(True)
        if reader.supportsAnimation():
            self.error.emit("Use a still image for this reference slot.")
            return False
        image = reader.read()
        if image.isNull():
            self.error.emit("That file could not be read as an image.")
            return False
        self._import_serial += 1
        source = Path(path)
        mime = {'.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.bmp':'image/bmp',
                '.tif':'image/tiff','.tiff':'image/tiff'}.get(source.suffix.lower(),'image/png')
        value = {'name':source.name,'image':'data:'+mime+';base64,'+base64.b64encode(source.read_bytes()).decode(),
                 'role':self.role.currentData(),'notes':self.notes.text()}
        self.set_value(value)
        self.changed.emit(value)
        return True

    def browse(self) -> None:
        path = choose_document_open(self, "Choose reference media", "", "Media (*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff *.mp4 *.webm *.mov *.mkv *.wav *.mp3 *.flac *.ogg *.m4a *.aac *.opus)")
        if path:
            self.load_path(path)

    def paste(self) -> None:
        if not self.load_mime(QApplication.clipboard().mimeData()):
            self.error.emit("Copy an image or a local media file, then paste it here.")

    def clear(self) -> None:
        self._import_serial += 1
        self.set_value(None)
        self.changed.emit(None)

    def load_mime(self, mime) -> bool:
        if mime.hasUrls():
            paths = [url.toLocalFile() for url in mime.urls() if url.isLocalFile()]
            if paths:
                return self.load_path(paths[0])
        if mime.hasImage():
            image = mime.imageData()
            if isinstance(image, QPixmap):
                image = image.toImage()
            return self.load_image(image) if isinstance(image, QImage) else False
        return False

    def dragEnterEvent(self, event) -> None:
        if self.accepts_mime(event.mimeData()):
            self.set_drop_active(True)
            event.acceptProposedAction()
        else:
            self.set_drop_active(False)
            event.ignore()

    @staticmethod
    def accepts_mime(mime) -> bool:
        return mime.hasImage() or any(url.isLocalFile() and Path(url.toLocalFile()).is_file()
            and Path(url.toLocalFile()).suffix.lower() in ({".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"} | TIMELINE_VIDEO_SUFFIXES | AUDIO_SUFFIXES)
            for url in mime.urls())

    def dragMoveEvent(self, event) -> None:
        self.dragEnterEvent(event)

    def dragLeaveEvent(self, event) -> None:
        self.set_drop_active(False)
        super().dragLeaveEvent(event)

    def set_drop_active(self, active) -> None:
        self.setProperty("dropActive", bool(active))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def show_image_menu(self, point) -> None:
        menu = QMenu(self)
        menu.addAction(self.export_action)
        menu.addAction(self.clear_action)
        menu.exec(point)

    def contextMenuEvent(self, event) -> None:
        self.show_image_menu(event.globalPos())
        event.accept()

    def drag_mime(self):
        if self.value and self.value.get('kind') in {'video','audio'} and Path(self.value.get('path','')).is_file():
            mime = QMimeData()
            mime.setUrls([QUrl.fromLocalFile(self.value['path'])])
            return mime
        if not self.value or not self.value.get("image"):
            return None
        data = base64.b64decode(self.value.get("image", "").split(",", 1)[1])
        # Keep URL targets alive after the drag returns: external file managers
        # may read them asynchronously. The content hash avoids stale copies.
        root = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.CacheLocation)) / "reference-drags"
        root = root / hashlib.sha256(data).hexdigest()
        root.mkdir(parents=True, exist_ok=True)
        name = Path(self.value.get("name") or "Reference.png").stem
        mime_type = self.value.get("image", "").split(";", 1)[0].removeprefix("data:").lower()
        suffix = {"image/jpeg": ".jpg", "image/webp": ".webp", "image/bmp": ".bmp",
                  "image/tiff": ".tiff"}.get(mime_type, ".png")
        path = root / (name + suffix)
        if not path.exists():
            path.write_bytes(data)
        mime = QMimeData()
        mime.setUrls([QUrl.fromLocalFile(str(path))])
        mime.setImageData(QImage.fromData(data))
        return mime

    def eventFilter(self, watched, event):
        if (watched is getattr(self, "notes", None) and event.type() == QEvent.Type.FocusOut
                and self.value and self.notes.text() != self.value.get("notes", "")):
            self.metadata_changed()
        if watched is self.preview and event.type()==QEvent.Type.Resize and not self._source_pixmap.isNull():
            self.preview.setPixmap(self._source_pixmap.scaled(self.preview.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        if watched is self.preview:
            if event.type() == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                self._drag_start = event.position().toPoint()
            elif event.type() == QEvent.Type.MouseButtonRelease:
                self._drag_start = None
            elif event.type() == QEvent.Type.MouseMove and self._drag_start is not None and event.buttons() & Qt.MouseButton.LeftButton:
                if (event.position().toPoint() - self._drag_start).manhattanLength() >= QApplication.startDragDistance():
                    self._drag_start = None
                    mime = self.drag_mime()
                    if mime:
                        drag = QDrag(self.preview)
                        drag.setMimeData(mime)
                        if self.preview.pixmap() and not self.preview.pixmap().isNull():
                            drag.setPixmap(self.preview.pixmap())
                        drag.exec(Qt.DropAction.CopyAction)
                        return True
        return super().eventFilter(watched, event)

    def dropEvent(self, event) -> None:
        self.set_drop_active(False)
        if self.load_mime(event.mimeData()):
            event.acceptProposedAction()
        else:
            event.ignore()
