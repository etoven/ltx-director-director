from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path
from urllib.parse import quote

import imageio_ffmpeg
from PIL import Image
from PIL import ImageOps
from PySide6.QtCore import QStandardPaths


_os_cache = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.GenericCacheLocation)
APP_CACHE = (Path(_os_cache) if _os_cache else Path(tempfile.gettempdir())) / "ltx-director-director"
APP_CACHE.mkdir(parents=True, exist_ok=True)
TIMELINE_VIDEO_SUFFIXES = {".webm", ".mp4"}
THUMBNAIL_EDGE = 640
_VIDEO_DIMENSIONS: dict[str, tuple[int, int]] = {}


def cache_key(path: str) -> str:
    source = Path(path).resolve()
    stat = source.stat()
    return hashlib.sha256(f"{source}:{stat.st_size}:{stat.st_mtime_ns}".encode()).hexdigest()[:24]


def thumbnail_for_image(path: str) -> str:
    """Cache a bounded, orientation-correct JPEG; never replace the source image."""
    source = Path(path)
    if not source.is_file():
        return path
    destination = APP_CACHE / "thumbnails" / f"image-{cache_key(path)}.jpg"
    if not destination.is_file():
        destination.parent.mkdir(parents=True, exist_ok=True)
        with Image.open(source) as opened:
            image = ImageOps.exif_transpose(opened)
            image.thumbnail((THUMBNAIL_EDGE, THUMBNAIL_EDGE), Image.Resampling.LANCZOS)
            if image.mode != "RGB":
                image = image.convert("RGB")
            temporary = destination.with_name(destination.name + f".{os.getpid()}.tmp")
            try:
                image.save(temporary, "JPEG", quality=76, optimize=False)
                os.replace(temporary, destination)
            finally:
                temporary.unlink(missing_ok=True)
    return str(destination)


def safe_media_filename(value: str, fallback_stem: str = "media", *, suffix: str | None = None) -> str:
    """Return a filesystem-safe media name containing no whitespace."""
    source = Path(str(value).replace("\\", "/"))
    extension = source.suffix if re.fullmatch(r"\.[A-Za-z][A-Za-z0-9]{0,11}", source.suffix) else ""
    stem = source.name[:-len(extension)] if extension else source.name
    stem = re.sub(r"\s+", "_", stem.strip())
    stem = re.sub(r'[^\w.-]+', "_", stem, flags=re.UNICODE)
    stem = re.sub(r"_+", "_", stem).strip("._-") or fallback_stem
    if stem.split(".", 1)[0].upper() in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}:
        stem = "_" + stem
    stem = stem.encode("utf-8")[:150].decode("utf-8", errors="ignore").rstrip(" .")
    actual_suffix = extension if suffix is None else suffix
    if actual_suffix and not re.fullmatch(r"\.[A-Za-z][A-Za-z0-9]{0,11}", actual_suffix):
        actual_suffix = ""
    return f"{stem}{actual_suffix}"


def unique_media_filename(filename: str, used_names: set[str]) -> str:
    """Keep colliding media names unique within one export."""
    source = Path(filename)
    candidate = filename
    number = 2
    while candidate.casefold() in used_names:
        candidate = f"{source.stem}_{number}{source.suffix}"
        number += 1
    used_names.add(candidate.casefold())
    return candidate


def copy_media_for_export(source_path: str, display_name: str, destination: Path, used_names: set[str], fallback_stem: str) -> Path:
    """Copy media into ComfyUI with a safe, collision-free filename."""
    source = Path(source_path)
    suffix = media_suffix(source, source.suffix)
    name = unique_media_filename(safe_media_filename(display_name or source.name, fallback_stem, suffix=suffix), used_names)
    target = destination / name
    if source.resolve() != target.resolve():
        shutil.copy2(source, target)
    return target


def comfy_input_references(filename: str, subfolder: str = "whatdreamscost") -> tuple[str, str]:
    """Return Prompt Director's Comfy-relative file and browser preview references."""
    relative = f"{subfolder}/{filename}"
    preview = f"/api/view?filename={quote(filename, safe='')}&type=input&subfolder={quote(subfolder, safe='')}"
    return relative, preview


MEDIA_SUFFIXES = {"video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov",
                  "video/x-matroska": ".mkv", "video/x-msvideo": ".avi",
                  "image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp",
                  "image/gif": ".gif", "image/bmp": ".bmp", "image/tiff": ".tiff",
                  "image/heif": ".heif", "image/avif": ".avif", "audio/mp4": ".m4a",
                  "audio/wav": ".wav", "audio/mpeg": ".mp3", "audio/flac": ".flac",
                  "audio/ogg": ".ogg", "audio/aac": ".aac", "audio/aiff": ".aiff"}


def media_suffix(path: str | Path, fallback: str = "") -> str:
    return MEDIA_SUFFIXES.get(media_mime(path), fallback)


def media_mime(path: str | Path) -> str:
    """Identify cached/archived media by its bytes, regardless of its filename."""
    source = Path(path)
    with source.open("rb") as stream:
        header = stream.read(4096)
    return media_mime_from_header(header, source.suffix)


def media_mime_from_header(header: bytes, suffix: str = "") -> str:
    """Shared signature detection for real files and lazy archive members."""
    if header[4:8] == b"ftyp":
        brand = header[8:12]
        if brand in {b"M4A ", b"M4B "} or suffix.lower() == ".m4a":
            return "audio/mp4"
        if brand == b"qt  ":
            return "video/quicktime"
        if brand in {b"heic", b"heix", b"hevc", b"hevx", b"mif1"}:
            return "image/heif"
        if brand in {b"avif", b"avis"}:
            return "image/avif"
        return "video/mp4"
    if header.startswith(b"\x1aE\xdf\xa3"):
        return "video/webm" if b"webm" in header else "video/x-matroska"
    if header.startswith(b'FORM') and header[8:12] in (b'AIFF', b'AIFC'):
        return 'audio/aiff'
    if header.startswith(b"RIFF"):
        return {b"WEBP": "image/webp", b"WAVE": "audio/wav",
                b"AVI ": "video/x-msvideo"}.get(header[8:12], "application/octet-stream")
    for signature, mime in ((b"\x89PNG\r\n\x1a\n", "image/png"),
                            (b"\xff\xd8\xff", "image/jpeg"), (b"GIF8", "image/gif"),
                            (b"BM", "image/bmp"), (b"II*\x00", "image/tiff"),
                            (b"MM\x00*", "image/tiff"), (b"fLaC", "audio/flac"),
                            (b"OggS", "audio/ogg"), (b"ID3", "audio/mpeg")):
        if header.startswith(signature):
            return mime
    return {".webm": "video/webm", ".mp4": "video/mp4", ".mov": "video/quicktime",
            ".mkv": "video/x-matroska", ".avi": "video/x-msvideo", ".m4v": "video/mp4",
            ".wav": "audio/wav", ".mp3": "audio/mpeg", ".flac": "audio/flac",
            ".ogg": "audio/ogg", ".m4a": "audio/mp4", ".aac": "audio/aac",
            ".opus": "audio/ogg", ".aif": "audio/aiff", ".aiff": "audio/aiff", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif"}.get(suffix.lower(), "application/octet-stream")


def data_url(path: str, max_edge: int | None = None, quality: int = 82) -> str:
    source = Path(path)
    if max_edge:
        with Image.open(source) as image:
            image = image.convert("RGB")
            image.thumbnail((max_edge, max_edge), Image.Resampling.LANCZOS)
            output = io.BytesIO()
            image.save(output, "WEBP", quality=quality, method=6)
        return "data:image/webp;base64," + base64.b64encode(output.getvalue()).decode()
    mime = media_mime(source)
    return f"data:{mime};base64," + base64.b64encode(source.read_bytes()).decode()


def probe_video_duration(path: str) -> float:
    """Return a video's duration in seconds using the bundled FFmpeg binary."""
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    probe = subprocess.run([ffmpeg, "-hide_banner", "-i", str(path)], capture_output=True, text=True, check=False)
    dimensions = re.search(r"Video:[^\n]*?\b(\d{2,5})x(\d{2,5})\b", probe.stderr)
    if dimensions:
        _VIDEO_DIMENSIONS[cache_key(path)] = (int(dimensions.group(1)), int(dimensions.group(2)))
    match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", probe.stderr)
    if not match:
        return 0.0
    return int(match.group(1)) * 3600 + int(match.group(2)) * 60 + float(match.group(3))


def video_storyboard_data_urls(path: str, count: int = 6, max_edge: int = 512) -> list[dict[str, float | str]]:
    """Sample timestamped frames across a video for providers without native video input."""
    source = Path(path)
    if not source.is_file():
        return []
    duration = probe_video_duration(str(source))
    if duration <= 0:
        return []
    count = max(2, min(10, int(count)))
    final_timestamp = max(0.0, duration - min(.1, duration / (count * 2)))
    timestamps = [final_timestamp * index / (count - 1) for index in range(count)]
    frames: list[dict[str, float | str]] = []
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    with tempfile.TemporaryDirectory(prefix="ltx-video-analysis-") as directory:
        for index, timestamp in enumerate(timestamps):
            output = Path(directory) / f"frame-{index:02d}.jpg"
            result = subprocess.run(
                [ffmpeg, "-y", "-ss", f"{timestamp:.3f}", "-i", str(source), "-frames:v", "1", "-q:v", "2", str(output)],
                capture_output=True,
                check=False,
            )
            if not result.returncode and output.is_file():
                frames.append({"timestamp": round(timestamp, 3), "image": data_url(str(output), max_edge=max_edge)})
    return frames


def write_data_url(value: str, destination: Path) -> None:
    _, encoded = value.split(",", 1)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(base64.b64decode(encoded))


def capture_video_preview(path: str, fps_out: int = 24) -> tuple[str, int, int]:
    source = Path(path)
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    preview = APP_CACHE / "thumbnails" / f"video-{cache_key(path)}.jpg"
    metadata = preview.with_suffix(".json")
    if preview.is_file() and metadata.is_file():
        try:
            cached = json.loads(metadata.read_text(encoding="utf-8"))
            duration = float(cached["duration"])
            frames = max(1, round(duration * fps_out))
            return str(preview), frames, max(0, frames - fps_out)
        except (OSError, ValueError, KeyError):
            pass
    preview.parent.mkdir(parents=True, exist_ok=True)
    duration = probe_video_duration(str(source)) or 1.0
    seek = max(0.0, duration - 1.0)
    scale = f"scale=w={THUMBNAIL_EDGE}:h={THUMBNAIL_EDGE}:force_original_aspect_ratio=decrease"
    command = [ffmpeg, "-y", "-ss", f"{seek:.3f}", "-i", str(source), "-frames:v", "1", "-vf", scale, "-q:v", "4", str(preview)]
    result = subprocess.run(command, capture_output=True, check=False)
    if result.returncode or not preview.is_file():
        fallback = [ffmpeg, "-y", "-i", str(source), "-frames:v", "1", "-vf", scale, "-q:v", "4", str(preview)]
        result = subprocess.run(fallback, capture_output=True, check=False)
    if result.returncode or not preview.is_file():
        raise ValueError("Could not decode a preview frame from the video file.")
    duration_frames = max(1, round(duration * fps_out))
    trim_start = max(0, duration_frames - fps_out)
    width, height = _VIDEO_DIMENSIONS.pop(cache_key(path), (0, 0))
    metadata.write_text(json.dumps({"duration": duration, "width": width, "height": height}), encoding="utf-8")
    return str(preview), duration_frames, trim_start


def video_source_dimensions(path: str) -> tuple[int, int] | None:
    source = Path(path)
    if not source.is_file():
        return None
    metadata = APP_CACHE / "thumbnails" / f"video-{cache_key(path)}.json"
    try:
        record = json.loads(metadata.read_text(encoding="utf-8"))
        width, height = int(record["width"]), int(record["height"])
        return (width, height) if width > 0 and height > 0 else None
    except (OSError, ValueError, KeyError):
        return None


def prepare_media(path: str) -> tuple[str, str, int | None, int | None]:
    source = Path(path)
    if source.suffix.lower() in TIMELINE_VIDEO_SUFFIXES:
        preview, frames, trim = capture_video_preview(path)
        return "video", preview, frames, trim
    with Image.open(source) as image:
        image.verify()
    return "image", thumbnail_for_image(path), None, None


def extract_audio_for_export(source_path: str, destination: str | Path, fps: int = 24) -> tuple[int, list[float]]:
    """Extract a video's complete audio stream and return its frame duration and peaks."""
    source = Path(source_path)
    output = Path(destination)
    output.parent.mkdir(parents=True, exist_ok=True)
    command = [
        imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-i", str(source), "-vn",
        "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(output),
    ]
    result = subprocess.run(command, capture_output=True, check=False)
    if result.returncode or not output.is_file() or output.stat().st_size <= 44:
        output.unlink(missing_ok=True)
        raise ValueError("No decodable audio track was found.")
    with wave.open(str(output), "rb") as audio:
        frame_count = audio.getnframes()
        sample_rate = audio.getframerate()
        sample_width = audio.getsampwidth()
        channels = audio.getnchannels()
        raw = audio.readframes(frame_count)
    duration_frames = max(1, round(frame_count / max(1, sample_rate) * fps))
    return duration_frames, waveform_peaks(raw, sample_width, channels)


def waveform_peaks(raw: bytes, sample_width: int, channels: int, count: int = 200) -> list[float]:
    """Return normalized peak amplitudes in evenly sized waveform buckets."""
    if sample_width != 2 or not raw:
        return [0.0] * count
    samples = memoryview(raw).cast("h")
    if channels > 1:
        samples = samples[::channels]
    bucket = max(1, len(samples) // count)
    peaks = []
    for index in range(count):
        chunk = samples[index * bucket:min(len(samples), (index + 1) * bucket)]
        peaks.append(max((abs(value) for value in chunk), default=0) / 32768.0)
    return peaks


def _image_mime(path: Path) -> str:
    return {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif"}.get(path.suffix.lower(), "image/png")
