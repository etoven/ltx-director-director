"""LTX Director - Director native desktop application."""

__version__ = "1.13.0a29"
