from __future__ import annotations

import base64
import copy
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import warnings
import zipfile
from datetime import datetime, timezone
from importlib.resources import files
from pathlib import Path
from uuid import uuid4

from PySide6.QtCore import QDateTime, QEasingCurve, QEventLoop, QObject, QRunnable, QRectF, QSettings, QSize, QStandardPaths, Qt, QThreadPool, QTimer, QUrl, QVariantAnimation, Signal, Slot
from PySide6.QtGui import QAction, QActionGroup, QBrush, QColor, QCursor, QIcon, QImageReader, QPainter, QPen, QPixmap, QTextCharFormat, QTextCursor, QTextOption
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QColorDialog, QDateTimeEdit, QDockWidget, QGraphicsOpacityEffect, QFileDialog, QFormLayout, QFrame, QHBoxLayout, QLabel, QLayout, QLineEdit,
    QListWidget, QListWidgetItem, QTabBar, QTabWidget, QMainWindow, QMenu, QMessageBox, QPushButton, QScrollArea,
    QSizePolicy, QSlider, QSpinBox, QProgressBar, QStatusBar, QStyle, QStyledItemDelegate, QStyleOptionSlider, QStyleOptionViewItem, QTextEdit, QToolBar, QToolTip, QVBoxLayout, QWidget,
)

from . import __version__
from .cache_maintenance import cover_path, mark_ready, needs_refresh, warm_metadata
from .ai import AIResponseFormatError, GEMINI_MODELS, build_minimax_h3_prompt, build_minimax_h3_reference_prompt, build_prompts, minimax_h3_cache_key, provider_error_message, WORKSPACE_INSTRUCTIONS, refine_minimax_h3_prompt, refine_minimax_h3_reference_prompt, refine_segment_prompt, refine_timing, retryable_connection_error
from .media import APP_CACHE, TIMELINE_VIDEO_SUFFIXES, comfy_input_references, copy_media_for_export, data_url, extract_audio_for_export, prepare_media, safe_media_filename, thumbnail_for_image, unique_media_filename, video_source_dimensions, write_data_url
from .project_archive import materialize_source, project_thumbnail_data, read_project, save_project_archive
from .minimax_reference import WORKFLOW_NAMES, detect_workflow, reference_inventory, reference_slots
from .minimax_reference_widgets import MiniMaxReferenceSlot
from .generic_ai import build_generic_prompt, refine_generic_prompt, build_generic_segments, refine_generic_segment
from .downloads import DownloadTray
from .catalog import MediaCatalog
from .media_labels import add_thumbnail_labels
from .workspaces import WorkspaceStore
from .workspace_editor import WorkspaceEditor
from .models import Segment, order_segments_by_ids, text_segment_from_ltx
from .project_data import ARCHIVE_COLOR, load_other_tags, load_project_tags, new_note, normalize_notes, normalize_project_labels
from .spellcheck import install_spellcheck
from .prompt_tags import consume_global_refinements, install_prompt_tags, render_prompt_notes
from .inline_cues import PromptTextEdit, cue_cells, insert_cue_cells, focus_cue
from .timed_action import CUE, NEXT, SECTION, compose_actions, split_actions, parse_timed_plan

FPS = 24
MIN_DURATION = 0.01
PROJECT_CARD_COLOR_ROLE = int(Qt.ItemDataRole.UserRole) + 1


def project_library_path() -> Path:
    root = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
    path = Path(root) / "projects"
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_export_name(value: str) -> str:
    cleaned = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "-", value).strip(" .-")
    return cleaned or "Untitled"


def pixmap_from_data_url(value: str) -> QPixmap:
    pixmap = QPixmap()
    try:
        pixmap.loadFromData(base64.b64decode(value.split(",", 1)[1]))
    except (IndexError, ValueError):
        pass
    return pixmap


def timeline_preview_pixmap(path: str) -> QPixmap:
    """Decode a timeline-sized preview instead of retaining an unbounded source image."""
    if not path:
        return QPixmap()
    reader = QImageReader(path)
    reader.setAutoTransform(True)
    size = reader.size()
    if size.isValid() and (size.width() > 1024 or size.height() > 1024):
        size.scale(QSize(1024, 1024), Qt.AspectRatioMode.KeepAspectRatio)
        reader.setScaledSize(size)
    image = reader.read()
    return QPixmap.fromImage(image) if not image.isNull() else QPixmap()


def requested_length_value(value: object) -> float:
    """Map legacy Auto/null project values to the spin box's zero=Auto value."""
    if value is None or (isinstance(value, str) and value.strip().casefold() in {"", "auto", "none", "null"}):
        return 0.0
    try:
        duration = float(value)
    except (TypeError, ValueError):
        return 0.0
    return duration if math.isfinite(duration) and duration > 0 else 0.0


def application_window_title(project_name: str = "") -> str:
    title = f"LTX Director - Director v{__version__}"
    return f"{title} :: {project_name}" if project_name else title


def toolbar_icon(name: str) -> QIcon:
    """Return one of the bundled, theme-independent toolbar icons."""
    return QIcon(str(files("ltx_prompt_director").joinpath(f"assets/toolbar-{name}.svg")))


def _export_segment_source(segment: Segment, target: Path):
    source = Path(materialize_source(segment))
    if not source.is_file():
        raise FileNotFoundError("The complete source media for this segment is not available.")
    return shutil.copy2(source, target)


def segment_media_suffix(segment: Segment) -> str:
    """Preserve a segment's real container instead of renaming video bytes."""
    return Path(segment.name).suffix or Path(segment.media_path).suffix or (".webm" if segment.kind == "video" else ".png")


def segment_kind_label(segment: Segment) -> str:
    if segment.kind == "text":
        return "TEXT"
    if segment.kind == "image":
        return "IMAGE"
    container = segment_media_suffix(segment).lstrip(".").upper()
    return container if container in {"WEBM", "MP4"} else "VIDEO"


def choose_media_files(parent: QWidget, multiple: bool, initial: str) -> list[str]:
    """Prefer the desktop's actual file picker, then fall back to QFileDialog."""
    media_filter = "Supported Media (*.png *.jpg *.jpeg *.webp *.gif *.webm *.mp4)"
    if sys.platform.startswith("linux") and shutil.which("kdialog"):
        command = ["kdialog", "--title", "Choose images or video files"]
        if multiple:
            command.extend(["--multiple", "--separate-output"])
        command.extend(["--getopenfilename", initial or ":ltxPromptDirectorMedia", media_filter])
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        if result.returncode == 0:
            return [line.strip() for line in result.stdout.splitlines() if line.strip()]
        return []
    if sys.platform.startswith("linux") and shutil.which("zenity"):
        command = ["zenity", "--file-selection", "--title=Choose images or video files", f"--filename={initial.rstrip('/')}/", "--file-filter=Supported media | *.png *.jpg *.jpeg *.webp *.gif *.webm *.mp4"]
        if multiple:
            command.extend(["--multiple", "--separator=\n"])
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        if result.returncode == 0:
            return [line.strip() for line in result.stdout.splitlines() if line.strip()]
        return []
    if multiple:
        files, _ = QFileDialog.getOpenFileNames(parent, "Add images or video", initial, media_filter)
        return files
    file, _ = QFileDialog.getOpenFileName(parent, "Replace media", initial, media_filter)
    return [file] if file else []


def choose_document_open(parent: QWidget, title: str, initial: str, name_filter: str) -> str:
    if sys.platform.startswith("linux") and shutil.which("kdialog"):
        result = subprocess.run(["kdialog", "--title", title, "--getopenfilename", initial, name_filter], capture_output=True, text=True, check=False)
        return result.stdout.strip() if result.returncode == 0 else ""
    if sys.platform.startswith("linux") and shutil.which("zenity"):
        result = subprocess.run(["zenity", "--file-selection", f"--title={title}", f"--filename={initial.rstrip('/')}/", f"--file-filter={name_filter}"], capture_output=True, text=True, check=False)
        return result.stdout.strip() if result.returncode == 0 else ""
    file, _ = QFileDialog.getOpenFileName(parent, title, initial, name_filter)
    return file


def choose_document_save(parent: QWidget, title: str, suggested: str, name_filter: str) -> str:
    if sys.platform.startswith("linux") and shutil.which("kdialog"):
        result = subprocess.run(["kdialog", "--title", title, "--getsavefilename", suggested, name_filter], capture_output=True, text=True, check=False)
        return result.stdout.strip() if result.returncode == 0 else ""
    if sys.platform.startswith("linux") and shutil.which("zenity"):
        result = subprocess.run(["zenity", "--file-selection", "--save", "--confirm-overwrite", f"--title={title}", f"--filename={suggested}", f"--file-filter={name_filter}"], capture_output=True, text=True, check=False)
        return result.stdout.strip() if result.returncode == 0 else ""
    file, _ = QFileDialog.getSaveFileName(parent, title, suggested, name_filter)
    return file


def choose_directory(parent: QWidget, title: str, initial: str) -> str:
    if sys.platform.startswith("linux") and shutil.which("kdialog"):
        result = subprocess.run(["kdialog", "--title", title, "--getexistingdirectory", initial], capture_output=True, text=True, check=False)
        return result.stdout.strip() if result.returncode == 0 else ""
    if sys.platform.startswith("linux") and shutil.which("zenity"):
        result = subprocess.run(["zenity", "--file-selection", "--directory", f"--title={title}", f"--filename={initial.rstrip('/')}/"], capture_output=True, text=True, check=False)
        return result.stdout.strip() if result.returncode == 0 else ""
    return QFileDialog.getExistingDirectory(parent, title, initial)


class WorkerSignals(QObject):
    finished = Signal(object)
    failed = Signal(str)
    progress = Signal(int, int, str)


class MagicWorker(QRunnable):
    def __init__(self, operation, args: tuple, retries: int, retry_cooldown: int, activity: str = "Analyzing frames and directing motion…"):
        super().__init__()
        self.operation = operation
        self.args = args
        self.retries = retries
        self.retry_cooldown = max(0, int(retry_cooldown))
        self.activity = activity
        self.signals = WorkerSignals()

    def run(self) -> None:
        attempts = max(0, int(self.retries)) + 1
        for attempt in range(1, attempts + 1):
            try:
                self.signals.progress.emit(attempt, attempts, self.activity)
                self.signals.finished.emit(self.operation(*self.args))
                return
            except Exception as error:
                if attempt >= attempts or not retryable_connection_error(error):
                    message = provider_error_message(error)
                    if retryable_connection_error(error) and attempts > 1:
                        message = f"{message}\n\nStopped after {attempt} attempts."
                    self.signals.failed.emit(message)
                    return
                retry_subject = "AI response failed validation" if isinstance(error, AIResponseFormatError) else "Provider response stumbled"
                for remaining in range(self.retry_cooldown, 0, -1):
                    self.signals.progress.emit(attempt + 1, attempts, f"{retry_subject}—retrying in {remaining}s…")
                    time.sleep(1)
                if self.retry_cooldown == 0:
                    self.signals.progress.emit(attempt + 1, attempts, f"{retry_subject}—retrying now…")


class BackgroundWorker(QRunnable):
    """Run disk work off the GUI thread; deliver results via Qt queued signals."""

    def __init__(self, operation, args: tuple):
        super().__init__()
        self.operation = operation
        self.args = args
        self.signals = WorkerSignals()

    def run(self) -> None:
        try:
            result = self.operation(*self.args)
        except Exception as error:
            try:
                self.signals.failed.emit(str(error))
            except RuntimeError:
                pass  # The window closed while its queued disk job was finishing.
            return
        try:
            self.signals.finished.emit(result)
        except RuntimeError:
            pass  # A test or shutdown released the receiver before delivery.


class BackgroundCallbacks(QObject):
    def __init__(self, owner, finished, failed):
        super().__init__(owner)
        self.owner = owner
        self.finished = finished
        self.failed = failed

    @Slot(object)
    def on_finished(self, result):
        self._complete(self.finished, result)

    @Slot(str)
    def on_failed(self, message):
        self.owner._close_after_jobs = False
        self._complete(self.failed, message)

    def _complete(self, callback, result):
        self.owner._pending_disk_jobs -= 1
        try:
            callback(result)
        finally:
            self.owner.update_closing_progress()
            if self.owner._close_after_jobs and not self.owner._pending_disk_jobs:
                # Let the completed progress state reach the screen before dismissing it.
                QTimer.singleShot(180, self.owner.close)
            self.deleteLater()


def _write_library_archive(path: str, payload: dict, segments: list[Segment], metadata_path: Path, meta: dict) -> None:
    save_project_archive(path, payload, segments)
    metadata_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")


def _prepare_media_batch(paths: list[str]) -> tuple[list[tuple[str, str, str, int | None, int | None]], list[str]]:
    prepared, errors = [], []
    for path in paths:
        try:
            kind, preview, frames, trim = prepare_media(path)
            prepared.append((path, kind, preview, frames, trim))
        except Exception as error:
            errors.append(f"{Path(path).name}: {error}")
    return prepared, errors


def _persist_library_archive(meta: dict, metadata_path: Path) -> None:
    """Update the archive in order; the UI already saved current gallery metadata."""
    project_path = Path(meta.get("projectPath", ""))
    if project_path.is_file() and zipfile.is_zipfile(project_path):
        with zipfile.ZipFile(project_path, "a") as archive:
            payload = json.loads(archive.read("project.json"))
            payload["library"] = {key: meta.get(key, "") for key in ("id", "name", "description", "collection", "savedAt", "status", "tags", "tag", "archived", "notes", "previewVideoPath", "previewVideoName", "projectFiles", "workflowFiles", "downloadDirectory")}
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                archive.writestr("project.json", json.dumps(payload, separators=(",", ":")), compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    elif project_path.is_file() and project_path.stat().st_size < 1024 * 1024:
        payload = json.loads(project_path.read_text(encoding="utf-8"))
        payload["library"] = {key: meta.get(key, "") for key in ("id", "name", "description", "collection", "savedAt", "status", "tags", "tag", "archived", "notes", "previewVideoPath", "previewVideoName", "projectFiles", "workflowFiles", "downloadDirectory")}
        project_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _export_ltx_snapshot(segments: list[Segment], global_prompt: str, output_width: int, output_height: int,
                         media_directory: Path, path: str) -> None:
    """Prepare full-resolution ComfyUI media and JSON away from the GUI thread."""
    media_directory.mkdir(parents=True, exist_ok=True)
    cursor = 0
    timeline = []
    audio_timeline = []
    used_media_names: set[str] = set()
    for segment in segments:
        start = cursor
        length = max(1, round(segment.duration * FPS))
        record = {"id": segment.id, "type": segment.kind, "start": start, "length": length, "prompt": segment.prompt, "isEndFrame": False if segment.kind == "text" else segment.role == "end"}
        if segment.kind != "text":
            source = Path(materialize_source(segment))
            record.update({"imageFile": str(source), "fileName": segment.name,
                           "fileSize": source.stat().st_size if source.exists() else 0,
                           "imageB64": data_url(segment.preview_path) if segment.preview_path else ""})
            if segment.kind == "image" and source.exists():
                image_path = copy_media_for_export(str(source), segment.name, media_directory, used_media_names, "image")
                image_file, image_preview = comfy_input_references(image_path.name)
                record.update({"imageFile": image_file, "imageB64": image_preview})
                record.pop("fileName", None)
                record.pop("fileSize", None)
            elif segment.kind == "video":
                record.update({"trimStart": segment.trim_start or 0, "videoDurationFrames": segment.media_duration_frames or length})
                if source.exists():
                    video_path = copy_media_for_export(str(source), segment.name, media_directory, used_media_names, "video")
                    video_name = video_path.name
                    video_file, _ = comfy_input_references(video_name)
                    record.update({"imageFile": video_file, "fileName": video_name, "fileSize": video_path.stat().st_size})
                    record["videoB64"] = data_url(str(video_path))
                    audio_name = unique_media_filename(f"{video_path.stem}_extracted_audio.wav", used_media_names)
                    audio_path = media_directory / audio_name
                    try:
                        audio_duration_frames, peaks = extract_audio_for_export(str(video_path), audio_path, FPS)
                    except ValueError:
                        pass
                    else:
                        audio_file, _ = comfy_input_references(audio_name)
                        audio_timeline.append({
                            "id": f"{segment.id}_a", "type": "audio", "start": start,
                            "length": length, "trimStart": segment.trim_start or 0,
                            "audioDurationFrames": audio_duration_frames,
                            "audioFile": audio_file, "fileName": video_name,
                            "waveformPeaks": peaks, "fileSize": audio_path.stat().st_size,
                        })
        timeline.append(record)
        cursor += length
    payload = {"version": 1, "settings": {"start_second": 0, "end_second": cursor / FPS, "duration_seconds": cursor / FPS, "start_frame": 0, "end_frame": cursor, "duration_frames": cursor, "epsilon": .99, "use_custom_audio": bool(audio_timeline), "use_custom_motion": False, "inpaint_audio": True, "frame_rate": FPS, "display_mode": "seconds", "custom_width": output_width, "custom_height": output_height, "resize_method": "crop", "divisible_by": 32, "img_compression": 0, "override_audio": False}, "global_prompt": global_prompt, "retake_global_prompt": "", "timeline": {"mainTrackEnabled": True, "audioTrackEnabled": bool(audio_timeline), "motionTrackEnabled": False, "showFilenames": True, "overrideAudio": False, "inpaint_audio": True, "propHeight": 163, "globalPropHeight": 124, "global_prompt": global_prompt, "retake_global_prompt": "", "retakeMode": False, "retakeStart": 0, "retakeLength": 0, "retakePrompt": "", "retakeStrength": 1, "retakeVideo": None, "normalStartFrame": 0, "normalDurationFrames": cursor, "segments": timeline, "motionSegments": [], "audioSegments": audio_timeline}}
    temporary_fd, temporary_name = tempfile.mkstemp(prefix=f".{Path(path).name}.", suffix=".tmp", dir=Path(path).parent)
    try:
        with os.fdopen(temporary_fd, "w", encoding="utf-8") as output:
            json.dump(payload, output, indent=2)
        os.replace(temporary_name, path)
    finally:
        Path(temporary_name).unlink(missing_ok=True)


class TimelineListWidget(QListWidget):
    files_dropped = Signal(list, int)
    files_replaced = Signal(list, int)
    projects_dropped = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._scroll_animation = None
        self._scroll_target = 0
        self._drop_index = -1
        self.setAcceptDrops(True)
        self.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.horizontalScrollBar().setSingleStep(24)
        self.horizontalScrollBar().sliderPressed.connect(self._cancel_smooth_scroll)

    def wheelEvent(self, event) -> None:
        bar = self.horizontalScrollBar()
        pixel_delta = event.pixelDelta()
        pixels = pixel_delta.x() or pixel_delta.y()
        if pixels:
            self._cancel_smooth_scroll()
            bar.setValue(bar.value() - pixels)
            self._scroll_target = bar.value()
            event.accept()
            return
        angle_delta = event.angleDelta()
        degrees = angle_delta.x() or angle_delta.y()
        if not degrees:
            super().wheelEvent(event)
            return
        base = self._scroll_target if self._scroll_animation else bar.value()
        distance = round(-(degrees / 120) * 120)
        self._scroll_target = max(bar.minimum(), min(bar.maximum(), base + distance))
        if self._scroll_animation:
            self._scroll_animation.stop()
        animation = QVariantAnimation(self)
        animation.setDuration(190)
        animation.setStartValue(bar.value())
        animation.setEndValue(self._scroll_target)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.valueChanged.connect(lambda value: bar.setValue(round(value)))
        animation.finished.connect(self._smooth_scroll_finished)
        self._scroll_animation = animation
        animation.start()
        event.accept()

    def _cancel_smooth_scroll(self) -> None:
        if self._scroll_animation:
            self._scroll_animation.stop()
            self._scroll_animation = None
        self._scroll_target = self.horizontalScrollBar().value()

    def _smooth_scroll_finished(self) -> None:
        self._scroll_animation = None
        self._scroll_target = self.horizontalScrollBar().value()

    def mousePressEvent(self, event) -> None:
        self._cancel_smooth_scroll()
        super().mousePressEvent(event)

    @staticmethod
    def _media_paths(event) -> list[str]:
        if not event.mimeData().hasUrls():
            return []
        supported = {".png", ".jpg", ".jpeg", ".webp", ".gif", *TIMELINE_VIDEO_SUFFIXES}
        return [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile() and Path(url.toLocalFile()).suffix.lower() in supported]

    @staticmethod
    def _project_paths(event) -> list[str]:
        if not event.mimeData().hasUrls():
            return []
        supported = {".ltxd", ".json"}
        return [
            url.toLocalFile() for url in event.mimeData().urls()
            if url.isLocalFile() and Path(url.toLocalFile()).is_file() and Path(url.toLocalFile()).suffix.casefold() in supported
        ]

    def dragEnterEvent(self, event) -> None:
        if self._media_paths(event) or self._project_paths(event):
            self.setProperty("dropActive", True)
            self.style().unpolish(self)
            self.style().polish(self)
            event.acceptProposedAction()
            return
        super().dragEnterEvent(event)

    def dragMoveEvent(self, event) -> None:
        media_paths = self._media_paths(event)
        project_paths = self._project_paths(event)
        if media_paths or project_paths:
            replacing = bool(getattr(event, "modifiers", lambda: Qt.KeyboardModifier.NoModifier)() & Qt.KeyboardModifier.ControlModifier)
            target = self.itemAt(event.position().toPoint()) if replacing else None
            self._drop_index = self.row(target) if target else self.insertion_index(event.position().toPoint()) if media_paths else -1
            self.viewport().update()
            event.acceptProposedAction()
            return
        super().dragMoveEvent(event)

    def dragLeaveEvent(self, event) -> None:
        self._clear_drop_state()
        super().dragLeaveEvent(event)

    def dropEvent(self, event) -> None:
        paths = self._media_paths(event)
        project_paths = self._project_paths(event)
        insertion_index = self.insertion_index(event.position().toPoint())
        self._clear_drop_state()
        if project_paths:
            self.projects_dropped.emit(project_paths)
            event.acceptProposedAction()
            return
        if paths:
            target = self.itemAt(event.position().toPoint()) if getattr(event, "modifiers", lambda: Qt.KeyboardModifier.NoModifier)() & Qt.KeyboardModifier.ControlModifier else None
            if target:
                self.files_replaced.emit(paths, self.row(target))
            else:
                self.files_dropped.emit(paths, insertion_index)
            event.acceptProposedAction()
            return
        super().dropEvent(event)

    def _clear_drop_state(self) -> None:
        self._drop_index = -1
        self.setProperty("dropActive", False)
        self.style().unpolish(self)
        self.style().polish(self)
        self.viewport().update()

    def insertion_index(self, point) -> int:
        item = self.itemAt(point)
        if item is None:
            return self.count()
        row = self.row(item)
        rect = self.visualItemRect(item)
        return row + (1 if point.x() >= rect.center().x() else 0)

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        if self._drop_index < 0:
            return
        if self._drop_index < self.count():
            x = self.visualItemRect(self.item(self._drop_index)).left()
        elif self.count():
            x = self.visualItemRect(self.item(self.count() - 1)).right()
        else:
            x = 4
        painter = QPainter(self.viewport())
        painter.setPen(QPen(QColor("#68b9ee"), 4))
        painter.drawLine(x, 4, x, self.viewport().height() - 4)


class ProjectListWidget(QListWidget):
    drag_started = Signal()
    order_changed = Signal()
    files_dropped = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._press_position = None
        self._drag_row = -1
        self._reordering = False
        self._scroll_animation = None
        self._scroll_target = 0
        self.setDragDropMode(QListWidget.DragDropMode.NoDragDrop)
        self.setAcceptDrops(True)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.verticalScrollBar().setSingleStep(24)

    def wheelEvent(self, event) -> None:
        bar = self.verticalScrollBar()
        pixels = event.pixelDelta().y()
        if pixels:
            if self._scroll_animation:
                self._scroll_animation.stop()
                self._scroll_animation = None
            bar.setValue(bar.value() - pixels)
            self._scroll_target = bar.value()
            event.accept()
            return
        degrees = event.angleDelta().y()
        if not degrees:
            super().wheelEvent(event)
            return
        base = self._scroll_target if self._scroll_animation else bar.value()
        distance = round(-(degrees / 120) * 96)
        self._scroll_target = max(bar.minimum(), min(bar.maximum(), base + distance))
        if self._scroll_animation:
            self._scroll_animation.stop()
        animation = QVariantAnimation(self)
        animation.setDuration(175)
        animation.setStartValue(bar.value())
        animation.setEndValue(self._scroll_target)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.valueChanged.connect(lambda value: bar.setValue(round(value)))
        animation.finished.connect(self._scroll_finished)
        self._scroll_animation = animation
        animation.start()
        event.accept()

    def _scroll_finished(self) -> None:
        self._scroll_animation = None
        self._scroll_target = self.verticalScrollBar().value()

    def mousePressEvent(self, event) -> None:
        self._press_position = event.position().toPoint()
        self._drag_row = self.indexAt(self._press_position).row()
        self._reordering = False
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if not (event.buttons() & Qt.MouseButton.LeftButton) or self._drag_row < 0 or self._press_position is None:
            super().mouseMoveEvent(event)
            return
        if not self._reordering:
            distance = (event.position().toPoint() - self._press_position).manhattanLength()
            if distance < QApplication.startDragDistance():
                return
            self._reordering = True
            self.drag_started.emit()
            self.viewport().setCursor(Qt.CursorShape.ClosedHandCursor)
        position = event.position().toPoint()
        edge = 34
        if position.y() < edge:
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() - 24)
        elif position.y() > self.viewport().height() - edge:
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() + 24)

        hovered = self.indexAt(position)
        target = hovered.row() if hovered.isValid() else self._drag_row
        if target != self._drag_row:
            item = self.takeItem(self._drag_row)
            self.insertItem(target, item)
            item.setSelected(True)
            self._drag_row = target
            self.order_changed.emit()
        event.accept()

    def mouseReleaseEvent(self, event) -> None:
        was_reordering = self._reordering
        self._press_position = None
        self._drag_row = -1
        self._reordering = False
        self.viewport().unsetCursor()
        if was_reordering:
            self.order_changed.emit()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    @staticmethod
    def _project_paths(event) -> list[str]:
        if not event.mimeData().hasUrls():
            return []
        supported = {".ltxd", ".json"}
        return [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile() and Path(url.toLocalFile()).is_file() and Path(url.toLocalFile()).suffix.casefold() in supported]

    def _set_drop_active(self, active: bool) -> None:
        self.setProperty("dropActive", active)
        self.style().unpolish(self)
        self.style().polish(self)

    def dragEnterEvent(self, event) -> None:
        if self._project_paths(event):
            self._set_drop_active(True)
            event.acceptProposedAction()
            return
        event.ignore()

    def dragMoveEvent(self, event) -> None:
        if self._project_paths(event):
            event.acceptProposedAction()
            return
        event.ignore()

    def dragLeaveEvent(self, event) -> None:
        self._set_drop_active(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event) -> None:
        paths = self._project_paths(event)
        self._set_drop_active(False)
        if paths:
            self.files_dropped.emit(paths)
            event.acceptProposedAction()
            return
        event.ignore()


class ProjectTileDelegate(QStyledItemDelegate):
    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index) -> None:
        color_value = str(index.data(PROJECT_CARD_COLOR_ROLE) or "")
        border = QColor(color_value).lighter(125) if color_value else QColor("#3b464b")
        card = option.rect.adjusted(4, 4, -4, -4)
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        fill = QColor(color_value).darker(150) if color_value else QColor("#22282b")
        painter.setBrush(fill)
        painter.setPen(QPen(border, 2 if color_value else 1))
        painter.drawRoundedRect(card, 7, 7)
        if option.state & QStyle.StateFlag.State_Selected:
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(QColor("#d9eefb"), 1))
            painter.drawRoundedRect(card.adjusted(3, 3, -3, -3), 5, 5)
        painter.restore()
        clean = QStyleOptionViewItem(option)
        clean.state &= ~QStyle.StateFlag.State_Selected
        clean.state &= ~QStyle.StateFlag.State_MouseOver
        clean.state &= ~QStyle.StateFlag.State_HasFocus
        clean.backgroundBrush = QBrush(Qt.BrushStyle.NoBrush)
        super().paint(painter, clean, index)


class SeekSlider(QSlider):
    """A normal slider that also seeks directly to a clicked groove position."""

    seek_requested = Signal(int)

    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent)
        self.sliderMoved.connect(self.seek_requested.emit)
        self.sliderReleased.connect(lambda: self.seek_requested.emit(self.value()))

    def mousePressEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton or self.orientation() != Qt.Orientation.Horizontal:
            super().mousePressEvent(event)
            return

        option = QStyleOptionSlider()
        self.initStyleOption(option)
        handle = self.style().subControlRect(
            QStyle.ComplexControl.CC_Slider,
            option,
            QStyle.SubControl.SC_SliderHandle,
            self,
        )
        if handle.contains(event.position().toPoint()):
            super().mousePressEvent(event)
            return

        span = max(1, self.width() - handle.width())
        click_position = round(event.position().x() - handle.width() / 2)
        value = QStyle.sliderValueFromPosition(
            self.minimum(),
            self.maximum(),
            max(0, min(span, click_position)),
            span,
            option.upsideDown,
        )
        self.setValue(value)
        self.seek_requested.emit(value)
        event.accept()


class ProjectVideoWidget(QVideoWidget):
    video_dropped = Signal(str)
    drag_active_changed = Signal(bool)
    play_requested = Signal()
    fullscreen_requested = Signal()
    export_frame_requested = Signal()
    copy_frame_requested = Signal()

    VIDEO_SUFFIXES = {".mp4", ".webm", ".mov", ".mkv", ".avi", ".m4v"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setMinimumSize(320, 180)

    def mouseDoubleClickEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.fullscreen_requested.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def contextMenuEvent(self, event) -> None:
        menu = QMenu(self)
        export_frame = menu.addAction("Export Current Frame…")
        copy_frame = menu.addAction("Copy Current Frame to Clipboard")
        selected = menu.exec(event.globalPos())
        if selected == export_frame:
            self.export_frame_requested.emit()
        elif selected == copy_frame:
            self.copy_frame_requested.emit()
        event.accept()

    def dragEnterEvent(self, event) -> None:
        urls = event.mimeData().urls() if event.mimeData().hasUrls() else []
        if len(urls) == 1 and urls[0].isLocalFile() and Path(urls[0].toLocalFile()).suffix.lower() in self.VIDEO_SUFFIXES:
            self.drag_active_changed.emit(True)
            event.acceptProposedAction()
            return
        event.ignore()

    def dragMoveEvent(self, event) -> None:
        self.dragEnterEvent(event)

    def dragLeaveEvent(self, event) -> None:
        self.drag_active_changed.emit(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event) -> None:
        self.drag_active_changed.emit(False)
        path = event.mimeData().urls()[0].toLocalFile()
        self.video_dropped.emit(path)
        event.acceptProposedAction()


class WorkflowDropList(QListWidget):
    files_dropped = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    @staticmethod
    def _json_paths(event) -> list[str]:
        if not event.mimeData().hasUrls():
            return []
        return [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile() and Path(url.toLocalFile()).is_file()]

    def _set_drop_active(self, active: bool) -> None:
        self.setProperty("dropActive", active)
        self.style().unpolish(self)
        self.style().polish(self)

    def dragEnterEvent(self, event) -> None:
        if self._json_paths(event):
            self._set_drop_active(True)
            event.acceptProposedAction()
            return
        event.ignore()

    def dragMoveEvent(self, event) -> None:
        if self._json_paths(event):
            event.acceptProposedAction()
            return
        event.ignore()

    def dragLeaveEvent(self, event) -> None:
        self._set_drop_active(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event) -> None:
        paths = self._json_paths(event)
        self._set_drop_active(False)
        if paths:
            self.files_dropped.emit(paths)
            event.acceptProposedAction()
            return
        event.ignore()


class ProjectFilesPanel(QWidget):
    add_requested = Signal()
    file_dropped = Signal(str)
    export_requested = Signal()
    remove_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("projectFilesPanel")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(5)
        self.title = QLabel("No saved project selected")
        self.title.setObjectName("previewTitle")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.files = WorkflowDropList()
        self.files.setObjectName("projectWorkflowList")
        self.files.files_dropped.connect(self.files_dropped)
        controls = QHBoxLayout()
        self.add_button = QPushButton("Add Files…")
        self.add_button.clicked.connect(self.add_requested)
        self.export_button = QPushButton("Export")
        self.export_button.clicked.connect(self.export_requested)
        self.remove_button = QPushButton("Remove")
        self.remove_button.clicked.connect(self.remove_requested)
        controls.addWidget(self.add_button)
        controls.addWidget(self.export_button)
        controls.addWidget(self.remove_button)
        layout.addWidget(self.title)
        layout.addWidget(self.files, 1)
        layout.addLayout(controls)
        self.files.currentRowChanged.connect(self.selection_changed)
        self.clear_project()

    def files_dropped(self, paths: list[str]) -> None:
        for path in paths:
            self.file_dropped.emit(path)

    def selection_changed(self, row: int) -> None:
        enabled = row >= 0
        self.export_button.setEnabled(enabled)
        self.remove_button.setEnabled(enabled)

    def selected_file(self) -> dict | None:
        item = self.files.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def set_project(self, name: str, project_files: list[dict] | None = None) -> None:
        self.title.setText(name)
        self.add_button.setEnabled(True)
        self.files.clear()
        for project_file in project_files or []:
            item = QListWidgetItem(str(project_file.get("name") or Path(str(project_file.get("path", ""))).name))
            item.setData(Qt.ItemDataRole.UserRole, project_file)
            self.files.addItem(item)
        self.files.setCurrentRow(0 if self.files.count() else -1)
        self.selection_changed(self.files.currentRow())

    def clear_project(self) -> None:
        self.title.setText("No saved project selected")
        self.add_button.setEnabled(False)
        self.files.clear()
        self.selection_changed(-1)


class FullscreenVideoDialog(QDialog):
    def __init__(self, player: QMediaPlayer, parent=None):
        super().__init__(parent)
        self.player = player
        self.setWindowTitle("Project Video Preview")
        self.setModal(False)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.video = ProjectVideoWidget(self)
        layout.addWidget(self.video, 1)
        controls = QFrame()
        controls.setObjectName("fullscreenPlayerControls")
        controls_layout = QHBoxLayout(controls)
        controls_layout.setContentsMargins(12, 8, 12, 8)
        self.play = QPushButton("▶ Play")
        self.play.clicked.connect(self.toggle_playback)
        self.seek = SeekSlider(Qt.Orientation.Horizontal)
        self.seek.seek_requested.connect(self.seek_to)
        self.position = QLabel("00:00 / 00:00")
        exit_button = QPushButton("✕ Exit Fullscreen")
        exit_button.clicked.connect(self.reject)
        controls_layout.addWidget(self.play)
        controls_layout.addWidget(self.seek, 1)
        controls_layout.addWidget(self.position)
        controls_layout.addWidget(exit_button)
        layout.addWidget(controls)

    def toggle_playback(self) -> None:
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def seek_to(self, position: int) -> None:
        self.player.setPosition(max(0, min(position, self.player.duration())))

    def update_position(self, position: int, duration: int) -> None:
        if not self.seek.isSliderDown():
            self.seek.setValue(position)
        self.position.setText(f"{ProjectPreviewPanel.time_text(position)} / {ProjectPreviewPanel.time_text(duration)}")


class ProjectPreviewPanel(QWidget):
    video_dropped = Signal(str)
    choose_requested = Signal()
    export_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("projectPreviewPanel")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setProperty("dropActive", False)
        self.setAcceptDrops(True)
        self.duration = 0
        self._source_generation = 0
        self.current_frame = None
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.audio.setMuted(False)
        self.audio.setVolume(1.0)
        self.player.setAudioOutput(self.audio)
        self.video = ProjectVideoWidget(self)
        self.fullscreen_window = FullscreenVideoDialog(self.player, self)
        self.fullscreen_window.finished.connect(self.restore_embedded_video)
        self.player.setVideoOutput(self.video)
        self.video.video_dropped.connect(self.video_dropped)
        self.video.drag_active_changed.connect(self.set_drop_active)
        self.video.play_requested.connect(self.toggle_playback)
        self.video.fullscreen_requested.connect(self.open_fullscreen)
        for video_output in (self.video, self.fullscreen_window.video):
            video_output.export_frame_requested.connect(self.export_current_frame)
            video_output.copy_frame_requested.connect(self.copy_current_frame)
            video_output.videoSink().videoFrameChanged.connect(self.capture_frame)
        self.fullscreen_window.video.fullscreen_requested.connect(self.fullscreen_window.reject)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(5)
        self.title = QLabel("No saved project selected")
        self.title.setObjectName("previewTitle")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty = QLabel("Save or open a project, then drop a rendered video here")
        self.empty.setObjectName("previewEmpty")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setWordWrap(True)
        video_stack = QVBoxLayout()
        video_stack.setContentsMargins(0, 0, 0, 0)
        video_stack.addWidget(self.video, 1)
        video_stack.addWidget(self.empty)
        layout.addWidget(self.title)
        layout.addLayout(video_stack, 1)
        seek_row = QHBoxLayout()
        self.position = QLabel("00:00 / 00:00")
        self.seek = SeekSlider(Qt.Orientation.Horizontal)
        self.seek.setRange(0, 0)
        self.seek.seek_requested.connect(self.seek_to)
        seek_row.addWidget(self.seek, 1)
        seek_row.addWidget(self.position)
        layout.addLayout(seek_row)
        controls = QHBoxLayout()
        self.play = QPushButton("▶ Play")
        self.play.clicked.connect(self.toggle_playback)
        self.choose = QPushButton("Add Video…")
        self.choose.clicked.connect(self.choose_requested)
        self.export = QPushButton("Export Video…")
        self.export.clicked.connect(self.export_requested)
        self.fullscreen = QPushButton("⛶ Fullscreen")
        self.fullscreen.clicked.connect(self.open_fullscreen)
        controls.addWidget(self.play)
        controls.addWidget(self.choose)
        controls.addWidget(self.export)
        controls.addWidget(self.fullscreen)
        layout.addLayout(controls)
        self.player.positionChanged.connect(self.position_changed)
        self.player.durationChanged.connect(self.duration_changed)
        self.player.playbackStateChanged.connect(self.playback_changed)
        self.player.mediaStatusChanged.connect(self.media_status_changed)
        self.player.errorOccurred.connect(self.media_error)
        self.clear_project()

    def capture_frame(self, frame) -> None:
        image = frame.toImage()
        if not image.isNull():
            self.current_frame = image.copy()

    def frame_available(self) -> bool:
        if self.current_frame is not None and not self.current_frame.isNull():
            return True
        QMessageBox.information(self, "Video Frame", "No video frame is available yet.")
        return False

    def export_current_frame(self) -> None:
        if not self.frame_available():
            return
        source = Path(self.player.source().toLocalFile())
        stem = source.stem or "video"
        suggested = f"{stem}_{self.player.position():010d}ms.png"
        owner = self.window()
        while owner is not None and not hasattr(owner, "next_export_path"):
            owner = owner.parent()
        if owner is None:
            return
        path = owner.next_export_path(suggested)
        if not self.current_frame.save(str(path)):
            owner._reserved_exports.discard(str(path))
            QMessageBox.warning(self, "Export Current Frame", "The current frame could not be saved.")
            return
        owner.record_export(path)
        self.show_player_message(f"Exported frame to {path.name}")

    def copy_current_frame(self) -> None:
        if not self.frame_available():
            return
        QApplication.clipboard().setImage(self.current_frame)
        self.show_player_message("Copied current frame to the clipboard")

    def show_player_message(self, message: str) -> None:
        window = self.window()
        if isinstance(window, QMainWindow):
            window.statusBar().showMessage(message, 3500)

    def dragEnterEvent(self, event) -> None:
        urls = event.mimeData().urls() if event.mimeData().hasUrls() else []
        if self.choose.isEnabled() and len(urls) == 1 and urls[0].isLocalFile() and Path(urls[0].toLocalFile()).suffix.lower() in ProjectVideoWidget.VIDEO_SUFFIXES:
            self.set_drop_active(True)
            event.acceptProposedAction()
            return
        event.ignore()

    def dragMoveEvent(self, event) -> None:
        self.dragEnterEvent(event)

    def dragLeaveEvent(self, event) -> None:
        self.set_drop_active(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event) -> None:
        self.set_drop_active(False)
        self.video_dropped.emit(event.mimeData().urls()[0].toLocalFile())
        event.acceptProposedAction()

    def set_drop_active(self, active: bool) -> None:
        self.setProperty("dropActive", active)
        self.style().unpolish(self)
        self.style().polish(self)

    @staticmethod
    def time_text(milliseconds: int) -> str:
        total = max(0, int(milliseconds) // 1000)
        return f"{total // 60:02d}:{total % 60:02d}"

    def set_project(self, name: str, video_path: str = "") -> None:
        self.title.setText(name)
        self.choose.setEnabled(True)
        self.pending_preview_path = video_path
        path = Path(video_path)
        try:
            valid_preview = path.is_file() and path.suffix.casefold() in ProjectVideoWidget.VIDEO_SUFFIXES and path.stat().st_size > 0
        except OSError:
            valid_preview = False
        current_path = Path(self.player.source().toLocalFile()) if self.player.source().isLocalFile() else None
        same_preview = False
        if valid_preview and current_path:
            try:
                same_preview = current_path.resolve() == path.resolve()
            except OSError:
                same_preview = False
        if same_preview:
            self.player.setAudioOutput(self.audio)
            self.export.setEnabled(True)
            self.fullscreen.setEnabled(self.duration > 0)
            if self.duration > 0:
                self.empty.hide()
                self.video.show()
            return

        self._source_generation += 1
        generation = self._source_generation
        self.player.stop()
        self.current_frame = None
        self.player.setSource(QUrl())
        if valid_preview:
            self.video.hide()
            self.empty.setText("Loading saved video preview…")
            self.empty.show()
            self.export.setEnabled(True)
            self.fullscreen.setEnabled(False)
            if self.isVisible():
                QTimer.singleShot(0, lambda p=str(path), token=generation: self.load_project_video(p, token))
            else:
                self.empty.setText("Saved video preview loads when this panel opens")
        else:
            self.video.hide()
            self.empty.setText("Drop a rendered video here\nor use Add Video")
            self.empty.show()
            self.export.setEnabled(False)
            self.fullscreen.setEnabled(False)

    def load_project_video(self, path: str, generation: int) -> None:
        """Activate saved preview media only after project/timeline loading has returned."""
        if generation != self._source_generation or not self.isVisible():
            return
        source = Path(path)
        if not source.is_file() or source.suffix.casefold() not in ProjectVideoWidget.VIDEO_SUFFIXES:
            self.media_error()
            return
        self.player.setAudioOutput(self.audio)
        self.player.setSource(QUrl.fromLocalFile(str(source)))

    def set_preview_visible(self, visible: bool) -> None:
        if visible:
            pending = getattr(self, "pending_preview_path", "")
            if pending and Path(pending).is_file() and not self.player.source().isLocalFile():
                QTimer.singleShot(0, lambda p=pending, token=self._source_generation: self.load_project_video(p, token))
        else:
            self._source_generation += 1
            self.player.stop()
            self.player.setSource(QUrl())
            self.current_frame = None

    def media_error(self, *_args) -> None:
        self.player.stop()
        self.current_frame = None
        self.player.setSource(QUrl())
        self.video.hide()
        self.empty.setText("Saved video preview could not be loaded\nDrop a replacement video here")
        self.empty.show()
        self.export.setEnabled(False)
        self.fullscreen.setEnabled(False)

    def clear_project(self) -> None:
        self._source_generation += 1
        self.player.stop()
        self.current_frame = None
        self.player.setSource(QUrl())
        self.title.setText("No saved project selected")
        self.video.hide()
        self.empty.setText("Save or open a project, then drop a rendered video here")
        self.empty.show()
        self.choose.setEnabled(False)
        self.export.setEnabled(False)
        self.fullscreen.setEnabled(False)
        self.seek.setRange(0, 0)
        self.position.setText("00:00 / 00:00")

    def toggle_playback(self) -> None:
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def seek_to(self, position: int) -> None:
        if self.duration > 0:
            self.player.setPosition(max(0, min(position, self.duration)))

    def duration_changed(self, duration: int) -> None:
        self.duration = max(0, duration)
        self.seek.setRange(0, self.duration)
        self.fullscreen_window.seek.setRange(0, self.duration)
        self.position_changed(self.player.position())

    def media_status_changed(self, status) -> None:
        if status in {QMediaPlayer.MediaStatus.LoadedMedia, QMediaPlayer.MediaStatus.BufferedMedia} and self.player.position() == 0:
            self.empty.hide()
            self.video.show()
            self.fullscreen.setEnabled(True)
            self.player.setPosition(1)
            self.player.pause()

    def position_changed(self, position: int) -> None:
        if not self.seek.isSliderDown():
            self.seek.setValue(position)
        self.position.setText(f"{self.time_text(position)} / {self.time_text(self.duration)}")
        self.fullscreen_window.update_position(position, self.duration)

    def playback_changed(self, state) -> None:
        playing = state == QMediaPlayer.PlaybackState.PlayingState
        self.play.setText("❚❚ Pause" if playing else "▶ Play")
        self.fullscreen_window.play.setText("❚❚ Pause" if playing else "▶ Play")

    def fullscreen_changed(self, fullscreen: bool) -> None:
        self.fullscreen.setText("Exit Fullscreen" if fullscreen else "⛶ Fullscreen")

    def open_fullscreen(self) -> None:
        if self.fullscreen_window.isVisible():
            self.fullscreen_window.reject()
            return
        self.player.setVideoOutput(self.fullscreen_window.video)
        self.fullscreen_window.showFullScreen()
        self.fullscreen_changed(True)

    def restore_embedded_video(self, *_args) -> None:
        position = self.player.position()
        self.player.setVideoOutput(self.video)
        self.player.setPosition(position)
        self.fullscreen_changed(False)

class MagicSpinner(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.angle = 0
        self.scale_factor = 1.0
        self.set_scale(1.0)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.advance)
        self.timer.start(45)

    def advance(self) -> None:
        self.angle = (self.angle + 8) % 360
        self.update()

    def set_scale(self, scale: float) -> None:
        self.scale_factor = max(.75, min(2.0, scale))
        side = round(150 * self.scale_factor)
        self.setFixedSize(side, side)
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        scale = self.scale_factor
        center = self.rect().center()
        painter.translate(center)
        painter.rotate(self.angle)
        for index in range(10):
            painter.save()
            painter.rotate(index * 36)
            alpha = 55 + index * 20
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(90, 176, 235, min(255, alpha)))
            painter.drawEllipse(QRectF(-4 * scale, -61 * scale, 8 * scale, 18 * scale))
            painter.restore()
        painter.rotate(-self.angle)
        painter.setPen(QPen(QColor("#d9efff"), 3 * scale))
        painter.setBrush(QColor("#27343c"))
        painter.drawRoundedRect(QRectF(-31 * scale, -23 * scale, 62 * scale, 46 * scale), 8 * scale, 8 * scale)
        painter.setPen(QPen(QColor("#79c8ff"), 2 * scale))
        for x in (-19, 0, 19):
            painter.drawLine(round(x * scale), round(-16 * scale), round((x + 8) * scale), round(-6 * scale))
            painter.drawLine(round((x + 8) * scale), round(-6 * scale), round(x * scale), round(4 * scale))
        painter.setPen(QColor("#fff2a8"))
        painter.setFont(self.font())
        painter.drawText(QRectF(-30 * scale, 6 * scale, 60 * scale, 15 * scale), Qt.AlignmentFlag.AlignCenter, "DIRECTING")


class MagicBuildOverlay(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("magicOverlay")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setStyleSheet("#magicOverlay{background:rgba(5,8,10,205)} #magicOverlayPanel{background:#20282c;border:2px solid #4f83ae;border-radius:12px}")
        layout = QVBoxLayout(self)
        self.panel = QFrame(self)
        self.panel.setObjectName("magicOverlayPanel")
        self.panel_layout = QVBoxLayout(self.panel)
        self.panel_layout.addStretch()
        self.spinner = MagicSpinner(self.panel)
        self.spinner.timer.stop()
        self.panel_layout.addWidget(self.spinner, 0, Qt.AlignmentFlag.AlignCenter)
        self.title = QLabel("✦ Magic Build is directing your sequence")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title.setObjectName("magicOverlayTitle")
        self.detail = QLabel("Analyzing frames and directing motion…")
        self.detail.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.detail.setWordWrap(True)
        self.attempt = QLabel("")
        self.attempt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.attempt.setObjectName("muted")
        self.panel_layout.addWidget(self.title)
        self.panel_layout.addWidget(self.detail)
        self.panel_layout.addWidget(self.attempt)
        self.panel_layout.addStretch()
        layout.addWidget(self.panel, 0, Qt.AlignmentFlag.AlignCenter)
        scale = parent.settings.value("ui_text_scale", 100, int) / 100 if parent and hasattr(parent, "settings") else 1.0
        self.set_scale(scale)
        self.hide()

    def set_scale(self, scale: float) -> None:
        scale = max(.75, min(2.0, scale))
        self.panel.setFixedSize(round(390 * scale), round(290 * scale))
        self.panel_layout.setContentsMargins(round(28 * scale), round(20 * scale), round(28 * scale), round(24 * scale))
        self.spinner.set_scale(scale)

    def update_attempt(self, current: int, total: int, detail: str) -> None:
        self.detail.setText(detail)
        self.attempt.setText(f"Attempt {current} of {total}" if total > 1 else "")

    def show_overlay(self) -> None:
        self.setGeometry(self.parentWidget().rect())
        self.raise_()
        self.spinner.timer.start(45)
        self.show()
        self.setFocus(Qt.FocusReason.ActiveWindowFocusReason)
        self.grabKeyboard()

    def hide_overlay(self) -> None:
        self.releaseKeyboard()
        self.spinner.timer.stop()
        self.hide()

    def mousePressEvent(self, event) -> None:
        event.accept()

    def keyPressEvent(self, event) -> None:
        event.accept()


class TileLoadingSpinner(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.phase = 0
        self.scale_factor = 1.0
        self.set_scale(1.0)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.advance)

    def set_scale(self, scale: float) -> None:
        self.scale_factor = max(.75, min(2.0, scale))
        self.setFixedSize(round(104 * self.scale_factor), round(58 * self.scale_factor))
        self.update()

    def advance(self) -> None:
        self.phase = (self.phase + 1) % 12
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        scale = self.scale_factor
        active = (self.phase // 4) % 3
        for index, x in enumerate((4, 38, 72)):
            lift = -4 if index == active else 0
            rect = QRectF(x * scale, (10 + lift) * scale, 28 * scale, 38 * scale)
            painter.setPen(QPen(QColor("#9edaff") if index == active else QColor("#56646c"), 2 * scale))
            painter.setBrush(QColor("#315f7b") if index == active else QColor("#252d31"))
            painter.drawRoundedRect(rect, 4 * scale, 4 * scale)
            painter.setPen(QPen(QColor("#d8f1ff") if index == active else QColor("#78868d"), 2 * scale))
            painter.drawLine(round((x + 6) * scale), round((37 + lift) * scale), round((x + 13) * scale), round((29 + lift) * scale))
            painter.drawLine(round((x + 13) * scale), round((29 + lift) * scale), round((x + 22) * scale), round((39 + lift) * scale))
            painter.drawEllipse(QRectF((x + 18) * scale, (17 + lift) * scale, 4 * scale, 4 * scale))


class TimelineLoadingOverlay(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("background:rgba(9,13,15,220);color:#d9efff")
        layout = QVBoxLayout(self)
        layout.addStretch()
        self.spinner = TileLoadingSpinner(self)
        layout.addWidget(self.spinner, 0, Qt.AlignmentFlag.AlignCenter)
        label = QLabel("Loading timeline tiles…")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setStyleSheet("font-weight:bold;color:#d9efff")
        layout.addWidget(label)
        layout.addStretch()
        self.hide()

    def set_scale(self, scale: float) -> None:
        self.spinner.set_scale(scale)

    def show_loading(self) -> None:
        self.setGeometry(self.parentWidget().rect())
        self.raise_()
        self.spinner.timer.start(80)
        self.show()

    def hide_loading(self) -> None:
        self.spinner.timer.stop()
        self.hide()


class TimelineRuler(QWidget):
    def __init__(self):
        super().__init__()
        self.offset = 0
        self.scale = 65
        self.setFixedHeight(28)

    def set_offset(self, value: int) -> None:
        self.offset = value
        self.update()

    def set_scale(self, value: float) -> None:
        self.scale = max(0.000001, float(value))
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#17191a"))
        painter.setFont(self.font())
        scale = max(0.000001, float(self.scale))
        visible_start = max(0.0, (self.offset - 30) / scale)
        visible_end = max(0.0, (self.offset + self.width() + 30) / scale)
        label_width = painter.fontMetrics().horizontalAdvance(f"{math.ceil(visible_end)}.00") + 8
        minimum_interval = max(1, math.ceil(label_width / scale))
        magnitude = 10 ** math.floor(math.log10(minimum_interval))
        label_interval = next(step * magnitude for step in (1, 2, 5, 10) if step * magnitude >= minimum_interval)
        first_second = max(0, math.floor(visible_start / label_interval) * label_interval)
        for second in range(first_second, math.ceil(visible_end) + label_interval, label_interval):
            x = round(second * scale - self.offset)
            painter.setPen(QPen(QColor("#303538")))
            painter.drawLine(x, 12, x, 24)
            painter.setPen(QColor("#ff5757") if second == 0 else QColor("#788186"))
            painter.drawText(x + 4, 16, "0" if second == 0 else f"{second}.00")


class ResizeHandle(QFrame):
    preview = Signal(float)
    finished = Signal()

    def __init__(self, duration: float, pixels_per_second: int):
        super().__init__()
        self.duration = duration
        self.start_duration = duration
        self.start_x: float | None = None
        self.pixels_per_second = pixels_per_second
        self.setObjectName("resizeHandle")
        # Keep a comfortable hit target while drawing only a slim dotted grip.
        self.setFixedWidth(12)
        self.setCursor(Qt.CursorShape.SizeHorCursor)
        self.setToolTip("Drag to resize segment")

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        active = self.start_x is not None
        color = QColor("#b9e7ff") if active else QColor("#84aabd") if self.underMouse() else QColor("#52636c")
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(color)
        diameter = 3.0
        spacing = 7.0
        center_x = self.width() / 2
        center_y = self.height() / 2
        for index in range(-3, 4):
            painter.drawEllipse(QRectF(center_x - diameter / 2, center_y + index * spacing - diameter / 2, diameter, diameter))

    def enterEvent(self, event) -> None:
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.start_x = event.globalPosition().x()
            self.start_duration = self.duration
            self.grabMouse()
            self.update()
            event.accept()

    def mouseMoveEvent(self, event):
        if self.start_x is not None:
            value = max(MIN_DURATION, round(self.start_duration + (event.globalPosition().x() - self.start_x) / self.pixels_per_second, 2))
            if value != self.duration:
                self.duration = value
                self.preview.emit(value)
            event.accept()

    def mouseReleaseEvent(self, event):
        if self.start_x is not None:
            self.start_x = None
            self.releaseMouse()
            self.update()
            self.finished.emit()
            event.accept()


class TimelineHeightHandle(QFrame):
    height_changed = Signal(int)
    finished = Signal()

    def __init__(self, current_height: int):
        super().__init__()
        self.current_height = current_height
        self.start_height = current_height
        self.start_y: float | None = None
        self.scale_factor = 1.0
        self.setObjectName("timelineHeightHandle")
        self.set_scale(1.0)
        self.setCursor(Qt.CursorShape.SizeVerCursor)
        self.setToolTip("Drag down to enlarge timeline previews")

    def set_scale(self, scale: float) -> None:
        self.scale_factor = max(.75, min(2.0, scale))
        self.setFixedHeight(round(14 * self.scale_factor))
        self.update()

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        active = self.start_y is not None
        color = QColor("#9fd8fa") if active else QColor("#71838d") if self.underMouse() else QColor("#4f5c63")
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(color)
        diameter = max(3.0, 3.2 * self.scale_factor)
        spacing = 8 * self.scale_factor
        center_x = self.width() / 2
        center_y = self.height() / 2
        for index in range(-3, 4):
            painter.drawEllipse(QRectF(center_x + index * spacing - diameter / 2, center_y - diameter / 2, diameter, diameter))

    def enterEvent(self, event) -> None:
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.start_y = event.globalPosition().y()
            self.start_height = self.current_height
            self.grabMouse()
            self.update()
            event.accept()

    def mouseMoveEvent(self, event):
        if self.start_y is not None:
            value = max(184, min(430, int(self.start_height + event.globalPosition().y() - self.start_y)))
            self.current_height = value
            self.height_changed.emit(value)
            event.accept()

    def mouseReleaseEvent(self, event):
        if self.start_y is not None:
            self.start_y = None
            self.releaseMouse()
            self.update()
            self.finished.emit()
            event.accept()


class SegmentCard(QFrame):
    duration_changed = Signal(float)
    delete_requested = Signal()
    resize_finished = Signal()

    def __init__(self, segment: Segment, start_time: float, preview_height: int, pixels_per_second: int):
        super().__init__()
        self.segment = segment
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setObjectName("segmentCard")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.outer_layout = QHBoxLayout(self)
        self.outer_layout.setContentsMargins(0, 0, 0, 0)
        self.outer_layout.setSpacing(0)
        self.content = QWidget()
        self.content.setObjectName("segmentCardBody")
        self.content.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.content.setCursor(Qt.CursorShape.OpenHandCursor)
        layout = QVBoxLayout(self.content)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(1)
        badges = QHBoxLayout()
        badges.setContentsMargins(0, 0, 0, 0)
        kind = QLabel(segment_kind_label(segment))
        kind.setObjectName("mediaBadge")
        self.role_badge = QLabel("PROMPT" if segment.kind == "text" else segment.role.upper())
        self.role_badge.setObjectName("roleBadge")
        close = QPushButton("×")
        close.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)
        close.setObjectName("tileDelete")
        close.setFixedSize(20, 20)
        close.setCursor(Qt.CursorShape.ArrowCursor)
        close.clicked.connect(self.delete_requested)
        badges.addWidget(kind)
        badges.addStretch()
        badges.addWidget(self.role_badge)
        badges.addWidget(close)
        layout.addLayout(badges)
        self.preview = QLabel()
        self.preview.setObjectName("segmentPreview")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.source_pixmap = timeline_preview_pixmap(segment.preview_path)
        self.resolution_badge = QLabel(self.preview)
        self.resolution_badge.setObjectName("resolutionPill")
        self.resolution_badge.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.resolution_badge.setStyleSheet(
            "background:rgba(20,25,28,220);color:#e3f4ff;border:1px solid #668594;"
            "border-radius:8px;padding:2px 6px;font-size:9px;font-weight:bold"
        )
        resolution_source = segment.media_path if segment.kind == "image" else segment.preview_path
        resolution = QImageReader(resolution_source).size() if segment.kind in {"image", "video"} and resolution_source and Path(resolution_source).is_file() else QSize()
        if segment.kind == "video":
            original_size = video_source_dimensions(segment.media_path) or getattr(segment, "_source_size", None)
            if original_size:
                resolution = QSize(*original_size)
        elif segment.kind == "image" and not resolution.isValid() and getattr(segment, "_source_size", None):
            resolution = QSize(*segment._source_size)
        if resolution.isValid():
            self.resolution_badge.setText(f"{resolution.width()} × {resolution.height()}")
            self.resolution_badge.adjustSize()
            self.resolution_badge.show()
        else:
            self.resolution_badge.hide()
        if segment.kind == "text":
            self.preview.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
            self.preview.setMargin(8)
            self.preview.setWordWrap(True)
            self.set_text_preview(segment.prompt)
        layout.addWidget(self.preview, 1)
        title = QLabel(segment.name if segment.kind == "text" else (segment.prompt or segment.name))
        title.setToolTip(segment.name)
        title.setWordWrap(False)
        title.setObjectName("tileTitle")
        layout.addWidget(title)
        timing = QHBoxLayout()
        timing.setContentsMargins(0, 0, 0, 0)
        self.start_time_label = QLabel()
        self.start_time_label.setObjectName("tileStartTime")
        self.set_start_time(start_time)
        timing.addWidget(self.start_time_label)
        timing.addStretch()
        self.duration_label = QLabel(f"{segment.duration:.2f}s")
        self.duration_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.duration_label.setObjectName("tileDuration")
        timing.addWidget(self.duration_label)
        layout.addLayout(timing)
        self.outer_layout.addWidget(self.content, 1)
        self.resize_handle = ResizeHandle(segment.duration, pixels_per_second)
        self.resize_handle.preview.connect(self._preview_duration)
        self.resize_handle.finished.connect(self.resize_finished)
        self.outer_layout.addWidget(self.resize_handle)
        self.update_layout(preview_height, pixels_per_second)

    def set_timeline_edges(self, first: bool, last: bool) -> None:
        self.outer_layout.setContentsMargins(0 if first else 1, 0, 0 if last else 1, 0)

    def set_role(self, role: str) -> None:
        """Update the visible role without recreating the timeline card."""
        if self.segment.kind == "text":
            return
        self.segment.role = role
        self.role_badge.setText(role.upper())

    def set_start_time(self, value: float) -> None:
        self.start_time_label.setText(f"START {max(0.0, value):.2f}s")

    def set_text_preview(self, text: str) -> None:
        if self.segment.kind == "text":
            self.preview.setText(text or "Enter text prompt…")

    def update_layout(self, preview_height: int, pixels_per_second: int) -> None:
        height = max(80, preview_height)
        width = max(36, int(self.segment.duration * pixels_per_second) - 14)
        self.preview.setMinimumHeight(height)
        if not self.source_pixmap.isNull():
            scaled = self.source_pixmap.scaled(
                width, height, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            self.preview.setPixmap(scaled)
        self.resize_handle.pixels_per_second = pixels_per_second
        self.resize_handle.duration = self.segment.duration
        self.duration_label.setText(f"{self.segment.duration:.2f}s")
        self.position_resolution_badge()

    def position_resolution_badge(self) -> None:
        if self.resolution_badge.isHidden():
            return
        self.resolution_badge.adjustSize()
        self.resolution_badge.move(
            max(4, self.preview.width() - self.resolution_badge.width() - 6),
            max(4, self.preview.height() - self.resolution_badge.height() - 6),
        )
        self.resolution_badge.raise_()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.position_resolution_badge()

    def _preview_duration(self, value: float) -> None:
        self.duration_label.setText(f"{value:.2f}s")
        self.duration_changed.emit(value)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
        event.ignore()

    def mouseReleaseEvent(self, event):
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        event.ignore()


class TagEditor(QWidget):
    def __init__(self, tags: list[dict[str, str]], parent=None, allow_empty: bool = False):
        super().__init__(parent)
        self.allow_empty = allow_empty
        self.rows: list[tuple[QWidget, QLineEdit, QPushButton]] = []
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(4)
        for tag in tags:
            self.add_tag(tag["name"], tag["color"])
        self.add_button = QPushButton("+ Add tag")
        self.add_button.clicked.connect(lambda: self.add_tag("New tag", "#56616a"))
        self.layout.addWidget(self.add_button)

    @staticmethod
    def style_color_button(button: QPushButton, color: str) -> None:
        button.setProperty("tagColor", color)
        button.setStyleSheet(f"background: {color}; border: 1px solid {QColor(color).lighter(150).name()}; border-radius: 4px;")

    def add_tag(self, name: str, color: str) -> None:
        row = QWidget()
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)
        name_input = QLineEdit(name)
        color_button = QPushButton()
        color_button.setFixedWidth(42)
        color_button.setToolTip("Choose tag color")
        self.style_color_button(color_button, color)
        color_button.clicked.connect(lambda: self.choose_color(color_button))
        remove = QPushButton("×")
        remove.setFixedWidth(28)
        remove.setToolTip("Remove tag")
        remove.clicked.connect(lambda: self.remove_tag(row))
        layout.addWidget(name_input, 1)
        layout.addWidget(color_button)
        layout.addWidget(remove)
        self.rows.append((row, name_input, color_button))
        index = self.layout.count() - 1 if hasattr(self, "add_button") else self.layout.count()
        self.layout.insertWidget(max(0, index), row)

    def choose_color(self, button: QPushButton) -> None:
        selected = QColorDialog.getColor(QColor(str(button.property("tagColor"))), self, "Choose tag color")
        if selected.isValid():
            self.style_color_button(button, selected.name())

    def remove_tag(self, row: QWidget) -> None:
        self.rows = [value for value in self.rows if value[0] is not row]
        row.deleteLater()

    def tags(self) -> list[dict[str, str]]:
        result = []
        names = set()
        for _row, name_input, color_button in self.rows:
            name = name_input.text().strip()
            if not name:
                raise ValueError("Every project tag needs a name.")
            if name.casefold() in names:
                raise ValueError(f"Duplicate project tag: {name}")
            names.add(name.casefold())
            result.append({"name": name, "color": str(color_button.property("tagColor"))})
        if not result and not self.allow_empty:
            raise ValueError("Add at least one project tag.")
        return result


class SettingsDialog(QDialog):
    def __init__(self, settings: QSettings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.setWindowTitle("Application Settings")
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs)
        general = QWidget()
        form = QFormLayout(general)
        tabs.addTab(general, "Application")
        tabs.addTab(WorkspaceEditor(parent.workspace_store, parent, tabs), "Workspaces")
        self.resize(850, 760)
        self.provider = QComboBox()
        self.provider.addItems(["gemini", "openai"])
        self.provider.setCurrentText(settings.value("provider", "gemini"))
        self.model = QComboBox()
        self.model.addItems(GEMINI_MODELS)
        self.model.setCurrentText(settings.value("gemini_model", GEMINI_MODELS[0]))
        self.gemini = QLineEdit(settings.value("gemini_key", ""))
        self.openai = QLineEdit(settings.value("openai_key", ""))
        self.gemini.setEchoMode(QLineEdit.EchoMode.Password)
        self.openai.setEchoMode(QLineEdit.EchoMode.Password)
        self.remember = QCheckBox("Store API keys persistently on this computer")
        self.remember.setChecked(settings.value("remember_keys", False, bool))
        self.timeout = QSpinBox()
        self.timeout.setRange(30, 900)
        self.timeout.setSingleStep(10)
        self.timeout.setSuffix(" seconds")
        self.timeout.setValue(settings.value("api_timeout", 400, int))
        self.retries = QSpinBox()
        self.retries.setRange(0, 10)
        self.retries.setValue(settings.value("api_retries", 2, int))
        self.retries.setToolTip("Additional attempts after the initial API request")
        self.retry_cooldown = QSpinBox()
        self.retry_cooldown.setRange(0, 300)
        self.retry_cooldown.setSingleStep(5)
        self.retry_cooldown.setSuffix(" seconds")
        self.retry_cooldown.setValue(settings.value("api_retry_cooldown", 10, int))
        self.retry_cooldown.setToolTip("Time to wait before each retry; set to 0 to retry immediately")
        text_scale = settings.value("ui_text_scale", 100, int)
        self.ui_text_scale = QSlider(Qt.Orientation.Horizontal)
        self.ui_text_scale.setRange(75, 200)
        self.ui_text_scale.setSingleStep(5)
        self.ui_text_scale.setPageStep(25)
        self.ui_text_scale.setTickInterval(25)
        self.ui_text_scale.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.ui_text_scale.setValue(text_scale)
        self.ui_text_scale.setToolTip("Scale text throughout the main application window")
        self.ui_text_scale_value = QLabel(f"{text_scale}%")
        self.ui_text_scale_value.setMinimumWidth(44)
        self.ui_text_scale_value.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.ui_text_scale.valueChanged.connect(lambda value: self.ui_text_scale_value.setText(f"{value}%"))
        text_scale_row = QWidget()
        text_scale_layout = QHBoxLayout(text_scale_row)
        text_scale_layout.setContentsMargins(0, 0, 0, 0)
        text_scale_layout.addWidget(self.ui_text_scale, 1)
        text_scale_layout.addWidget(self.ui_text_scale_value)
        downloads = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation) or str(Path.home())
        self.segment_save_dir = QLineEdit(str(settings.value("segment_export_dir", settings.value("segment_save_dir", downloads))))
        self.segment_save_browse = QPushButton("Browse…")
        self.segment_save_browse.clicked.connect(self.choose_segment_save_directory)
        save_directory_row = QWidget()
        save_directory_layout = QHBoxLayout(save_directory_row)
        save_directory_layout.setContentsMargins(0, 0, 0, 0)
        save_directory_layout.addWidget(self.segment_save_dir, 1)
        save_directory_layout.addWidget(self.segment_save_browse)
        self.comfy_root_dir = QLineEdit(str(settings.value("comfy_root_dir", "")))
        self.comfy_root_dir.setPlaceholderText("Choose the ComfyUI root directory")
        self.comfy_root_browse = QPushButton("Browse…")
        self.comfy_root_browse.clicked.connect(self.choose_comfy_root_directory)
        comfy_directory_row = QWidget()
        comfy_directory_layout = QHBoxLayout(comfy_directory_row)
        comfy_directory_layout.setContentsMargins(0, 0, 0, 0)
        comfy_directory_layout.addWidget(self.comfy_root_dir, 1)
        comfy_directory_layout.addWidget(self.comfy_root_browse)
        status_value = settings.value("project_status_tags", settings.value("project_tags", ""))
        self.project_status_tags = TagEditor(load_project_tags(status_value))
        self.project_status_tags.setToolTip("A project can have one status. Its status controls the project card color.")
        self.project_other_tags = TagEditor(load_other_tags(settings.value("project_other_tags", "")), allow_empty=True)
        self.project_other_tags.setToolTip("A project can have any number of these labels. They appear as thumbnail pills.")
        form.addRow("Provider", self.provider)
        form.addRow("Gemini model", self.model)
        form.addRow("Gemini API key", self.gemini)
        form.addRow("OpenAI API key", self.openai)
        form.addRow("API timeout", self.timeout)
        form.addRow("Connection retries", self.retries)
        form.addRow("Retry cooldown", self.retry_cooldown)
        form.addRow("UI text scale (DPI)", text_scale_row)
        form.addRow("Default download folder", save_directory_row)
        form.addRow("ComfyUI working directory", comfy_directory_row)
        form.addRow("Status tags (choose one)", self.project_status_tags)
        form.addRow("Other tags (choose many)", self.project_other_tags)
        form.addRow("", self.remember)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        geometry = settings.value("dialogs/settings_geometry")
        if geometry:
            self.restoreGeometry(geometry)

    def accept(self) -> None:
        try:
            project_status_tags = self.project_status_tags.tags()
            project_other_tags = self.project_other_tags.tags()
            names = [tag["name"].casefold() for tag in project_status_tags + project_other_tags]
            if len(names) != len(set(names)) or "archive" in names:
                raise ValueError("Status and other tag names must be unique, and Archive is reserved.")
        except ValueError as error:
            QMessageBox.warning(self, "Invalid project tags", str(error))
            return
        self.settings.setValue("provider", self.provider.currentText())
        self.settings.setValue("gemini_model", self.model.currentText())
        self.settings.setValue("remember_keys", self.remember.isChecked())
        self.settings.setValue("api_timeout", self.timeout.value())
        self.settings.setValue("api_retries", self.retries.value())
        self.settings.setValue("api_retry_cooldown", self.retry_cooldown.value())
        self.settings.setValue("ui_text_scale", self.ui_text_scale.value())
        self.settings.setValue("segment_export_dir", self.segment_save_dir.text().strip())
        self.settings.setValue("comfy_root_dir", self.comfy_root_dir.text().strip())
        self.settings.setValue("project_status_tags", json.dumps(project_status_tags))
        self.settings.setValue("project_other_tags", json.dumps(project_other_tags))
        self.settings.setValue("project_tags", json.dumps(project_status_tags))
        self.settings.setValue("dialogs/settings_geometry", self.saveGeometry())
        if self.remember.isChecked():
            self.settings.setValue("gemini_key", self.gemini.text().strip())
            self.settings.setValue("openai_key", self.openai.text().strip())
        else:
            self.settings.remove("gemini_key")
            self.settings.remove("openai_key")
        self.parent().session_keys = {"gemini": self.gemini.text().strip(), "openai": self.openai.text().strip()}
        super().accept()

    def choose_segment_save_directory(self) -> None:
        selected = choose_directory(self, "Choose default download folder", self.segment_save_dir.text().strip() or str(Path.home()))
        if selected:
            self.segment_save_dir.setText(selected)

    def choose_comfy_root_directory(self) -> None:
        selected = choose_directory(self, "Choose ComfyUI root directory", self.comfy_root_dir.text().strip() or str(Path.home()))
        if selected:
            self.comfy_root_dir.setText(selected)

    def reject(self) -> None:
        self.settings.setValue("dialogs/settings_geometry", self.saveGeometry())
        super().reject()


class ProjectNoteRow(QFrame):
    edit_requested = Signal(str)
    delete_requested = Signal(str)
    checked_changed = Signal(str, bool)

    def __init__(self, note: dict, parent=None):
        super().__init__(parent)
        self.note_id = str(note["id"])
        self.setObjectName("projectNoteRow")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(7, 5, 5, 5)
        layout.setSpacing(7)
        completed = QCheckBox()
        completed.setChecked(bool(note.get("checked", False)))
        completed.setToolTip("Mark note complete")
        completed.toggled.connect(lambda checked: self.checked_changed.emit(self.note_id, checked))
        note_time = QDateTime.fromString(str(note["date"]), Qt.DateFormat.ISODate)
        stamp = QLabel(note_time.toLocalTime().toString("yyyy-MM-dd HH:mm") if note_time.isValid() else str(note["date"]).replace("T", " ")[:16])
        stamp.setObjectName("projectNoteDate")
        stamp.setFixedWidth(118)
        stamp.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        text = QLabel(str(note["text"]))
        text.setWordWrap(True)
        if note.get("checked"):
            font = text.font()
            font.setStrikeOut(True)
            text.setFont(font)
            text.setStyleSheet("color:#839097")
        text.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        remove = QPushButton("×")
        remove.setObjectName("projectNoteDelete")
        remove.setToolTip("Delete note")
        remove.setFixedSize(24, 24)
        remove.clicked.connect(lambda: self.delete_requested.emit(self.note_id))
        layout.addWidget(completed)
        layout.addWidget(stamp)
        layout.addWidget(text, 1)
        layout.addWidget(remove)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.edit_requested.emit(self.note_id)
        super().mousePressEvent(event)


class PreviewCacheDialog(QDialog):
    """On first run or after cache expiry, prepare project covers without freezing UI."""

    def __init__(self, metadata_files: list[Path], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Preparing project previews")
        self.setWindowModality(Qt.WindowModality.WindowModal)
        self.setMinimumWidth(370)
        self.files = metadata_files
        self.position = 0
        layout = QVBoxLayout(self)
        self.description = QLabel("Updating the preview cache for saved projects…")
        self.description.setWordWrap(True)
        layout.addWidget(self.description)
        self.progress = QProgressBar()
        self.progress.setRange(0, max(1, len(metadata_files)))
        self.progress.setValue(0)
        layout.addWidget(self.progress)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.advance)

    def start(self) -> None:
        self.open()
        self.timer.start(0)

    def advance(self) -> None:
        if self.position < len(self.files):
            path = self.files[self.position]
            try:
                warm_metadata(path)
            except (OSError, ValueError, TypeError):
                pass  # A broken thumbnail should not block access to the project.
            self.position += 1
            self.progress.setValue(self.position)
            self.description.setText(f"Preparing project previews: {self.position} of {len(self.files)}")
        else:
            self.timer.stop()
            mark_ready()
            self.accept()

    def reject(self) -> None:
        self.timer.stop()
        super().reject()


class ProjectDetailsDialog(QDialog):
    def __init__(self, suggested_description: str, parent=None, name: str = "", collection: str = "", collections: list[str] | None = None,
                 thumbnail_options: list[tuple[str, str]] | None = None, thumbnail_data: str = "", thumbnail_source: str = "",
                 notes: list[dict] | None = None, download_directory: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Save project to library")
        self.download_folder = QLineEdit(download_directory)
        self.download_folder.setPlaceholderText("Use the application download folder")
        self.setMinimumWidth(430)
        form = QFormLayout(self)
        self.name = QLineEdit()
        self.name.setPlaceholderText("Project name")
        self.name.setText(name)
        self.description = QTextEdit()
        install_spellcheck(self.description)
        self.description.setPlaceholderText("Short description shown in the project library")
        self.description.setPlainText(suggested_description[:240])
        self.description.setFixedHeight(90)
        self.collection = QComboBox()
        self.collection.setEditable(True)
        self.collection.addItem("No collection", "")
        for value in sorted(set(collections or []), key=str.casefold):
            self.collection.addItem(value, value)
        if collection:
            self.collection.setCurrentText(collection)
        self.thumbnail_data = thumbnail_data
        self.thumbnail_source = thumbnail_source
        self.thumbnail_options = thumbnail_options or []
        thumbnail_box = QWidget()
        thumbnail_layout = QVBoxLayout(thumbnail_box)
        thumbnail_layout.setContentsMargins(0, 0, 0, 0)
        self.thumbnail_list = QListWidget()
        self.thumbnail_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.thumbnail_list.setFlow(QListWidget.Flow.LeftToRight)
        self.thumbnail_list.setWrapping(False)
        self.thumbnail_list.setIconSize(QSize(104, 104))
        self.thumbnail_list.setFixedHeight(148)
        self.thumbnail_list.setSpacing(6)
        for index, (label, value) in enumerate(self.thumbnail_options):
            item = QListWidgetItem(QIcon(self._thumbnail_pixmap(value)), label)
            item.setData(Qt.ItemDataRole.UserRole, (f"segment:{index}", value))
            item.setSizeHint(QSize(116, 132))
            self.thumbnail_list.addItem(item)
            if self.thumbnail_source == f"segment:{index}" or (not self.thumbnail_source and index == 0):
                self.thumbnail_list.setCurrentItem(item)
        if self.thumbnail_source == "custom" and self.thumbnail_data:
            item = QListWidgetItem(QIcon(self._thumbnail_pixmap(self.thumbnail_data)), "Custom")
            item.setData(Qt.ItemDataRole.UserRole, ("custom", self.thumbnail_data))
            item.setSizeHint(QSize(116, 132))
            self.thumbnail_list.addItem(item)
            self.thumbnail_list.setCurrentItem(item)
        self.custom_thumbnail_button = QPushButton("Upload custom thumbnail…")
        self.custom_thumbnail_button.clicked.connect(self.choose_custom_thumbnail)
        thumbnail_layout.addWidget(self.thumbnail_list)
        thumbnail_layout.addWidget(self.custom_thumbnail_button)
        self.notes = normalize_notes(notes)
        self.editing_note_id = ""
        notes_box = QWidget()
        notes_layout = QVBoxLayout(notes_box)
        notes_layout.setContentsMargins(0, 0, 0, 0)
        notes_layout.setSpacing(5)
        note_entry = QHBoxLayout()
        self.note_date = QDateTimeEdit(QDateTime.currentDateTime())
        self.note_date.setCalendarPopup(True)
        self.note_date.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.note_date.setToolTip("Note date and time; editing does not change it unless you do")
        self.note_input = QLineEdit()
        self.note_input.setPlaceholderText("Type a note and press Enter…")
        self.note_input.returnPressed.connect(self.commit_note)
        add_note = QPushButton("Add")
        add_note.clicked.connect(self.commit_note)
        note_entry.addWidget(self.note_date)
        note_entry.addWidget(self.note_input, 1)
        note_entry.addWidget(add_note)
        self.notes_list = QListWidget()
        self.notes_list.setObjectName("projectNotesList")
        self.notes_list.setMinimumHeight(170)
        notes_layout.addLayout(note_entry)
        notes_layout.addWidget(self.notes_list)
        self.refresh_notes()
        form.addRow("Name", self.name)
        form.addRow("Description", self.description)
        form.addRow("Collection", self.collection)
        form.addRow("Download folder", self.download_folder)
        form.addRow("Thumbnail", thumbnail_box)
        form.addRow("Notes", notes_box)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        geometry = parent.settings.value("dialogs/project_details_geometry") if parent else None
        if geometry:
            self.restoreGeometry(geometry)

    def accept(self) -> None:
        if self.note_input.text().strip():
            self.commit_note()
        if not self.name.text().strip():
            QMessageBox.warning(self, "Project name required", "Enter a name for this project.")
            return
        self.parent().settings.setValue("dialogs/project_details_geometry", self.saveGeometry())
        super().accept()

    def reject(self) -> None:
        self.parent().settings.setValue("dialogs/project_details_geometry", self.saveGeometry())
        super().reject()

    def collection_name(self) -> str:
        value = self.collection.currentText().strip()
        return "" if value == "No collection" else value

    @staticmethod
    def _thumbnail_pixmap(value: str) -> QPixmap:
        pixmap = pixmap_from_data_url(value)
        if pixmap.isNull():
            return pixmap
        scaled = pixmap.scaled(104, 104, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
        return scaled.copy(max(0, (scaled.width() - 104) // 2), max(0, (scaled.height() - 104) // 2), 104, 104)

    def choose_custom_thumbnail(self) -> None:
        initial = self.parent().settings.value("last_media_dir", str(Path.home()))
        paths = choose_media_files(self, False, str(initial))
        if not paths:
            return
        path = paths[0]
        self.parent().settings.setValue("last_media_dir", str(Path(path).parent))
        custom_data = data_url(path, max_edge=720, quality=90)
        if not custom_data:
            QMessageBox.warning(self, "Thumbnail unavailable", "That image could not be used as a thumbnail.")
            return
        for row in range(self.thumbnail_list.count()):
            item = self.thumbnail_list.item(row)
            if (item.data(Qt.ItemDataRole.UserRole) or ("", ""))[0] == "custom":
                self.thumbnail_list.takeItem(row)
                break
        item = QListWidgetItem(QIcon(self._thumbnail_pixmap(custom_data)), "Custom")
        item.setData(Qt.ItemDataRole.UserRole, ("custom", custom_data))
        item.setSizeHint(QSize(116, 132))
        self.thumbnail_list.addItem(item)
        self.thumbnail_list.setCurrentItem(item)

    def selected_thumbnail(self) -> tuple[str, str]:
        item = self.thumbnail_list.currentItem()
        if item:
            return item.data(Qt.ItemDataRole.UserRole)
        if self.thumbnail_options:
            return "segment:0", self.thumbnail_options[0][1]
        return self.thumbnail_source, self.thumbnail_data

    def refresh_notes(self) -> None:
        self.notes = normalize_notes(self.notes)
        self.notes_list.clear()
        for note in self.notes:
            item = QListWidgetItem()
            row = ProjectNoteRow(note, self.notes_list)
            row.edit_requested.connect(self.edit_note)
            row.delete_requested.connect(self.delete_note)
            row.checked_changed.connect(self.set_note_checked)
            item.setSizeHint(row.sizeHint())
            item.setData(Qt.ItemDataRole.UserRole, note["id"])
            self.notes_list.addItem(item)
            self.notes_list.setItemWidget(item, row)
        self.notes_list.scrollToBottom()

    def commit_note(self) -> None:
        text = self.note_input.text().strip()
        if not text:
            return
        date = self.note_date.dateTime().toUTC().toString(Qt.DateFormat.ISODate)
        existing = next((note for note in self.notes if note["id"] == self.editing_note_id), None)
        if existing:
            existing["text"] = text
            existing["date"] = date
        else:
            self.notes.append(new_note(text, date))
        self.editing_note_id = ""
        self.note_input.clear()
        self.note_date.setDateTime(QDateTime.currentDateTime())
        self.refresh_notes()

    def edit_note(self, note_id: str) -> None:
        note = next((value for value in self.notes if value["id"] == note_id), None)
        if not note:
            return
        self.editing_note_id = note_id
        self.note_input.setText(note["text"])
        value = QDateTime.fromString(note["date"], Qt.DateFormat.ISODate)
        if value.isValid():
            self.note_date.setDateTime(value.toLocalTime())
        self.note_input.setFocus()
        self.note_input.selectAll()

    def delete_note(self, note_id: str) -> None:
        self.notes = [note for note in self.notes if note["id"] != note_id]
        if self.editing_note_id == note_id:
            self.editing_note_id = ""
            self.note_input.clear()
        self.refresh_notes()

    def set_note_checked(self, note_id: str, checked: bool) -> None:
        note = next((value for value in self.notes if value["id"] == note_id), None)
        if note:
            note["checked"] = checked
            self.refresh_notes()

    def notes_value(self) -> list[dict]:
        return normalize_notes(self.notes)


class ProjectPropertiesPanel(QWidget):
    """Editable project details, statuses, tags, and checklist notes in a dock."""

    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.project_id = ""
        self.notes: list[dict] = []
        self._loading = False
        self.editing_note_id = ""
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 8, 8, 8)
        self.message = QLabel("Select a project in the library to edit its properties.")
        self.message.setWordWrap(True)
        outer.addWidget(self.message)
        form = QFormLayout()
        self.name = QLineEdit()
        self.description = QTextEdit()
        install_spellcheck(self.description)
        self.description.setMaximumHeight(80)
        self.collection = QLineEdit()
        self.status = QComboBox()
        self.status.addItem("No status", "")
        self.status.currentIndexChanged.connect(self.commit_fields)
        self.archived = QCheckBox("Archived")
        self.archived.toggled.connect(self.commit_fields)
        form.addRow("Name", self.name)
        form.addRow("Description", self.description)
        form.addRow("Collection", self.collection)
        self.download_folder = QLineEdit()
        folder_row = QWidget()
        folder_layout = QHBoxLayout(folder_row)
        folder_layout.setContentsMargins(0, 0, 0, 0)
        folder_layout.addWidget(self.download_folder, 1)
        browse = QPushButton("…")
        browse.clicked.connect(self.choose_download_folder)
        folder_layout.addWidget(browse)
        self.download_folder.textChanged.connect(self.queue_fields)
        form.addRow("Download folder", folder_row)
        form.addRow("Status", self.status)
        form.addRow("", self.archived)
        outer.addLayout(form)
        outer.addWidget(QLabel("TAGS"))
        self.tags_container = QWidget()
        self.tags_layout = QVBoxLayout(self.tags_container)
        self.tags_layout.setContentsMargins(0, 0, 0, 0)
        self.tags_layout.setSpacing(2)
        outer.addWidget(self.tags_container)
        self.tag_boxes: list[QCheckBox] = []
        tag_entry = QHBoxLayout()
        self.new_tag = QLineEdit()
        self.new_tag.setPlaceholderText("Add a tag to this project…")
        self.new_tag.returnPressed.connect(self.create_tag)
        tag_add = QPushButton("Add tag")
        tag_add.clicked.connect(self.create_tag)
        tag_entry.addWidget(self.new_tag, 1)
        tag_entry.addWidget(tag_add)
        outer.addLayout(tag_entry)
        outer.addWidget(QLabel("TASKS & NOTES"))
        note_input = QHBoxLayout()
        self.note_date = QDateTimeEdit(QDateTime.currentDateTime())
        self.note_date.setCalendarPopup(True)
        self.note_date.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.note_text = QLineEdit()
        self.note_text.setPlaceholderText("New task or note…")
        self.note_text.returnPressed.connect(self.commit_note)
        add = QPushButton("Add")
        add.clicked.connect(self.commit_note)
        note_input.addWidget(self.note_date)
        note_input.addWidget(self.note_text, 1)
        note_input.addWidget(add)
        outer.addLayout(note_input)
        self.notes_list = QListWidget()
        self.notes_list.setMinimumHeight(130)
        outer.addWidget(self.notes_list, 1)
        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.setInterval(500)
        self.save_timer.timeout.connect(self.commit_fields)
        self.name.textChanged.connect(self.queue_fields)
        self.description.textChanged.connect(self.queue_fields)
        self.collection.textChanged.connect(self.queue_fields)
        self.set_project(None)

    def choose_download_folder(self) -> None:
        directory = choose_directory(self, "Project download folder", self.download_folder.text() or str(self.owner.export_directory()))
        if directory:
            self.download_folder.setText(directory)
            self.commit_fields()

    def queue_fields(self, *_args) -> None:
        if not self._loading and self.project_id:
            self.save_timer.start()

    def set_project(self, meta: dict | None) -> None:
        project_id = str(meta.get("id", "")) if meta and meta.get("kind") != "collection" else ""
        if project_id != self.project_id and self.save_timer.isActive():
            self.save_timer.stop()
            self.commit_fields()
        self._loading = True
        self.project_id = project_id
        self.setEnabled(bool(project_id))
        self.message.setText("Project properties save as you edit." if project_id else "Select a project in the library to edit its properties.")
        self.name.setText(str(meta.get("name", "")) if meta else "")
        self.description.setPlainText(str(meta.get("description", "")) if meta else "")
        self.collection.setText(str(meta.get("collection", "")) if meta else "")
        directory = (self.owner.download_directory if project_id == self.owner.current_project_id else str(meta.get("downloadDirectory", ""))) if meta else ""
        self.download_folder.setText(directory)
        self.download_folder.setPlaceholderText(str(self.owner.export_directory()))
        self.status.blockSignals(True)
        self.status.clear()
        self.status.addItem("No status", "")
        for tag in self.owner.project_status_tags():
            self.status.addItem(tag["name"], tag["name"])
        current = str(meta.get("status", "")) if meta else ""
        if current and self.status.findData(current) < 0:
            self.status.addItem(current, current)
        self.status.setCurrentIndex(max(0, self.status.findData(current)))
        self.status.blockSignals(False)
        self.archived.blockSignals(True)
        self.archived.setChecked(bool(meta.get("archived")) if meta else False)
        self.archived.blockSignals(False)
        for box in self.tag_boxes:
            self.tags_layout.removeWidget(box)
            box.deleteLater()
        self.tag_boxes = []
        selected = {str(value).casefold() for value in meta.get("tags", [])} if meta else set()
        definitions = self.owner.project_other_tags()
        for value in selected:
            if value not in {tag["name"].casefold() for tag in definitions}:
                definitions.append({"name": next((tag for tag in meta.get("tags", []) if str(tag).casefold() == value), value)})
        for tag in definitions:
            box = QCheckBox(tag["name"])
            box.setChecked(tag["name"].casefold() in selected)
            box.toggled.connect(self.commit_fields)
            self.tags_layout.addWidget(box)
            self.tag_boxes.append(box)
        self.notes = normalize_notes(meta.get("notes")) if meta else []
        self.editing_note_id = ""
        self.note_text.clear()
        self.refresh_notes()
        self._loading = False

    def refresh_notes(self) -> None:
        self.notes_list.clear()
        for note in self.notes:
            item = QListWidgetItem()
            row = ProjectNoteRow(note, self.notes_list)
            row.edit_requested.connect(self.edit_note)
            row.delete_requested.connect(self.delete_note)
            row.checked_changed.connect(self.set_note_checked)
            item.setSizeHint(row.sizeHint())
            self.notes_list.addItem(item)
            self.notes_list.setItemWidget(item, row)

    def current_metadata(self) -> dict | None:
        if not self.project_id:
            return None
        try:
            return json.loads((project_library_path() / f"{self.project_id}.meta.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def commit_fields(self, *_args) -> None:
        if self._loading:
            return
        meta = self.current_metadata()
        if not meta:
            return
        name = self.name.text().strip()
        if not name:
            self.name.setText(str(meta.get("name", "")))
            return
        self.save_timer.stop()
        meta["downloadDirectory"] = self.download_folder.text().strip()
        if self.project_id == self.owner.current_project_id:
            self.owner.download_directory = meta["downloadDirectory"]
        meta.update({"name": name, "description": self.description.toPlainText().strip(),
                     "collection": self.collection.text().strip(), "status": self.status.currentData() or "",
                     "tags": [box.text() for box in self.tag_boxes if box.isChecked()],
                     "archived": self.archived.isChecked(), "notes": normalize_notes(self.notes),
                     "savedAt": datetime.now(timezone.utc).isoformat()})
        self.owner.persist_library_metadata(meta)
        if self.owner.current_project_id == self.project_id:
            self.owner.mark_dirty()
            self.owner.current_project_name = name
            self.owner.update_window_title()
        self.owner.refresh_project_library(self.project_id)

    def commit_note(self) -> None:
        value = self.note_text.text().strip()
        if not self.project_id or not value:
            return
        date = self.note_date.dateTime().toUTC().toString(Qt.DateFormat.ISODate)
        existing = next((note for note in self.notes if note["id"] == self.editing_note_id), None)
        if existing:
            existing.update({"text": value, "date": date})
        else:
            self.notes.append(new_note(value, date))
        self.editing_note_id = ""
        self.note_text.clear()
        self.note_date.setDateTime(QDateTime.currentDateTime())
        self.notes = normalize_notes(self.notes)
        self.refresh_notes()
        self.commit_fields()

    def create_tag(self) -> None:
        name = self.new_tag.text().strip()
        if not self.project_id or not name:
            return
        existing = {tag["name"].casefold() for tag in self.owner.project_status_tags() + self.owner.project_other_tags()}
        if name.casefold() in existing or name.casefold() == "archive":
            self.message.setText("That tag name is already in use.")
            return
        definitions = self.owner.project_other_tags()
        definitions.append({"name": name, "color": "#567a94"})
        self.owner.settings.setValue("project_other_tags", json.dumps(definitions))
        self.new_tag.clear()
        box = QCheckBox(name)
        box.setChecked(True)
        box.toggled.connect(self.commit_fields)
        self.tags_layout.addWidget(box)
        self.tag_boxes.append(box)
        self.commit_fields()
        self.owner.rebuild_project_filter_buttons()

    def edit_note(self, note_id: str) -> None:
        note = next((value for value in self.notes if value["id"] == note_id), None)
        if note:
            self.editing_note_id = note_id
            self.note_text.setText(note["text"])
            timestamp = QDateTime.fromString(note["date"], Qt.DateFormat.ISODate)
            if timestamp.isValid():
                self.note_date.setDateTime(timestamp.toLocalTime())
            self.note_text.setFocus()

    def delete_note(self, note_id: str) -> None:
        self.notes = [note for note in self.notes if note["id"] != note_id]
        self.refresh_notes()
        self.commit_fields()

    def set_note_checked(self, note_id: str, checked: bool) -> None:
        for note in self.notes:
            if note["id"] == note_id:
                note["checked"] = checked
        self.refresh_notes()
        self.commit_fields()


class ReferenceImageDock(QDockWidget):
    closed_by_user = Signal()

    def closeEvent(self, event):
        self.closed_by_user.emit()
        super().closeEvent(event)


class ProjectLibraryDock(QDockWidget):
    user_resized = Signal(int, int)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        on_separator = QApplication.widgetAt(QCursor.pos()) is self.parentWidget()
        if QApplication.mouseButtons() & Qt.MouseButton.LeftButton and (on_separator or self.isFloating()):
            self.user_resized.emit(self.width(), self.height())


class MiniMaxPromptPanel(QFrame):
    """Inline MiniMax controls. The production editor belongs to MainWindow."""

    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.editor = owner.segment_prompt
        self.refine_button = owner.refine_prompt_button
        self.copy_button = owner.copy_segment
        self.busy = False
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        header = QHBoxLayout()
        self.cache_state = QLabel("Not generated")
        self.cache_state.setObjectName("minimaxCacheState")
        header.addWidget(self.cache_state)
        header.addStretch()
        layout.addLayout(header)
        self.message_panel = QFrame()
        self.message_panel.setObjectName("minimaxMessagePanel")
        message_layout = QHBoxLayout(self.message_panel)
        message_layout.setContentsMargins(8, 4, 8, 4)
        self.message_banner = QLabel()
        self.message_banner.setObjectName("minimaxMessageBanner")
        self.message_banner.setWordWrap(True)
        self.message_banner.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        message_layout.addWidget(self.message_banner, 1)
        self.retry_button = QPushButton("↻ Retry")
        self.retry_button.clicked.connect(owner.retry_minimax_operation)
        message_layout.addWidget(self.retry_button)
        self.timeline_refine_button = QPushButton("✎ Refine prompt")
        self.timeline_refine_button.clicked.connect(owner.refine_minimax_prompt)
        message_layout.addWidget(self.timeline_refine_button)
        layout.addWidget(self.message_panel)
        self.clear_message()

        # Untimed project references can accompany either MiniMax workflow.
        self.reference_dock = ReferenceImageDock("REFERENCE IMAGES", owner)
        self.reference_dock.setObjectName("minimaxReferenceDock")
        self.reference_dock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self.reference_dock.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable | QDockWidget.DockWidgetFeature.DockWidgetMovable)
        content = QWidget()
        refs_layout = QVBoxLayout(content)
        self.reference_targets = []
        for index in range(2):
            target = MiniMaxReferenceSlot(index + 1)
            target.changed.connect(lambda value, slot=index: owner.set_minimax_reference_image(slot, value))
            target.error.connect(lambda message: self.show_message(message, "warning"))
            refs_layout.addWidget(target)
            self.reference_targets.append(target)
        refs_layout.addStretch()
        self.reference_dock.setWidget(content)
        owner.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.reference_dock)
        self.reference_dock.hide()
        self.reference_dock.closed_by_user.connect(lambda: owner.set_reference_panel_open(False))
        self.reference_dock.toggleViewAction().triggered.connect(owner.set_reference_panel_open)
        self.workflow_label = owner.workflow_label

    def set_project(self, project_name: str, prompt: str, instructions: str, cache_state: str) -> None:
        self.refresh_references()
        self.set_cache_state(cache_state)
        self.owner.refresh_shared_editor()

    def refresh_references(self, update_images: bool = True) -> None:
        segments = self.owner.segments
        refs = reference_slots(self.owner.minimax_reference_images)
        active_refs = self.owner.active_reference_images() if self.owner.unified_workspace or self.owner.workspace_engine == "generic" else []
        workflow = detect_workflow(segments, active_refs)
        self.workflow_label.setText("Frames + references" if self.owner.workspace_engine == "minimax_frames" and any(active_refs)
                                    else "Conditioning frames" if self.owner.workspace_engine == "minimax_frames"
                                    else WORKFLOW_NAMES[workflow])
        inventory = reference_inventory(segments, active_refs)
        self.workflow_label.setToolTip("Detected from timeline and active reference images.\n" + "\n".join(
            f"{item['label']}: {item['name']}"
            + (f" · {item['role']} at {item['checkpoint_time']:.3f}s" if "checkpoint_time" in item else "")
            for item in inventory if item["label"]
        ))
        if update_images:
            labels = {item["reference_slot"]: item["label"] for item in inventory if "reference_slot" in item}
            for index, target in enumerate(self.reference_targets):
                target.set_value(refs[index], labels.get(index))

    def set_cache_state(self, text: str) -> None:
        self.cache_state.setText(text)

    def show_message(self, text: str, level: str = "info", retry: bool = False) -> None:
        self.message_banner.setText(text)
        self.message_panel.setProperty("level", level)
        self.message_panel.style().unpolish(self.message_panel)
        self.message_panel.style().polish(self.message_panel)
        self.retry_button.setVisible(retry)
        self.timeline_refine_button.setVisible(level == "timeline")
        self.message_panel.show()

    def clear_message(self) -> None:
        self.message_banner.clear()
        self.retry_button.hide()
        self.timeline_refine_button.hide()
        self.message_panel.hide()

    def set_busy(self, busy: bool, status: str = "") -> None:
        self.busy = busy
        if status:
            self.set_cache_state(status)
        self.update_actions()

    def update_actions(self) -> None:
        if self.owner.unified_workspace:
            self.refine_button.setEnabled(not self.busy and bool(self.editor.toPlainText().strip()))
        self.retry_button.setEnabled(not self.busy)
        self.timeline_refine_button.setEnabled(not self.busy)

    def focus_prompt_editor(self) -> None:
        self.editor.setFocus(Qt.FocusReason.OtherFocusReason)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(application_window_title())
        self.setWindowIcon(QIcon(str(files("ltx_prompt_director").joinpath("assets/icon.png"))))
        self.resize(1450, 900)
        self.settings = QSettings()
        self._settings_sync_timer = QTimer(self)
        self._settings_sync_timer.setSingleShot(True)
        self._settings_sync_timer.setInterval(250)
        self._settings_sync_timer.timeout.connect(self.settings.sync)
        self.session_keys = {"gemini": self.settings.value("gemini_key", ""), "openai": self.settings.value("openai_key", "")}
        self.segments: list[Segment] = []
        self.current_project_id: str | None = None
        self.current_project_name = "Untitled"
        self.download_directory = ""
        self._reserved_exports = set()
        self.project_dirty = False
        self.project_sessions: dict[str, dict] = {}
        self.minimax_prompt_text = ""
        self.minimax_refinement_instructions = ""
        self.minimax_prompt_cache_key = ""
        self.minimax_prompt_updated_at = ""
        self.minimax_prompt_mode = "frames"
        self.minimax_reference_images = [None, None]
        self.minimax_panel: MiniMaxPromptPanel | None = None
        self.workspace_store = WorkspaceStore()
        self.workspace_definitions = self.workspace_store.load()
        self.project_type = "ltx" if "ltx" in self.workspace_definitions else next(iter(self.workspace_definitions), "")
        self.minimax_drafts: dict[str, dict] = {}
        self.workspace_revision = 0
        self.ai_busy = False
        self.current_collection: str | None = None
        self.autofit_tail_extension = 0
        self.timeline_fit_mode = False
        self._restoring_layout = True
        self.project_panel_width = max(280, self.settings.value("project_panel_width", 330, int))
        self.project_panel_height = max(160, self.settings.value("project_panel_height", 300, int))
        saved_icon_size = self.settings.value("project_icon_size", 230, int)
        self.project_icon_size = min((96, 156, 230), key=lambda size: abs(size - saved_icon_size))
        self.pixels_per_second = 65
        self._timeline_fit_timer = QTimer(self)
        self._timeline_fit_timer.setSingleShot(True)
        self._timeline_fit_timer.setInterval(60)
        self._timeline_fit_timer.timeout.connect(self.apply_timeline_fit)
        self._project_open_timer = QTimer(self)
        self._project_open_timer.setSingleShot(True)
        self._project_open_timer.setInterval(90)
        self._project_open_timer.timeout.connect(self.open_pending_library_project)
        self._pending_project_id: str | None = None
        self.timeline_height = max(184, min(430, self.settings.value("timeline_panel_height", 184, int)))
        self.thread_pool = QThreadPool.globalInstance()
        self.disk_pool = QThreadPool(self)
        self.disk_pool.setMaxThreadCount(1)
        self.media_pool = QThreadPool(self)
        self.media_pool.setMaxThreadCount(2)
        self._edit_serial = 0
        self._latest_save_id = {}
        self._pending_disk_jobs = 0
        self._close_after_jobs = False
        self._close_saves_queued = False
        self._closing_progress = None
        self._closing_total = 0
        self._open_serial = 0
        self._action_segment_ids = []
        self._action_descriptions = {}
        self._changed_action_sources = set()
        self._timeline_signature = ()
        self._actions_refresh_timer = QTimer(self)
        self._actions_refresh_timer.setSingleShot(True)
        self._actions_refresh_timer.setInterval(280)
        self._actions_refresh_timer.timeout.connect(self.sync_timed_actions)
        self._loading = True
        self.setDockNestingEnabled(True)
        splash = getattr(QApplication.instance(), '_director_splash', None)
        if splash:
            splash.set_status('Creating timeline and project panels…')
            QApplication.processEvents()
        self._build_ui()
        self._loading = False
        self.project_dirty = False
        for editor in self.findChildren(QTextEdit):
            install_spellcheck(editor)
            if isinstance(editor, PromptTextEdit):
                install_prompt_tags(editor)
        if splash:
            splash.set_status('Preparing text tools and appearance…')
            QApplication.processEvents()
        self._apply_theme()
        self.magic_overlay = MagicBuildOverlay(self)
        geometry = self.settings.value("window/geometry")
        state = self.settings.value("window/state")
        if geometry:
            self.restoreGeometry(geometry)
        if state:
            self.restoreState(state)
        self.sync_reference_panel_visibility()
        self.tabifiedDockWidgetActivated.connect(lambda *_: self.queue_project_panel_width_restore())
        QTimer.singleShot(0, self.restore_startup_workspace)
        self.update_window_title()

    def _build_ui(self) -> None:
        self._build_project_dock()
        self._build_project_preview_dock()
        self._build_project_files_dock()
        self._build_project_properties_dock()
        self.catalog_dock = QDockWidget("Media Catalog", self)
        self.catalog_dock.setObjectName("mediaCatalogDock")
        self.media_catalog = MediaCatalog(self)
        self.media_catalog.add_to_timeline.connect(self.add_media_paths)
        self.catalog_dock.setWidget(self.media_catalog)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.catalog_dock)
        self.catalog_dock.hide()
        toolbar = QToolBar("Project")
        toolbar.setObjectName("mainToolbar")
        toolbar.setMovable(False)
        toolbar.setIconSize(QSize(22, 22))
        self.addToolBar(toolbar)
        projects_action = self.project_dock.toggleViewAction()
        projects_action.setText("Projects")
        projects_action.setIcon(toolbar_icon("projects"))
        toolbar.addAction(projects_action)
        preview_action = self.project_preview_dock.toggleViewAction()
        preview_action.setText("Preview")
        preview_action.setIcon(toolbar_icon("preview"))
        toolbar.addAction(preview_action)
        files_action = self.project_files_dock.toggleViewAction()
        files_action.setText("Project Files")
        files_action.setIcon(toolbar_icon("project-files"))
        toolbar.addAction(files_action)
        properties_action = self.project_properties_dock.toggleViewAction()
        properties_action.setText("Properties")
        toolbar.addAction(properties_action)
        catalog_action = self.catalog_dock.toggleViewAction()
        catalog_action.setIcon(toolbar_icon("catalog"))
        toolbar.addAction(catalog_action)
        toolbar.addSeparator()
        action_groups = [
            (("New Project", "new", self.new_project),
             ("Open", "open", self.open_project),
             ("Save to Library", "save", self.save_library_project),
             ("Export Project", "export-project", self.export_project)),
            (("Import", "import", self.import_ltx),
             ("Export", "export-ltx", self.export_workflow)),
            (("Delete selected", "delete", self.delete_selected),),
        ]
        for group_index, group in enumerate(action_groups):
            for label, icon_name, callback in group:
                action = QAction(toolbar_icon(icon_name), label, self)
                action.triggered.connect(callback)
                if label == "Export":
                    self.workflow_export_action = action
                toolbar.addAction(action)
            if group_index < len(action_groups) - 1:
                toolbar.addSeparator()
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        toolbar.addWidget(spacer)
        self.downloads_button = QPushButton()
        self.downloads_button.setIcon(toolbar_icon("downloads"))
        self.downloads_button.setIconSize(QSize(22, 22))
        self.downloads_button.setToolTip("Recent exports")
        self.downloads_button.clicked.connect(self.toggle_downloads)
        toolbar.addWidget(self.downloads_button)
        self.download_tray = DownloadTray(self.settings, self)
        self.download_tray.folder_button.clicked.connect(self.open_download_folder)
        self.provider_button = QPushButton()
        self.provider_button.setObjectName("toolbarButton")
        self.provider_button.clicked.connect(self.open_settings)
        self.update_provider_button()
        toolbar.addWidget(self.provider_button)
        toolbar.addSeparator()
        current_text_scale = self.settings.value("ui_text_scale", 100, int)
        self.ui_scale_label = QLabel("TEXT")
        self.ui_scale_label.setObjectName("timelineControlLabel")
        self.ui_scale_label.setToolTip("Interface text scale")
        toolbar.addWidget(self.ui_scale_label)
        self.ui_scale_control = QFrame()
        self.ui_scale_control.setObjectName("outputSizeControl")
        ui_scale_layout = QHBoxLayout(self.ui_scale_control)
        ui_scale_layout.setContentsMargins(0, 0, 0, 0)
        self.ui_scale_spin = QSpinBox()
        self.ui_scale_spin.setObjectName("timelineSpin")
        self.ui_scale_spin.setRange(75, 200)
        self.ui_scale_spin.setSingleStep(5)
        self.ui_scale_spin.setSuffix("%")
        self.ui_scale_spin.setValue(current_text_scale)
        self.ui_scale_spin.setToolTip("Adjust interface text size (75–200%)")
        self.ui_scale_spin.valueChanged.connect(self.set_ui_text_scale)
        ui_scale_layout.addWidget(self.ui_scale_spin)
        toolbar.addWidget(self.ui_scale_control)
        settings_action = QAction(toolbar_icon("settings"), "Settings", self)
        settings_action.triggered.connect(self.open_settings)
        toolbar.addAction(settings_action)

        root = QWidget()
        outer = QVBoxLayout(root)
        outer.setContentsMargins(10, 5, 10, 8)
        outer.setSpacing(8)
        workflow_row = QHBoxLayout()
        workflow_row.addWidget(QLabel("PROJECT TYPE"))
        self.project_type_combo = QComboBox()
        for key, definition in self.workspace_definitions.items():
            self.project_type_combo.addItem(definition["name"], key)
        self.project_type_combo.currentIndexChanged.connect(self.project_type_changed)
        workflow_row.addWidget(self.project_type_combo)
        self.workflow_label = QLabel()
        self.workflow_label.setObjectName("muted")
        workflow_row.addWidget(self.workflow_label)
        workflow_row.addStretch()
        self.direction_toggle = QCheckBox("Director’s Intent")
        self.direction_toggle.setChecked(self.settings.value("director_intent_expanded", True, bool))
        self.direction_toggle.setToolTip("Show Director's Intent and the options used for generation")
        self.references_button = QPushButton("Reference images")
        self.references_button.clicked.connect(self.show_reference_images)
        workflow_row.addWidget(self.references_button)
        outer.addLayout(workflow_row)
        timeline_shell = QFrame()
        timeline_shell.setObjectName("timelineShell")
        timeline_layout = QVBoxLayout(timeline_shell)
        timeline_layout.setContentsMargins(0, 0, 0, 0)
        timeline_layout.setSpacing(0)
        self.timeline_controls = QHBoxLayout()
        self.timeline_controls.setContentsMargins(10, 6, 10, 5)
        self.timeline_controls.setSpacing(8)
        timeline_title = QLabel("TIMELINE")
        timeline_title.setObjectName("timelineTitle")
        self.timeline_controls.addWidget(timeline_title)
        self.timeline_controls.addStretch()
        output_label = QLabel("OUTPUT")
        self.output_label = output_label
        output_label.setObjectName("timelineControlLabel")
        self.timeline_controls.addWidget(output_label)
        self.output_size_control = QFrame()
        self.output_size_control.setObjectName("outputSizeControl")
        output_size_layout = QHBoxLayout(self.output_size_control)
        output_size_layout.setContentsMargins(0, 0, 0, 0)
        output_size_layout.setSpacing(0)
        self.output_width = QSpinBox()
        self.output_width.setObjectName("timelineSpin")
        self.output_width.setRange(256, 4096)
        self.output_width.setSingleStep(32)
        self.output_width.setValue(1280)
        self.output_width.setSuffix(" px")
        self.output_width.setToolTip("LTX Director custom output width")
        self.output_width.valueChanged.connect(self.mark_dirty)
        self.output_width.editingFinished.connect(self.normalize_output_dimensions)
        self.output_height = QSpinBox()
        self.output_height.setObjectName("timelineSpin")
        self.output_height.setRange(256, 4096)
        self.output_height.setSingleStep(32)
        self.output_height.setValue(704)
        self.output_height.setSuffix(" px")
        self.output_height.setToolTip("LTX Director custom output height")
        self.output_height.valueChanged.connect(self.mark_dirty)
        self.output_height.editingFinished.connect(self.normalize_output_dimensions)
        resolution_separator = QLabel("×")
        resolution_separator.setObjectName("resolutionSeparator")
        resolution_separator.setAlignment(Qt.AlignmentFlag.AlignCenter)
        output_size_layout.addWidget(self.output_width)
        output_size_layout.addWidget(resolution_separator)
        output_size_layout.addWidget(self.output_height)
        self.timeline_controls.addWidget(self.output_size_control)
        scale_label = QLabel("SCALE")
        scale_label.setObjectName("timelineControlLabel")
        self.timeline_controls.addWidget(scale_label)
        self.timeline_scale = QSlider(Qt.Orientation.Horizontal)
        self.timeline_scale.setRange(0, 160)
        self.timeline_scale.setValue(self.pixels_per_second)
        self.timeline_scale.setFixedWidth(150)
        self.timeline_scale.setToolTip("Timeline scale (far left fits the full sequence)")
        self.timeline_scale.valueChanged.connect(self.set_timeline_scale)
        self.timeline_controls.addWidget(self.timeline_scale)
        autofit = QPushButton("↔  Auto fit")
        autofit.setObjectName("timelineButton")
        autofit.clicked.connect(self.autofit_timeline)
        self.timeline_controls.addWidget(autofit)
        timeline_layout.addLayout(self.timeline_controls)
        ruler_row = QHBoxLayout()
        ruler_row.setContentsMargins(0, 0, 0, 0)
        ruler_spacer = QWidget()
        ruler_spacer.setFixedWidth(145)
        self.ruler = TimelineRuler()
        ruler_row.addWidget(ruler_spacer)
        ruler_row.addWidget(self.ruler, 1)
        timeline_layout.addLayout(ruler_row)
        track_row = QHBoxLayout()
        track_row.setContentsMargins(0, 0, 0, 0)
        track_row.setSpacing(0)
        main_label = QLabel("MAIN ◉")
        main_label.setObjectName("mainTrackLabel")
        main_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_label.setFixedWidth(145)
        track_row.addWidget(main_label)
        self.timeline = TimelineListWidget()
        self.timeline.setObjectName("timeline")
        self.timeline.setProperty("dropActive", False)
        self.timeline.setViewMode(QListWidget.ViewMode.ListMode)
        self.timeline.setFlow(QListWidget.Flow.LeftToRight)
        self.timeline.setWrapping(False)
        self.timeline.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.timeline.setSpacing(0)
        self.timeline.setFixedHeight(self.timeline_height)
        self.timeline.setDragDropMode(QListWidget.DragDropMode.InternalMove)
        self.timeline.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.timeline.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.timeline.customContextMenuRequested.connect(self.timeline_menu)
        self.timeline.currentRowChanged.connect(self.load_editor)
        self.timeline.currentRowChanged.connect(self.update_timeline_selection_style)
        self.timeline.itemClicked.connect(self.reload_clicked_segment)
        self.timeline.model().rowsMoved.connect(lambda *_: self.sync_order())
        self.timeline.files_dropped.connect(self.add_media_paths)
        self.timeline.files_replaced.connect(self.replace_timeline_media)
        self.timeline.projects_dropped.connect(self.project_files_dropped)
        self.timeline.horizontalScrollBar().valueChanged.connect(self.ruler.set_offset)
        self.timeline_loading = TimelineLoadingOverlay(self.timeline.viewport())
        track_row.addWidget(self.timeline, 1)
        self.add_tile = QPushButton("＋\nAdd media")
        self.add_tile.setObjectName("addTile")
        self.add_tile.clicked.connect(self.add_media)
        self.add_text_tile = QPushButton("＋\nAdd text")
        self.add_text_tile.setObjectName("addTextTile")
        self.add_text_tile.clicked.connect(self.add_text_segment)
        self.add_tile_wrap = QFrame()
        self.add_tile_wrap.setObjectName("addTileBox")
        self.add_tile_wrap.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.add_tile_wrap.setFixedSize(128, max(152, self.timeline_height - 32))
        self.add_tile_layout = QVBoxLayout(self.add_tile_wrap)
        self.add_tile_layout.setContentsMargins(8, 8, 8, 8)
        self.add_tile_layout.setSpacing(0)
        self.add_tile.setFixedHeight(54)
        self.add_text_tile.setFixedHeight(30)
        self.add_tile_layout.addStretch(1)
        self.add_tile_layout.addWidget(self.add_tile, 0, Qt.AlignmentFlag.AlignHCenter)
        self.add_tile_layout.addWidget(self.add_text_tile, 0, Qt.AlignmentFlag.AlignHCenter)
        self.add_tile_layout.addStretch(1)
        track_row.addWidget(self.add_tile_wrap)
        timeline_layout.addLayout(track_row)
        self.timeline_height_handle = TimelineHeightHandle(self.timeline_height)
        self.timeline_height_handle.height_changed.connect(self.set_timeline_height)
        self.timeline_height_handle.finished.connect(self.finish_timeline_height_resize)
        timeline_layout.addWidget(self.timeline_height_handle)
        outer.addWidget(timeline_shell)

        self.sequence_bar = QLabel()
        self.sequence_bar.setObjectName("sequenceBar")
        self.sequence_controls = QHBoxLayout()
        self.sequence_controls.setContentsMargins(0, 0, 0, 0)
        self.sequence_controls.addWidget(self.sequence_bar, 1)
        outer.addLayout(self.sequence_controls)

        director_panel = QFrame()
        self.director_panel = director_panel
        self.direction_toggle.toggled.connect(director_panel.setVisible)
        self.direction_toggle.toggled.connect(lambda expanded: self.settings.setValue("director_intent_expanded", expanded))
        director_panel.setVisible(self.direction_toggle.isChecked())
        director_panel.setObjectName("directorPanel")
        self.director_controls = QVBoxLayout(director_panel)
        self.director_controls.setContentsMargins(10, 8, 10, 8)
        self.director_controls.setSpacing(7)
        intent_row = QHBoxLayout()
        intent_row.setContentsMargins(0, 0, 0, 0)
        intent_row.setSpacing(8)
        intent_label = QLabel("DIRECTOR'S INTENT")
        intent_label.setObjectName("panelTitle")
        intent_row.addWidget(intent_label)
        self.intent = PromptTextEdit()
        self.intent.setAcceptRichText(False)
        self.intent.setMaximumHeight(82)
        intent_example = (
            "Example: A lost courier discovers a glowing map, crosses the storm, and reaches the beacon at sunrise. "
            "Describe the narrative, action, pacing, camera, dialogue wording, and ending you want."
        )
        self.intent.setPlaceholderText(intent_example)
        self.intent.setToolTip(intent_example)
        self.intent.textChanged.connect(self.mark_dirty)
        self.sfx = QPushButton("SFX")
        self.sfx.setCheckable(True)
        self.sfx.setObjectName("audioToggle")
        self.sfx.toggled.connect(self.mark_dirty)
        self.spoken_dialog = QPushButton("Spoken Dialog")
        self.spoken_dialog.setCheckable(True)
        self.spoken_dialog.setObjectName("audioToggle")
        self.spoken_dialog.setToolTip("Allow Magic Build to include spoken-dialog direction when supported by the scene")
        self.spoken_dialog.toggled.connect(self.update_spoken_dialog_controls)
        self.hdr = QPushButton("HDR")
        self.hdr.setCheckable(True)
        self.hdr.setObjectName("qualityToggle")
        self.hdr.setToolTip("Prepend (4K, HDR, Realistic) to the global prompt")
        self.hdr.clicked.connect(self.apply_global_prefixes)
        self.hdr.toggled.connect(self.mark_dirty)
        self.reduce_music = QPushButton("Reduce Music")
        self.reduce_music.setCheckable(True)
        self.reduce_music.setObjectName("qualityToggle")
        self.reduce_music.setToolTip("Ask Magic Build for setting-specific ambient sound to discourage generated music")
        self.reduce_music.toggled.connect(self.mark_dirty)
        self.magic_button = QPushButton("✦ Magic Build")
        self.magic_button.setObjectName("magicButton")
        self.magic_button.clicked.connect(self.generate_project_prompt)
        for button in (self.sfx, self.spoken_dialog, self.hdr, self.reduce_music, self.magic_button):
            button.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        intent_row.addWidget(self.intent, 1)
        workflow_row.addWidget(self.magic_button)
        self.director_controls.addLayout(intent_row)
        planning_row = QHBoxLayout()
        planning_row.setContentsMargins(0, 0, 0, 0)
        planning_row.setSpacing(6)
        planning_label = QLabel("DIRECTION SETTINGS")
        self.planning_label = planning_label
        planning_label.setObjectName("groupLabel")
        planning_row.addWidget(planning_label)
        length_label = QLabel("TOTAL LENGTH")
        self.length_label = length_label
        length_label.setObjectName("groupLabel")
        self.requested_length = QDoubleSpinBox()
        self.requested_length.setObjectName("timelineSpin")
        self.requested_length.setRange(0, sys.float_info.max)
        self.requested_length.setSingleStep(.01)
        self.requested_length.setDecimals(2)
        self.requested_length.setSuffix(" s")
        self.requested_length.setSpecialValueText("Auto")
        self.requested_length.setToolTip("Requested total sequence length; Auto lets Magic Build choose")
        self.requested_length.valueChanged.connect(self.mark_dirty)
        language_label = QLabel("LANGUAGE")
        language_label.setObjectName("groupLabel")
        self.speaker_language = QComboBox()
        self.speaker_language.setEditable(True)
        self.speaker_language.addItems([
            "(Image/context provided)", "English", "Spanish", "French", "German", "Italian",
            "Portuguese", "Japanese", "Korean", "Mandarin Chinese", "Hindi", "Arabic", "Russian",
        ])
        self.speaker_language.setCurrentIndex(0)
        self.speaker_language.setToolTip("Spoken language used when Spoken Dialog is enabled; this field is editable")
        self.speaker_language.currentTextChanged.connect(self.mark_dirty)
        self.speaker_language.setEnabled(False)
        accent_label = QLabel("ACCENT")
        accent_label.setObjectName("groupLabel")
        self.speaker_accent = QComboBox()
        self.speaker_accent.setEditable(True)
        self.speaker_accent.addItems([
            "(Image/context provided)", "Neutral", "General American", "British RP", "Yorkshire",
            "Australian", "Canadian", "Irish", "Scottish", "Indian English", "Asian (Chinese)", "Mexican Spanish",
            "Castilian Spanish", "Brazilian Portuguese", "European Portuguese",
        ])
        self.speaker_accent.setCurrentIndex(0)
        self.speaker_accent.setToolTip("Exact regional accent used when Spoken Dialog is enabled; this field is editable")
        self.speaker_accent.currentTextChanged.connect(self.mark_dirty)
        self.speaker_accent.setEnabled(False)
        planning_row.addWidget(length_label)
        planning_row.addWidget(self.requested_length)
        self.language_label = language_label
        self.accent_label = accent_label
        planning_row.addWidget(language_label)
        planning_row.addWidget(self.speaker_language)
        planning_row.addWidget(accent_label)
        planning_row.addWidget(self.speaker_accent)
        planning_row.addStretch()
        self.director_controls.addLayout(planning_row)
        options_row = QHBoxLayout()
        options_row.setContentsMargins(0, 0, 0, 0)
        options_row.setSpacing(6)
        options_label = QLabel("PROMPT OPTIONS")
        options_label.setObjectName("groupLabel")
        options_row.addWidget(options_label)
        options_row.addWidget(self.sfx)
        options_row.addWidget(self.spoken_dialog)
        options_row.addWidget(self.hdr)
        options_row.addWidget(self.reduce_music)
        options_row.addStretch()
        self.director_controls.addLayout(options_row)
        outer.addWidget(director_panel)

        segment_panel = QFrame()
        segment_panel.setObjectName("promptPanel")
        segment_layout = QVBoxLayout(segment_panel)
        segment_layout.setContentsMargins(9, 6, 9, 5)
        self.segment_header = QHBoxLayout()
        self.segment_header.setSpacing(8)
        self.prompt_label = QLabel("SEGMENT PROMPT")
        segment_label = self.prompt_label
        segment_label.setObjectName("sectionLabel")
        self.segment_header.addWidget(segment_label)
        self.segment_header.addWidget(self.direction_toggle)
        self.prompt_scope = QComboBox()
        self.prompt_scope.addItem("Selected segment", "segment")
        self.prompt_scope.addItem("Global prompt", "global")
        self.prompt_scope.currentIndexChanged.connect(self.prompt_scope_changed)
        self.segment_header.addWidget(self.prompt_scope)
        self.refine_timing_button = QPushButton("⏱ Refine Timing")
        self.refine_timing_button.setObjectName("refineButton")
        self.refine_timing_button.setToolTip("Analyze the existing sequence and retime only the selected segment; prompt wording is never changed")
        self.refine_timing_button.clicked.connect(self.refine_selected_timing)
        self.refine_timing_button.setEnabled(False)
        self.refine_prompt_button = QPushButton("✎ Refine Prompt")
        self.refine_prompt_button.setObjectName("refineButton")
        self.refine_prompt_button.setToolTip("Refine only the selected segment prompt using adjacent frames for continuity; may also adjust its duration")
        self.refine_prompt_button.clicked.connect(self.refine_project_prompt)
        self.refine_prompt_button.setEnabled(False)
        self.segment_header.addWidget(self.refine_timing_button)
        self.segment_header.addWidget(self.refine_prompt_button)
        self.frame_number = QLabel("Frame —")
        self.frame_number.setObjectName("muted")
        self.start_button = QPushButton("Start frame")
        self.end_button = QPushButton("End frame")
        self.start_button.setObjectName("frameToggle")
        self.end_button.setObjectName("frameToggle")
        self.start_button.setCheckable(True)
        self.end_button.setCheckable(True)
        self.duration_control = QFrame()
        self.duration_control.setObjectName("outputSizeControl")
        duration_control_layout = QHBoxLayout(self.duration_control)
        duration_control_layout.setContentsMargins(0, 0, 0, 0)
        self.duration_spin = QDoubleSpinBox()
        self.duration_spin.setObjectName("timelineSpin")
        self.duration_spin.setRange(MIN_DURATION, sys.float_info.max)
        self.duration_spin.setSingleStep(.01)
        self.duration_spin.setDecimals(2)
        self.duration_spin.setSuffix(" s")
        self.duration_spin.setToolTip("Segment duration in seconds")
        self.duration_spin.valueChanged.connect(self.editor_duration_changed)
        duration_control_layout.addWidget(self.duration_spin)
        self.start_button.clicked.connect(lambda: self.set_role("start"))
        self.end_button.clicked.connect(lambda: self.set_role("end"))
        self.segment_header.addStretch()
        segment_meta = QFrame()
        self.segment_meta = segment_meta
        segment_meta.setObjectName("segmentMetaBar")
        segment_meta_layout = QHBoxLayout(segment_meta)
        segment_meta_layout.setContentsMargins(5, 3, 5, 3)
        segment_meta_layout.setSpacing(6)
        segment_meta_layout.addWidget(self.frame_number)
        segment_meta_layout.addWidget(self.start_button)
        segment_meta_layout.addWidget(self.end_button)
        duration_label = QLabel("DURATION")
        duration_label.setObjectName("timelineControlLabel")
        segment_meta_layout.addWidget(duration_label)
        segment_meta_layout.addWidget(self.duration_control)
        self.sequence_controls.addWidget(segment_meta)
        segment_layout.addLayout(self.segment_header)
        self.segment_prompt = PromptTextEdit()
        self.segment_prompt.setObjectName("promptEditor")
        self.segment_prompt.setAcceptRichText(False)
        self.segment_prompt.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        self.segment_prompt.setWordWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
        self.segment_prompt.textChanged.connect(self.save_prompt)
        self.segment_prompt.timedPasteRequested.connect(self.paste_timed_prompt)
        segment_layout.addWidget(self.segment_prompt)
        segment_footer = QHBoxLayout()
        segment_footer.setContentsMargins(0, 0, 0, 0)
        segment_footer.setSpacing(0)
        self.segment_count = QLabel("0 characters")
        self.segment_count.setObjectName("muted")
        self.copy_segment = QPushButton("□ Copy")
        self.copy_segment.setObjectName("copyButton")
        self.copy_segment.setFlat(True)
        self.copy_segment.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.copy_segment.clicked.connect(lambda: QApplication.clipboard().setText(self.segment_prompt.toPlainText()))
        segment_footer.addWidget(self.segment_count)
        segment_footer.addStretch()
        segment_footer.addWidget(self.copy_segment, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        segment_layout.addLayout(segment_footer)
        # The global prompt is stored here for compatibility with generation/export;
        # it is edited through the same visible text box using the scope selector.
        self.global_prompt = PromptTextEdit(self)
        self.global_prompt.hide()
        self.global_prompt.textChanged.connect(self.global_prompt_changed)
        self.applied_label = QLabel(self)
        self.applied_label.hide()
        self.global_count = QLabel(self)
        self.global_count.hide()
        self.minimax_panel = MiniMaxPromptPanel(self)
        segment_layout.insertWidget(1, self.minimax_panel)
        outer.addWidget(segment_panel, 1)
        self.setCentralWidget(root)
        self.setStatusBar(QStatusBar())
        self.apply_project_type_ui()
        self.update_summary()

    def _build_project_preview_dock(self) -> None:
        self.project_preview_dock = QDockWidget("PROJECT VIDEO PREVIEW", self)
        self.project_preview_dock.setObjectName("projectPreviewDock")
        self.project_preview_dock.setAllowedAreas(
            Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea | Qt.DockWidgetArea.BottomDockWidgetArea
        )
        self.project_preview_dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetClosable
            | QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.project_preview_dock.setMinimumWidth(400)
        self.project_preview_panel = ProjectPreviewPanel(self.project_preview_dock)
        self.project_preview_panel.video_dropped.connect(self.attach_project_video)
        self.project_preview_panel.choose_requested.connect(self.choose_project_video)
        self.project_preview_panel.export_requested.connect(self.export_project_video)
        self.project_preview_dock.setWidget(self.project_preview_panel)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.project_preview_dock)
        self.project_preview_dock.dockLocationChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_preview_dock.topLevelChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_preview_dock.visibilityChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_preview_dock.visibilityChanged.connect(self.project_preview_panel.set_preview_visible)
        self.project_preview_dock.hide()

    def _build_project_files_dock(self) -> None:
        self.project_files_dock = QDockWidget("PROJECT FILES", self)
        self.project_files_dock.setObjectName("projectFilesDock")
        self.project_files_dock.setAllowedAreas(
            Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea
            | Qt.DockWidgetArea.TopDockWidgetArea | Qt.DockWidgetArea.BottomDockWidgetArea
        )
        self.project_files_dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetClosable
            | QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.project_files_panel = ProjectFilesPanel(self.project_files_dock)
        self.project_files_panel.add_requested.connect(self.choose_project_workflow)
        self.project_files_panel.file_dropped.connect(self.attach_project_workflow)
        self.project_files_panel.export_requested.connect(self.export_project_workflow)
        self.project_files_panel.remove_requested.connect(self.remove_project_workflow)
        self.project_files_dock.setWidget(self.project_files_panel)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.project_files_dock)
        self.project_files_dock.dockLocationChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_files_dock.topLevelChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_files_dock.visibilityChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_files_dock.hide()

    def _build_project_properties_dock(self) -> None:
        self.project_properties_dock = QDockWidget("PROJECT PROPERTIES", self)
        self.project_properties_dock.setObjectName("projectPropertiesDock")
        self.project_properties_dock.setAllowedAreas(
            Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea
        )
        self.project_properties_dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetClosable
            | QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.project_properties_panel = ProjectPropertiesPanel(self)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.project_properties_panel)
        self.project_properties_dock.setWidget(scroll)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.project_properties_dock)
        self.project_properties_dock.dockLocationChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_properties_dock.topLevelChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_properties_dock.visibilityChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_properties_dock.hide()

    def _build_project_dock(self) -> None:
        self.project_dock = ProjectLibraryDock("PROJECT LIBRARY", self)
        self.project_dock.user_resized.connect(self.remember_project_panel_width)
        self.project_dock.setObjectName("projectDock")
        self.project_dock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self.project_dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetClosable
            | QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.project_dock.setMinimumWidth(280)

        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        layout.setContentsMargins(9, 9, 9, 9)
        layout.setSpacing(8)
        library_controls = QFrame()
        library_controls.setObjectName("libraryControls")
        header = QHBoxLayout(library_controls)
        header.setContentsMargins(6, 5, 6, 5)
        header.setSpacing(6)
        self.collection_up = QPushButton("↑ UP")
        self.collection_up.setVisible(False)
        self.collection_up.clicked.connect(self.leave_collection)
        self.project_library_title = QLabel("Saved projects")
        self.project_library_title.setObjectName("projectLibraryTitle")
        self.project_library_title.setWordWrap(True)
        self.project_library_title.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.project_library_title.setMinimumWidth(0)
        self.project_library_title.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        layout.addWidget(self.project_library_title)
        self.project_sort = QComboBox()
        self.project_sort.addItem("Title A–Z", "title_asc")
        self.project_sort.addItem("Title Z–A", "title_desc")
        self.project_sort.addItem("Custom", "custom")
        saved_sort = self.settings.value("project_sort_mode", "title_asc")
        self.project_sort.setCurrentIndex(max(0, self.project_sort.findData(saved_sort)))
        self.project_sort.setToolTip("Sort projects by title or drag tiles in Custom mode")
        self.project_sort.currentIndexChanged.connect(self.project_sort_changed)
        header.addWidget(self.project_sort)
        self.project_icon_button = QPushButton()
        self.project_icon_button.setObjectName("projectIconButton")
        self.project_icon_button.setToolTip("Set project and collection thumbnail size")
        icon_menu = QMenu(self.project_icon_button)
        self.project_icon_actions: dict[int, QAction] = {}
        for label, size in (("Small", 96), ("Medium", 156), ("Large", 230)):
            action = icon_menu.addAction(label)
            action.setCheckable(True)
            action.triggered.connect(lambda checked=False, value=size: self.set_project_icon_size(value))
            self.project_icon_actions[size] = action
        self.project_icon_button.setMenu(icon_menu)
        header.addWidget(self.project_icon_button)
        header.addWidget(self.collection_up)
        header.addStretch()
        layout.addWidget(library_controls)
        self.project_search = QLineEdit()
        self.project_search.setObjectName("projectSearch")
        self.project_search.setPlaceholderText("Search projects…")
        self.project_search.setClearButtonEnabled(True)
        self.project_search.textChanged.connect(self.filter_projects)
        self.project_filter_box = QFrame()
        self.project_filter_box.setObjectName("projectFilters")
        self.project_filter_box.setMinimumWidth(0)
        self.project_filter_box.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.project_filter_layout = QHBoxLayout(self.project_filter_box)
        self.project_filter_layout.setContentsMargins(3, 3, 3, 3)
        self.project_filter_layout.setSpacing(3)
        self.project_filter_buttons: dict[str, QPushButton] = {}
        self.rebuild_project_filter_buttons()
        layout.addWidget(self.project_filter_box)
        layout.addWidget(self.project_search)

        self.project_list = ProjectListWidget()
        self.project_list.setObjectName("projectList")
        self.project_list.setItemDelegate(ProjectTileDelegate(self.project_list))
        self.project_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.project_list.setFlow(QListWidget.Flow.LeftToRight)
        self.project_list.setWrapping(True)
        self.project_list.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.project_list.setMovement(QListWidget.Movement.Static)
        self.project_list.setSpacing(4)
        self.project_list.itemClicked.connect(self.activate_clicked_project)
        self.project_list.itemDoubleClicked.connect(self.activate_double_clicked_project)
        self.project_list.drag_started.connect(self.activate_custom_sort_for_drag)
        self.project_list.order_changed.connect(self.save_custom_project_order)
        self.project_list.files_dropped.connect(self.project_files_dropped)
        self.project_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.project_list.customContextMenuRequested.connect(self.project_library_menu)
        self.project_list.currentItemChanged.connect(lambda *_: self.sync_project_properties())
        layout.addWidget(self.project_list, 1)

        self.update_project_icon_controls()
        self.project_dock.setWidget(panel)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.project_dock)
        self.project_dock.visibilityChanged.connect(self.project_dock_visibility_changed)
        self.project_dock.dockLocationChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_dock.topLevelChanged.connect(lambda *_: self.save_window_panel_state())
        self.project_dock.hide()
        self.refresh_project_library()

    def project_status_tags(self) -> list[dict[str, str]]:
        return load_project_tags(self.settings.value("project_status_tags", self.settings.value("project_tags", "")))

    def project_other_tags(self) -> list[dict[str, str]]:
        return load_other_tags(self.settings.value("project_other_tags", ""))

    def saved_project_filters(self) -> set[str]:
        try:
            value = json.loads(str(self.settings.value("project_tag_filters", "")))
            if isinstance(value, list):
                return {str(item) for item in value}
        except (TypeError, ValueError):
            pass
        return {"__untagged__", *(f"status:{tag['name']}" for tag in self.project_status_tags())}

    def rebuild_project_filter_buttons(self) -> None:
        while self.project_filter_layout.count():
            item = self.project_filter_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        selected = self.saved_project_filters()
        self.project_filter_buttons = {}
        status_names = {tag["name"] for tag in self.project_status_tags()}
        selected |= {f"status:{name}" for name in status_names if name in selected}
        definitions = [
            ("__untagged__", "No status", "#56616a"),
            *((f"status:{tag['name']}", tag["name"], tag["color"]) for tag in self.project_status_tags()),
            *((f"tag:{tag['name']}", tag["name"], tag["color"]) for tag in self.project_other_tags()),
            ("__archive__", "Archive", ARCHIVE_COLOR),
        ]
        for key, label, color in definitions:
            button = QPushButton(label)
            button.setObjectName("projectFilterButton")
            button.setCheckable(True)
            button.setChecked(key in selected)
            button.setStyleSheet(f"QPushButton:checked{{background:{color};border-color:{color};color:white}}")
            button.toggled.connect(self.project_filter_changed)
            self.project_filter_layout.addWidget(button)
            self.project_filter_buttons[key] = button
        self.project_filter_layout.addStretch(1)

    def project_filter_changed(self, *_args) -> None:
        selected = [key for key, button in self.project_filter_buttons.items() if button.isChecked()]
        self.settings.setValue("project_tag_filters", json.dumps(selected))
        self.queue_settings_sync()
        if hasattr(self, "project_list"):
            self.filter_projects(self.project_search.text())

    def project_dock_visibility_changed(self, visible: bool) -> None:
        if visible:
            QTimer.singleShot(0, self.restore_project_panel_width)

    def remember_project_panel_width(self, width: int, height: int) -> None:
        if self._restoring_layout or self._loading:
            return
        bottom = self.dockWidgetArea(self.project_dock) in {Qt.DockWidgetArea.TopDockWidgetArea, Qt.DockWidgetArea.BottomDockWidgetArea}
        if bottom and not self.project_dock.isFloating():
            self.project_panel_height = max(160, height)
            self.settings.setValue("project_panel_height", self.project_panel_height)
        else:
            self.project_panel_width = max(280, width)
            self.settings.setValue("project_panel_width", self.project_panel_width)
        self.queue_settings_sync()

    def queue_project_panel_width_restore(self) -> None:
        if self._restoring_layout or self.project_dock.isHidden():
            return
        QTimer.singleShot(0, self.restore_project_panel_width)

    def restore_project_panel_width(self) -> None:
        """Preserve the user's extent for side or bottom dock layouts."""
        if self.project_dock.isFloating():
            return
        area = self.dockWidgetArea(self.project_dock)
        if area in {Qt.DockWidgetArea.TopDockWidgetArea, Qt.DockWidgetArea.BottomDockWidgetArea}:
            tab_height = 0
            if self.tabifiedDockWidgets(self.project_dock):
                title = self.project_dock.windowTitle().replace('&', '')
                for bar in self.findChildren(QTabBar):
                    if any(bar.tabText(index).replace('&', '') == title for index in range(bar.count())):
                        tab_height = bar.height()
                        break
            self.resizeDocks([self.project_dock], [self.project_panel_height + tab_height], Qt.Orientation.Vertical)
        else:
            self.set_project_panel_width(self.project_panel_width, persist=False)

    def restore_startup_workspace(self) -> None:
        """Settle saved geometry before loading the previous project's media timeline."""
        self.restore_project_panel_width()
        self.restore_timeline_panel_height()
        self.finish_layout_restore()
        splash = getattr(QApplication.instance(), '_director_splash', None)
        if splash:
            splash.set_status('Checking project thumbnails…')
            QApplication.processEvents()
        if needs_refresh():
            files = list(project_library_path().glob("*.meta.json"))
            if files:
                self.cache_dialog = PreviewCacheDialog(files, self)
                self.cache_dialog.finished.connect(lambda *_: QTimer.singleShot(0, self.restore_last_project))
                self.cache_dialog.finished.connect(lambda *_: self.refresh_project_library())
                if splash:
                    splash.finish(self)
                    QApplication.instance()._director_splash = None
                QTimer.singleShot(0, self.cache_dialog.start)
                return
            mark_ready()
        if splash:
            splash.set_status('Opening the last workspace…')
            QApplication.processEvents()
            splash.finish(self)
            QApplication.instance()._director_splash = None
        QTimer.singleShot(0, self.restore_last_project)

    def finish_layout_restore(self) -> None:
        self._restoring_layout = False

    def set_project_panel_width(self, width: int, persist: bool = True) -> None:
        width = max(280, int(width))
        self.project_panel_width = width
        if self.project_dock.isFloating():
            self.project_dock.resize(width, self.project_dock.height())
        else:
            self.resizeDocks([self.project_dock], [width], Qt.Orientation.Horizontal)
        if persist:
            self.settings.setValue("project_panel_width", width)
            self.queue_settings_sync()

    def update_project_icon_controls(self) -> None:
        labels = {96: "Small", 156: "Medium", 230: "Large"}
        self.project_icon_button.setText(f"Icons: {labels[self.project_icon_size]}")
        for size, action in self.project_icon_actions.items():
            action.setChecked(size == self.project_icon_size)
        card_width = self.project_icon_size + 28
        card_height = self.project_icon_size + 76
        self.project_list.setIconSize(QSize(self.project_icon_size, self.project_icon_size))
        self.project_list.setGridSize(QSize(card_width, card_height))

    def set_project_icon_size(self, size: int) -> None:
        size = min((96, 156, 230), key=lambda value: abs(value - int(size)))
        if size == self.project_icon_size:
            return
        self.project_icon_size = size
        self.settings.setValue("project_icon_size", size)
        self.update_project_icon_controls()
        self.refresh_project_library(preserve_scroll=False)

    def queue_settings_sync(self) -> None:
        self._settings_sync_timer.start()

    def save_window_panel_state(self) -> None:
        if self._restoring_layout:
            return
        self.settings.setValue("window/state", self.saveState())
        self.queue_settings_sync()

    def _apply_theme(self) -> None:
        scale = max(75, min(200, self.settings.value("ui_text_scale", 100, int))) / 100

        def scaled(size: int) -> int:
            return max(7, round(size * scale))

        def metric(size: int) -> int:
            return max(1, round(size * scale))

        theme = """
        QMainWindow,QWidget{background:#24292c;color:#d9dcde;font:11px Arial} QMainWindow::separator{width:__DOCK_GRIP_WIDTH__px;height:__DOCK_GRIP_WIDTH__px;background:transparent;background-repeat:no-repeat;background-position:center} QMainWindow::separator:vertical{background-image:url("__DOCK_GRIP_IMAGE__")} QMainWindow::separator:horizontal{background-image:url("__DOCK_GRIP_HORIZONTAL_IMAGE__")} QMainWindow::separator:hover{background-color:rgba(88,118,134,35)} QToolBar{background:#1b2023;border:0;border-bottom:1px solid #111517;spacing:3px;padding:5px} QToolBar::separator{background:#394247;width:1px;margin:7px 5px}
        QToolButton,QPushButton,QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit{background:#303436;border:1px solid #101213;border-radius:3px;padding:3px 7px;min-height:19px}
        #mainToolbar QToolButton{background:transparent;border:1px solid transparent;border-radius:4px;padding:5px 9px;color:#c5cdd1} #mainToolbar QToolButton:hover{background:#2b3438;border-color:#3a464c;color:#f3f7f9} #mainToolbar QToolButton:pressed{background:#17232a;border-color:#477d99;color:#bde6fb} #toolbarButton{background:#23343d;border:1px solid #385667;border-radius:5px;color:#c4e8fb;font-weight:bold}
        #minimaxPromptToolbar{background:#1b2023;border:1px solid #354047;border-radius:6px} #minimaxCacheState{background:#2b3438;color:#aebbc1;border:1px solid #435159;border-radius:9px;padding:2px 8px;font-size:9px} #minimaxCacheState[cached="true"]{background:#244d37;color:#c9f4d6;border-color:#4c9b6a} #minimaxInstructions{background:#1b2023;border:1px solid #37464d;border-radius:4px;color:#d8e1e5;padding:7px} #minimaxMessagePanel{background:#20313a;border:1px solid #49758a;border-radius:6px} #minimaxMessagePanel[level="success"]{background:#20392c;border-color:#4b8962} #minimaxMessagePanel[level="warning"]{background:#3a321f;border-color:#8a7340} #minimaxMessagePanel[level="timeline"]{background:#3a321f;border-color:#b4974a} #minimaxMessagePanel[level="error"]{background:#3a2325;border-color:#94555a} #minimaxMessageBanner{background:transparent;color:#ccecf8;border:0;padding:1px} #minimaxMessagePanel[level="success"] #minimaxMessageBanner{color:#cef2d9} #minimaxMessagePanel[level="warning"] #minimaxMessageBanner{color:#f2dfb0} #minimaxMessagePanel[level="timeline"] #minimaxMessageBanner{color:#f2dfb0} #minimaxMessagePanel[level="error"] #minimaxMessageBanner{color:#f2c5c8} #minimaxRetryButton{background:#5b451b;color:#ffe7a1;border:1px solid #c79a39;border-radius:4px;font-weight:bold;padding:4px 10px} #minimaxRetryButton:hover{background:#755b25;border-color:#e2bc5a;color:#fff5cf} #minimaxBusyCard{background:#17262d;border:1px solid #65a7c7;border-radius:8px} #minimaxBusyStatus{background:transparent;color:#d9f2ff;font-weight:bold;padding:2px}
        QToolButton:hover,QPushButton:hover{background:#41474a} QToolButton:pressed,QPushButton:pressed{background:#202729;border-color:#79a8c5} QLineEdit{background:#1e2122}
        QSpinBox,QDoubleSpinBox{padding-right:__SPIN_PAD__px} QSpinBox::up-button,QDoubleSpinBox::up-button{subcontrol-origin:border;subcontrol-position:top right;width:__SPIN_BUTTON__px;background:#3b4347;border:0;border-left:1px solid #171a1c;border-bottom:1px solid #202527;border-top-right-radius:3px} QSpinBox::down-button,QDoubleSpinBox::down-button{subcontrol-origin:border;subcontrol-position:bottom right;width:__SPIN_BUTTON__px;background:#343b3f;border:0;border-left:1px solid #171a1c;border-top:1px solid #202527;border-bottom-right-radius:3px}
        QSpinBox::up-button:hover,QDoubleSpinBox::up-button:hover,QSpinBox::down-button:hover,QDoubleSpinBox::down-button:hover{background:#506471} QSpinBox::up-button:pressed,QDoubleSpinBox::up-button:pressed,QSpinBox::down-button:pressed,QDoubleSpinBox::down-button:pressed{background:#274e66} QSpinBox::up-arrow,QDoubleSpinBox::up-arrow,QSpinBox::down-arrow,QDoubleSpinBox::down-arrow{width:__ARROW_SIZE__px;height:__ARROW_SIZE__px}
        QComboBox{padding-right:__COMBO_PAD__px} QComboBox::drop-down{subcontrol-origin:padding;subcontrol-position:top right;width:__COMBO_BUTTON__px;background:#394145;border:0;border-left:1px solid #171a1c;border-top-right-radius:3px;border-bottom-right-radius:3px} QComboBox::drop-down:hover{background:#506471} QComboBox::drop-down:pressed{background:#274e66} QComboBox::down-arrow{width:__ARROW_SIZE__px;height:__ARROW_SIZE__px} QComboBox QAbstractItemView{background:#202527;color:#e1e5e7;border:1px solid #52616a;outline:0;padding:4px;selection-background-color:#3b6f9c;selection-color:#fff}
        QSlider::groove:horizontal{height:__SLIDER_GROOVE__px;background:#161b1d;border:1px solid #0d1011;border-radius:__SLIDER_RADIUS__px} QSlider::sub-page:horizontal{background:#367da6;border:1px solid #4b9ac6;border-radius:__SLIDER_RADIUS__px} QSlider::add-page:horizontal{background:#161b1d;border-radius:__SLIDER_RADIUS__px} QSlider::handle:horizontal{width:__SLIDER_HANDLE__px;margin:-__SLIDER_MARGIN__px 0;background:#607883;border:2px solid #8fb9cd;border-radius:__SLIDER_HANDLE_RADIUS__px} QSlider::handle:horizontal:hover{background:#78a8be;border-color:#c5ebff} QSlider::handle:horizontal:pressed{background:#4aa3d2;border-color:#e1f6ff}
        #timelineShell{background:#0d0f10;border:1px solid #323638;border-radius:3px} #mainTrackLabel{background:#191c1d;border-right:1px solid #34383a;font-weight:bold}
        #timelineTitle{background:#19262d;color:#b9def2;border:1px solid #304955;border-radius:4px;padding:4px 8px;font-weight:bold;letter-spacing:1px} #timelineControlLabel{background:transparent;color:#7f9099;border:0;font-size:9px;font-weight:bold;letter-spacing:1px}
        #outputSizeControl{background:#1a2023;border:1px solid #354047;border-radius:5px} #timelineSpin{background:transparent;border:0;border-radius:0;padding-left:9px;padding-right:__TIMELINE_SPIN_PAD__px;color:#e6edf1;font-weight:bold;selection-background-color:#3b6f9c} #timelineSpin:hover{background:#20292d} #timelineSpin:focus{background:#202b30;color:#fff}
        #timelineSpin::up-button{width:__TIMELINE_SPIN_BUTTON__px;background:transparent;border:0;border-radius:2px;subcontrol-origin:border;subcontrol-position:top right} #timelineSpin::down-button{width:__TIMELINE_SPIN_BUTTON__px;background:transparent;border:0;border-radius:2px;subcontrol-origin:border;subcontrol-position:bottom right} #timelineSpin::up-button:hover,#timelineSpin::down-button:hover{background:#344b57} #timelineSpin::up-button:pressed,#timelineSpin::down-button:pressed{background:#1f668b} #timelineSpin::up-arrow{image:url("__SPIN_UP_IMAGE__");width:__TIMELINE_ARROW__px;height:__TIMELINE_ARROW__px} #timelineSpin::down-arrow{image:url("__SPIN_DOWN_IMAGE__");width:__TIMELINE_ARROW__px;height:__TIMELINE_ARROW__px}
        #resolutionSeparator{background:transparent;color:#60717a;border:0;padding:0 3px;font-weight:bold} #timelineButton{background:transparent;color:#acd8ef;border:1px solid #3f6679;border-radius:5px;padding:4px 10px;font-weight:bold} #timelineButton:hover{background:#243b46;color:#e0f5ff;border-color:#65a7c7} #timelineButton:pressed{background:#172b35;color:#85c9eb;border-color:#347898}
        QListWidget{background:#0d0f10;border:0;padding:0} QListWidget::item{border:1px solid #696b6c;background:#252728;margin:0} QListWidget::item:selected{border:2px solid #f1f1f1;background:#293034}
        #mediaCatalogPanel{border:1px solid transparent} #mediaCatalogPanel[dropActive="true"]{border:3px solid #68b9ee;background:#13232c}
        #timeline{padding:3px;background:#0d0f10;outline:0} #timeline::item,#timeline::item:selected,#timeline::item:focus{background:#0d0f10;border:0;outline:0} #timeline[dropActive="true"]{border:3px solid #68b9ee;background:#13232c} #timeline[dropActive="false"]{border:1px solid #323638}
        #segmentCard{background:transparent;border:1px solid transparent} #segmentCard[selected="true"]{background:#17262e;border:1px solid #73a9c4} #segmentCardBody{background:#252728;border:0} #mediaBadge{background:#e5e5e5;color:#262626;font-weight:bold;padding:2px} #roleBadge{background:#36393a;color:#eee;padding:2px}
        #tileDelete{padding:0;min-height:0;max-height:20px;background:#454849;color:#ddd;border:0} #tileDelete:hover{background:#a94444;color:#fff;border:1px solid #e07878} #tileTitle{background:#242627;padding:3px;font-size:9px} #tileStartTime{color:#79b8d7;font-size:8px;font-weight:bold} #tileDuration{color:#a2a7a9;font-size:8px}
        #resizeHandle{background:transparent;border:0} #resizeHandle:hover{background:rgba(88,118,134,35);border:0}
        #timelineHeightHandle{background:transparent;border:0} #timelineHeightHandle:hover{background:rgba(88,118,134,35);border:0}
        #promptSplitter::handle{background:transparent;border:0} #promptSplitter::handle:hover{background:rgba(88,118,134,35);border:0}
        #segmentPreview{background:#17191a;border-top:1px solid #34383a}
        #addTileBox{border:1px dashed #596065;background:#111415} #addTile,#addTextTile{border:0;border-radius:0;background:transparent;color:#828b90;font-size:10px;text-align:center} #addTile:hover,#addTextTile:hover{background:#1c2326;color:#b7d7e6} #sequenceBar{background:#181e21;border:1px solid #303a3f;border-left:3px solid #4e91b4;border-radius:5px;padding:10px 12px;color:#cbd7dd;font-weight:bold}
        #directorPanel{background:#1d2326;border:1px solid #354047;border-radius:6px} #panelTitle{background:transparent;color:#b8d9e9;border:0;font-size:10px;font-weight:bold;letter-spacing:1px} #groupLabel{background:transparent;color:#71838c;border:0;font-size:8px;font-weight:bold;letter-spacing:1px;padding-right:4px}
        #sectionLabel{color:#8ebbd1;font-size:8px;font-weight:bold;letter-spacing:1px} #muted{color:#879095;font-size:9px} #promptPanel{background:#202527;border:1px solid #374044;border-radius:6px} #segmentMetaBar{background:#1a2023;border:1px solid #303a3f;border-radius:5px} #refineButton{background:#252d31;border:1px solid #45545b;color:#c9dce5;padding-left:9px;padding-right:9px} #refineButton:hover{background:#31414a;border-color:#6590a7;color:#f2fbff} #refineButton:pressed{background:#1d2b32;border-color:#7ca9bf} #refineButton:disabled{background:#202527;border-color:#31393d;color:#606a6f}
        QTextEdit{background:#252728;border:0;color:#e1e4e5;font:11px 'Courier New';padding:4px} #promptEditor{background:#202527;border:0;color:#e1e4e5;padding:7px} #magicButton{background:#3b78a5;border:1px solid #5b9bc6;border-radius:5px;color:#f4fbff;font-weight:bold;padding-left:12px;padding-right:12px} #magicButton:hover{background:#4b8dbd;border-color:#8bc6ea} #magicButton:pressed{background:#285b7c}
        #audioToggle,#qualityToggle,#frameToggle{background:transparent;border:1px solid #455057;color:#b8c0c4} #audioToggle:hover,#qualityToggle:hover,#frameToggle:hover{background:#293236;border-color:#65747c;color:#eef3f5} #audioToggle:checked,#qualityToggle:checked,#frameToggle:checked{background:#244d37;border-color:#4c9b6a;color:#c9f4d6} #copyButton{min-height:0;padding:1px 4px;margin:0;border:0;background:transparent;color:#aeb5b8} #copyButton:hover{background:#303a3f;color:#e5f4fc;border:0} #copyButton:pressed{background:#1b2429;color:#8fd3f7;border:0} QStatusBar{background:#171c1e;color:#7f898d;border-top:1px solid #30383c}
        QDockWidget{background:#191d1f;color:#d9dcde;font-weight:bold} QDockWidget::title{background:#1b2022;border-bottom:1px solid #0e1011;padding:8px;text-align:left}
        #projectLibraryTitle,#magicOverlayTitle{font-size:15px;font-weight:bold;color:#f0f2f3} #libraryControls{background:#1c2225;border:1px solid #343e43;border-radius:5px} #projectSearch{background:#171c1e;border:1px solid #343d41;border-radius:5px;padding-left:10px} #projectSearch:focus{border-color:#4d829d;background:#1b2225} #projectList{background:#15191b;border:1px solid #30383c;border-radius:5px;padding:10px} #projectList[dropActive="true"]{border:3px solid #68b9ee;background:#13232c}
        #projectList::item{background:transparent;border:1px solid #363f43;border-radius:6px;margin:4px;padding:7px;color:#dce0e2} #projectList::item:hover{border-color:#6488a1} #projectList::item:selected{border:2px solid #69a5d0}
        #projectFilters{background:#171c1e;border:1px solid #30383c;border-radius:5px} #projectFilterButton{min-height:17px;padding:2px 6px;background:#23292c;border-color:#394348;color:#aeb8bd} #projectFilterButton:hover{background:#303a3f;color:#fff} #projectNotesList{background:#171b1d;border:1px solid #3a4449;border-radius:4px;padding:3px} #projectNotesList::item{background:transparent;border:0;margin:2px;padding:0} #projectNoteRow{background:#22282b;border:1px solid #394348;border-radius:4px} #projectNoteRow:hover{border-color:#5e8295;background:#283136} #projectNoteDate{color:#86a9ba;font-size:9px} #projectNoteDelete{min-height:0;padding:0;background:transparent;border:0;color:#bca6a6;font-size:15px} #projectNoteDelete:hover{background:#713d3d;color:white}
        #projectPreviewPanel{border:1px solid transparent;background:#191d1f} #projectPreviewPanel[dropActive="true"]{border:3px solid #68b9ee;background:#13232c} #previewTitle{background:#1a2023;border:1px solid #354047;border-radius:4px;padding:5px;color:#d7ebf5;font-weight:bold} #previewEmpty{background:#101314;border:1px dashed #4a565c;border-radius:4px;padding:24px;color:#87959c} #previewSectionTitle{color:#8ebbd1;font-size:8px;font-weight:bold;letter-spacing:1px} #projectWorkflowList{background:#171b1d;border:1px solid #354047;border-radius:4px;padding:3px} #projectWorkflowList[dropActive="true"]{border:3px solid #68b9ee;background:#13232c} #projectWorkflowList::item{background:#22282b;border:1px solid #394348;border-radius:3px;margin:2px;padding:4px} #projectWorkflowList::item:selected{background:#294356;border-color:#69a5d0}
        #librarySave{background:#3b78a5;border-color:#5994bd;font-weight:bold} #librarySave:hover{background:#5596ca;border-color:#8bc8f5;color:#fff} #librarySave:pressed{background:#214865;border:1px solid #b9e1ff;color:#fff} #librarySecondary{background:transparent;border-color:#3d484e;color:#bfc7cb} #librarySecondary:hover{background:#30393d;border-color:#596a73;color:#fff} #libraryDelete{background:transparent;border-color:#4b3b3b;color:#c8b7b7} #libraryDelete:hover{background:#713d3d;border-color:#9b5656;color:#fff}
        QMenu{background:#252a2c;border:1px solid #596267;padding:4px} QMenu::item{padding:7px 28px 7px 12px;border-radius:3px} QMenu::item:selected{background:#3b6f9c;color:#fff} QMenu::separator{height:1px;background:#4b5255;margin:4px 7px}
        QScrollBar:vertical{background:#171b1d;width:12px;margin:0;border:0;border-radius:6px} QScrollBar::handle:vertical{background:#46545c;min-height:28px;margin:2px;border-radius:4px} QScrollBar::handle:vertical:hover{background:#63869b} QScrollBar::handle:vertical:pressed{background:#74a8c6}
        QScrollBar:horizontal{background:#171b1d;height:12px;margin:0;border:0;border-radius:6px} QScrollBar::handle:horizontal{background:#46545c;min-width:28px;margin:2px;border-radius:4px} QScrollBar::handle:horizontal:hover{background:#63869b} QScrollBar::handle:horizontal:pressed{background:#74a8c6}
        QScrollBar::add-line,QScrollBar::sub-line{width:0;height:0;background:transparent;border:0} QScrollBar::up-arrow,QScrollBar::down-arrow,QScrollBar::left-arrow,QScrollBar::right-arrow{width:0;height:0;background:transparent} QScrollBar::add-page,QScrollBar::sub-page{background:transparent} QAbstractScrollArea::corner{background:#171b1d;border:0}
        """
        theme = theme.replace("font:11px Arial", f"font:{scaled(11)}px Arial")
        theme = theme.replace("font:11px 'Courier New'", f"font:{scaled(11)}px 'Courier New'")
        theme = theme.replace("spacing:6px;padding:5px", f"spacing:{metric(6)}px;padding:{metric(5)}px")
        theme = theme.replace("padding:3px 7px;min-height:19px", f"padding:{metric(3)}px {metric(7)}px;min-height:{metric(19)}px")
        theme = theme.replace("width:12px;margin:0", f"width:{metric(12)}px;margin:0")
        theme = theme.replace("height:12px;margin:0", f"height:{metric(12)}px;margin:0")
        theme = theme.replace("min-height:28px;margin:2px", f"min-height:{metric(28)}px;margin:{metric(2)}px")
        theme = theme.replace("min-width:28px;margin:2px", f"min-width:{metric(28)}px;margin:{metric(2)}px")
        theme = theme.replace("__SPIN_PAD__", str(metric(30))).replace("__SPIN_BUTTON__", str(metric(23)))
        theme = theme.replace("__COMBO_PAD__", str(metric(30))).replace("__COMBO_BUTTON__", str(metric(25)))
        theme = theme.replace("__ARROW_SIZE__", str(metric(8)))
        theme = theme.replace("__SLIDER_GROOVE__", str(metric(6))).replace("__SLIDER_RADIUS__", str(metric(3)))
        theme = theme.replace("__SLIDER_HANDLE__", str(metric(16))).replace("__SLIDER_MARGIN__", str(metric(6))).replace("__SLIDER_HANDLE_RADIUS__", str(metric(8)))
        dock_grip = str(files("ltx_prompt_director").joinpath("assets/dock-grip.png")).replace("\\", "/")
        dock_grip_horizontal = str(files("ltx_prompt_director").joinpath("assets/dock-grip-horizontal.png")).replace("\\", "/")
        theme = theme.replace("__DOCK_GRIP_WIDTH__", str(metric(14))).replace("__DOCK_GRIP_IMAGE__", dock_grip).replace("__DOCK_GRIP_HORIZONTAL_IMAGE__", dock_grip_horizontal)
        spin_up = str(files("ltx_prompt_director").joinpath("assets/spin-up.svg")).replace("\\", "/")
        spin_down = str(files("ltx_prompt_director").joinpath("assets/spin-down.svg")).replace("\\", "/")
        theme = theme.replace("__SPIN_UP_IMAGE__", spin_up).replace("__SPIN_DOWN_IMAGE__", spin_down)
        theme = theme.replace("__TIMELINE_SPIN_PAD__", str(metric(20))).replace("__TIMELINE_SPIN_BUTTON__", str(metric(17))).replace("__TIMELINE_ARROW__", str(metric(8)))
        for size in (15, 10, 9, 8):
            theme = theme.replace(f"font-size:{size}px", f"font-size:{scaled(size)}px")
        self.setStyleSheet(theme)
        self.timeline_controls.setSpacing(metric(8))
        self.output_width.setFixedWidth(metric(104))
        self.output_height.setFixedWidth(metric(104))
        self.ui_scale_spin.setFixedWidth(metric(82))
        self.intent.setFixedHeight(metric(72))
        self.requested_length.setFixedWidth(metric(82))
        self.speaker_language.setMinimumWidth(metric(170))
        self.speaker_accent.setMinimumWidth(metric(170))
        self.director_controls.setSpacing(metric(8))
        self.segment_header.setSpacing(metric(8))
        self.ruler.setFixedHeight(metric(28))
        self.timeline_height_handle.set_scale(scale)
        self.project_list.setSpacing(metric(4))
        for button in (self.provider_button, self.sfx, self.spoken_dialog, self.hdr, self.reduce_music, self.magic_button, self.refine_timing_button, self.refine_prompt_button, self.start_button, self.end_button):
            button.setMinimumWidth(button.fontMetrics().horizontalAdvance(button.text()) + metric(18))
        self.output_width.setMinimumWidth(metric(92))
        self.output_height.setMinimumWidth(metric(92))
        self.duration_spin.setFixedWidth(metric(82))
        self.add_tile_wrap.setFixedWidth(metric(128))
        self.add_tile_layout.setContentsMargins(metric(8), 0, metric(8), 0)
        for button in (self.copy_segment,):
            button.setFixedHeight(button.fontMetrics().height() + metric(4))
            button.setMinimumWidth(button.fontMetrics().horizontalAdvance(button.text()) + metric(10))
        if hasattr(self, "timeline_loading"):
            self.timeline_loading.set_scale(scale)
        if hasattr(self, "magic_overlay"):
            self.magic_overlay.set_scale(scale)

    def refresh_project_library(self, select_id: str | None = None, preserve_scroll: bool = True) -> None:
        self._refreshing_project_library = True
        selected = select_id or self.current_project_id
        previous_scroll = self.project_list.verticalScrollBar().value() if preserve_scroll else 0
        if self.project_list._scroll_animation:
            self.project_list._scroll_animation.stop()
            self.project_list._scroll_animation = None
        self.project_list._scroll_target = previous_scroll
        self.project_list.clear()
        records = self.library_records()
        self.collection_up.setVisible(bool(self.current_collection))
        self.project_library_title.setText(self.current_collection or "Saved projects")
        visible_records = [record for record in records if record.get("collection", "") == (self.current_collection or "")]
        entries: list[dict] = [{**record, "kind": "project"} for record in visible_records]
        if not self.current_collection:
            collections: dict[str, list[dict]] = {}
            for record in records:
                if record.get("collection"):
                    collections.setdefault(str(record["collection"]), []).append(record)
            for name, members in collections.items():
                members.sort(key=lambda value: value.get("savedAt", ""), reverse=True)
                entries.append({"kind": "collection", "name": name, "description": f"{len(members)} projects", "members": members})
        mode = self.project_sort.currentData() if hasattr(self, "project_sort") else "title_asc"
        reverse = mode == "title_desc"
        if mode in {"title_asc", "title_desc"}:
            entries.sort(key=lambda value: str(value.get("name", "")).casefold(), reverse=reverse)
        else:
            order = self.custom_project_order()
            positions = {key: index for index, key in enumerate(order)}
            entries.sort(key=lambda value: (positions.get(self.project_entry_key(value), len(positions)), str(value.get("name", "")).casefold()))
        self.project_list.setDragDropMode(QListWidget.DragDropMode.NoDragDrop)
        self.project_list.setMovement(QListWidget.Movement.Static)
        selected_item = None
        for meta in entries:
            if meta.get("kind") == "collection":
                name = str(meta["name"])
                members = meta["members"]
                item = QListWidgetItem(f"{name}\n{len(members)} project{'s' if len(members) != 1 else ''}")
                item.setBackground(QColor("#22282b"))
                item.setData(Qt.ItemDataRole.UserRole, {"kind": "collection", "name": name, "description": meta["description"], "members": members})
                item.setToolTip(f"Collection: {name}")
                item.setSizeHint(QSize(self.project_icon_size + 28, self.project_icon_size + 76))
                collection_cover = self.collection_pixmap(members[:4], self.project_icon_size)
                item.setIcon(QIcon(collection_cover))
                self.project_list.addItem(item)
                continue
            name = str(meta.get("name") or "Untitled project")
            description = " ".join(str(meta.get("description") or "No description").split())
            if len(description) > 105:
                description = description[:102] + "…"
            item = QListWidgetItem(f"{name}\n{description}")
            item.setBackground(QColor("#22282b"))
            item.setData(Qt.ItemDataRole.UserRole, {**meta, "kind": "project"})
            item.setToolTip(f"{name}\n\n{meta.get('description', '')}")
            item.setSizeHint(QSize(self.project_icon_size + 28, self.project_icon_size + 76))
            cover = cover_path(str(meta.get("thumbnailData", ""))) if meta.get("thumbnailData") else None
            pixmap = QPixmap(str(cover)) if cover and cover.is_file() else pixmap_from_data_url(str(meta.get("thumbnailData", "")))
            if pixmap.isNull():
                pixmap = QPixmap(self.project_icon_size, self.project_icon_size)
                pixmap.fill(QColor("#171a1b"))
            else:
                pixmap = self.square_pixmap(pixmap, self.project_icon_size)
            tile_color = self.project_state_color(meta)
            if tile_color:
                item.setData(PROJECT_CARD_COLOR_ROLE, tile_color)
            labels = []
            status_colors = {tag["name"].casefold(): tag["color"] for tag in self.project_status_tags()}
            other_colors = {tag["name"].casefold(): tag["color"] for tag in self.project_other_tags()}
            status = str(meta.get("status", ""))
            if status:
                labels.append((status, status_colors.get(status.casefold(), "#56616a")))
            for label in meta.get("tags", []):
                labels.append((str(label), other_colors.get(str(label).casefold(), "#56616a")))
            if meta.get("archived"):
                labels.append(("Archive", ARCHIVE_COLOR))
            if labels:
                pixmap = self.add_thumbnail_labels(pixmap, labels)
            item.setIcon(QIcon(pixmap))
            self.project_list.addItem(item)
            if meta.get("id") == selected:
                selected_item = item
        if selected_item:
            self.project_list.setCurrentItem(selected_item)
        self.filter_projects(self.project_search.text())
        self._refreshing_project_library = False
        self.sync_project_properties()
        QTimer.singleShot(0, lambda value=previous_scroll: self.project_list.verticalScrollBar().setValue(value))

    def sync_project_properties(self) -> None:
        if not hasattr(self, "project_properties_panel") or getattr(self, "_refreshing_project_library", False):
            return
        chosen = self.selected_library_project()
        if chosen and chosen.get("kind") != "collection":
            self.project_properties_panel.set_project(chosen)
        elif self.current_project_id:
            self.project_properties_panel.set_project(self.current_library_metadata())
        else:
            self.project_properties_panel.set_project(None)

    @staticmethod
    def project_entry_key(meta: dict) -> str:
        return f"collection:{meta.get('name', '')}" if meta.get("kind") == "collection" else f"project:{meta.get('id', '')}"

    def project_state_color(self, meta: dict) -> str | None:
        if meta.get("archived"):
            return ARCHIVE_COLOR
        colors = {tag["name"].casefold(): tag["color"] for tag in self.project_status_tags()}
        return colors.get(str(meta.get("status", meta.get("tag", ""))).casefold())

    @staticmethod
    def add_thumbnail_labels(pixmap: QPixmap, labels: list[tuple[str, str]]) -> QPixmap:
        return add_thumbnail_labels(pixmap, labels)

    def custom_order_settings_key(self) -> str:
        return f"project_custom_order/{self.current_collection or '__root__'}"

    def custom_project_order(self) -> list[str]:
        try:
            value = json.loads(str(self.settings.value(self.custom_order_settings_key(), "[]")))
            return value if isinstance(value, list) else []
        except (ValueError, TypeError):
            return []

    def save_custom_project_order(self) -> None:
        if not hasattr(self, "project_sort") or self.project_sort.currentData() != "custom":
            return
        order = []
        for row in range(self.project_list.count()):
            order.append(self.project_entry_key(self.project_list.item(row).data(Qt.ItemDataRole.UserRole) or {}))
        self.settings.setValue(self.custom_order_settings_key(), json.dumps(order))

    def project_sort_changed(self) -> None:
        self.settings.setValue("project_sort_mode", self.project_sort.currentData())
        self.refresh_project_library()

    def activate_custom_sort_for_drag(self) -> None:
        if self.project_search.text():
            self.project_search.clear()
        if self.project_sort.currentData() == "custom":
            return
        current_order = []
        for row in range(self.project_list.count()):
            current_order.append(self.project_entry_key(self.project_list.item(row).data(Qt.ItemDataRole.UserRole) or {}))
        self.settings.setValue(self.custom_order_settings_key(), json.dumps(current_order))
        self.project_sort.blockSignals(True)
        self.project_sort.setCurrentIndex(self.project_sort.findData("custom"))
        self.project_sort.blockSignals(False)
        self.settings.setValue("project_sort_mode", "custom")

    def activate_clicked_project(self, item: QListWidgetItem) -> None:
        meta = item.data(Qt.ItemDataRole.UserRole) or {}
        if meta.get("kind") == "project":
            self._pending_project_id = str(meta.get("id", ""))
            self._project_open_timer.start()

    def activate_double_clicked_project(self, item: QListWidgetItem) -> None:
        """Open either a project or a collection from the same tile gesture."""
        meta = item.data(Qt.ItemDataRole.UserRole) or {}
        if meta.get("kind") == "collection":
            self._project_open_timer.stop()
            self._pending_project_id = None
            self.project_list.setCurrentItem(item)
            self.open_library_project()
            return
        self.activate_clicked_project(item)

    def open_pending_library_project(self) -> None:
        project_id = self._pending_project_id
        self._pending_project_id = None
        if project_id:
            self.open_library_project(project_id=project_id)

    def project_files_dropped(self, paths: list[str]) -> None:
        if not paths:
            return
        path = paths[0]
        if Path(path).suffix.casefold() == ".ltxd":
            self.open_project(path=path)
        else:
            self.import_ltx(path=path)

    def library_records(self) -> list[dict]:
        records = []
        for path in project_library_path().glob("*.meta.json"):
            try:
                meta = json.loads(path.read_text(encoding="utf-8"))
                if Path(meta.get("projectPath", "")).is_file():
                    normalize_project_labels(meta)
                    meta.setdefault("archived", False)
                    meta["notes"] = normalize_notes(meta.get("notes", []))
                    records.append(meta)
            except (OSError, ValueError, TypeError):
                continue
        records.sort(key=lambda value: value.get("savedAt", ""), reverse=True)
        return records

    @staticmethod
    def square_pixmap(pixmap: QPixmap, size: int) -> QPixmap:
        scaled = pixmap.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
        return scaled.copy(max(0, (scaled.width() - size) // 2), max(0, (scaled.height() - size) // 2), size, size)

    def collection_pixmap(self, members: list[dict], size: int) -> QPixmap:
        result = QPixmap(size, size)
        result.fill(QColor("#101314"))
        painter = QPainter(result)
        gap = max(2, round(size * .017))
        cell = (size - gap) // 2
        second = cell + gap
        cells = ((0, 0), (second, 0), (0, second), (second, second))
        line = max(3, round(size * .025))
        for member, (x, y) in zip(members, cells):
            pixmap = pixmap_from_data_url(str(member.get("thumbnailData", "")))
            if not pixmap.isNull():
                painter.drawPixmap(x, y, self.square_pixmap(pixmap, cell))
            color = self.project_state_color(member) or "#657078"
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(QColor(color).lighter(125), line))
            inset = max(1, line // 2)
            painter.drawRect(x + inset, y + inset, cell - line, cell - line)
        painter.end()
        return result

    def filter_projects(self, query: str) -> None:
        terms = query.casefold().split()
        selected = {key for key, button in self.project_filter_buttons.items() if button.isChecked()}
        statuses = {tag["name"].casefold(): tag["name"] for tag in self.project_status_tags()}
        selected_other = {key.removeprefix("tag:").casefold() for key in selected if key.startswith("tag:")}

        def visible(meta: dict) -> bool:
            notes = " ".join(str(note.get("text", "")) for note in meta.get("notes", []) if isinstance(note, dict))
            haystack = f"{meta.get('name', '')} {meta.get('description', '')} {meta.get('status', '')} {' '.join(meta.get('tags', []))} {notes}".casefold()
            if not all(term in haystack for term in terms):
                return False
            if meta.get("archived"):
                return "__archive__" in selected
            status = str(meta.get("status", "")).casefold()
            status_key = f"status:{statuses[status]}" if status in statuses else "__untagged__"
            if status_key not in selected:
                return False
            labels = {str(tag).casefold() for tag in meta.get("tags", [])}
            return not selected_other or bool(labels & selected_other)

        for row in range(self.project_list.count()):
            item = self.project_list.item(row)
            meta = item.data(Qt.ItemDataRole.UserRole) or {}
            if meta.get("kind") == "collection":
                item.setHidden(not any(visible(member) for member in meta.get("members", [])))
            else:
                item.setHidden(not visible(meta))

    def selected_library_project(self) -> dict | None:
        item = self.project_list.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def current_library_metadata(self) -> dict | None:
        if not self.current_project_id:
            return None
        path = project_library_path() / f"{self.current_project_id}.meta.json"
        try:
            meta = json.loads(path.read_text(encoding="utf-8"))
            normalize_project_labels(meta)
            return meta
        except (OSError, ValueError, TypeError):
            return None

    def update_project_preview(self) -> None:
        meta = self.current_library_metadata()
        if not meta:
            self.project_preview_panel.clear_project()
            self.project_files_panel.clear_project()
            return
        project_files = meta.get("projectFiles", meta.get("workflowFiles", []))
        project_files = [value for value in project_files if isinstance(value, dict) and Path(str(value.get("path", ""))).is_file()]
        name = str(meta.get("name") or "Untitled project")
        self.project_preview_panel.set_project(name, str(meta.get("previewVideoPath", "")))
        self.project_files_panel.set_project(name, project_files)

    def choose_project_video(self) -> None:
        initial = str(Path.home())
        meta = self.current_library_metadata()
        if meta and meta.get("previewVideoPath"):
            initial = str(Path(meta["previewVideoPath"]).parent)
        path = choose_document_open(self, "Choose rendered project video", initial, "Videos (*.mp4 *.webm *.mov *.mkv *.avi *.m4v)")
        if path:
            self.attach_project_video(path)

    def attach_project_video(self, source_path: str) -> None:
        meta = self.current_library_metadata()
        source = Path(source_path)
        if not meta:
            QMessageBox.information(self, "Save project first", "Save or open a project before adding its rendered video.")
            return
        if not source.is_file() or source.suffix.lower() not in ProjectVideoWidget.VIDEO_SUFFIXES:
            QMessageBox.warning(self, "Unsupported video", "Choose an MP4, WebM, MOV, MKV, AVI, or M4V video.")
            return
        preview_dir = project_library_path() / "previews"
        preview_dir.mkdir(parents=True, exist_ok=True)
        safe_name = safe_media_filename(source.name, "project_preview")
        destination = preview_dir / f"{meta['id']}_{safe_name}"
        previous = Path(str(meta.get("previewVideoPath", "")))
        try:
            if source.resolve() != destination.resolve():
                shutil.copy2(source, destination)
            if previous.is_file() and previous.resolve() != destination.resolve() and previous.parent == preview_dir:
                previous.unlink()
        except OSError as error:
            QMessageBox.critical(self, "Video import failed", str(error))
            return
        meta["previewVideoPath"] = str(destination)
        meta["previewVideoName"] = source.name
        self.persist_library_metadata(meta)
        self.project_preview_panel.set_project(str(meta.get("name") or "Untitled project"), str(destination))
        self.project_preview_dock.show()
        self.statusBar().showMessage(f"Rendered video saved to project: {meta.get('name', 'Untitled project')}")

    def export_project_video(self) -> None:
        meta = self.current_library_metadata()
        source = Path(str(meta.get("previewVideoPath", ""))) if meta else Path()
        if not meta or not source.is_file():
            QMessageBox.information(self, "No project video", "Add a rendered video to this project first.")
            return
        original = str(meta.get("previewVideoName") or source.name)
        target = self.next_export_path(original)
        self.start_disk_job(shutil.copy2, (source, target), lambda _result: self.record_export(target),
                            lambda message: self.export_failed(target, message), serialized=True)

    def choose_project_workflow(self) -> None:
        source_name = choose_document_open(self, "Add project file", str(Path.home()), "All files (*)")
        if source_name:
            self.attach_project_workflow(source_name)

    def attach_project_workflow(self, source_name: str) -> None:
        meta = self.current_library_metadata()
        if not meta:
            QMessageBox.information(self, "Save project first", "Save or open a project before adding project files.")
            return
        source = Path(source_name)
        if not source.is_file():
            QMessageBox.warning(self, "Project file missing", "The dropped project file could not be found.")
            return
        workflow_dir = project_library_path() / "project_files"
        workflow_dir.mkdir(parents=True, exist_ok=True)
        destination = workflow_dir / f"{meta['id']}_{uuid4().hex[:8]}_{safe_media_filename(source.name, 'project_file')}"
        try:
            shutil.copy2(source, destination)
        except OSError as error:
            QMessageBox.critical(self, "Project file import failed", str(error))
            return
        workflows = [value for value in meta.get("projectFiles", meta.get("workflowFiles", [])) if isinstance(value, dict)]
        workflows.append({"name": source.name, "path": str(destination)})
        meta["projectFiles"] = workflows
        meta.pop("workflowFiles", None)
        self.persist_library_metadata(meta)
        self.update_project_preview()
        self.project_files_dock.show()
        self.statusBar().showMessage(f"Project file added: {source.name}")

    def export_project_workflow(self) -> None:
        workflow = self.project_files_panel.selected_file()
        source = Path(str(workflow.get("path", ""))) if workflow else Path()
        if not workflow or not source.is_file():
            return
        target = self.next_export_path(str(workflow.get("name") or source.name))
        self.start_disk_job(shutil.copy2, (source, target), lambda _result: self.record_export(target),
                            lambda message: self.export_failed(target, message), serialized=True)

    def remove_project_workflow(self) -> None:
        meta = self.current_library_metadata()
        selected = self.project_files_panel.selected_file()
        if not meta or not selected:
            return
        selected_path = Path(str(selected.get("path", "")))
        meta["projectFiles"] = [
            value for value in meta.get("projectFiles", meta.get("workflowFiles", []))
            if not isinstance(value, dict) or str(value.get("path", "")) != str(selected_path)
        ]
        meta.pop("workflowFiles", None)
        try:
            if selected_path.is_file() and selected_path.parent in {project_library_path() / "project_files", project_library_path() / "workflows"}:
                selected_path.unlink()
        except OSError as error:
            QMessageBox.warning(self, "Project file removal warning", str(error))
        self.persist_library_metadata(meta)
        self.update_project_preview()
        self.statusBar().showMessage(f"Project file removed: {selected.get('name', selected_path.name)}")

    def project_library_menu(self, point) -> None:
        item = self.project_list.itemAt(point)
        if not item:
            return
        self.project_list.setCurrentItem(item)
        meta = item.data(Qt.ItemDataRole.UserRole) or {}
        menu = QMenu(self)
        is_collection = meta.get("kind") == "collection"
        members = meta.get("members", []) if is_collection else [meta]
        state_menu = menu.addMenu("Set group status" if is_collection else "Set status")
        status_group = QActionGroup(state_menu)
        status_group.setExclusive(True)
        clear = state_menu.addAction("No status")
        clear.setCheckable(True)
        status_group.addAction(clear)
        clear.setChecked(all(not member.get("status") for member in members))
        clear.triggered.connect(lambda: self.set_selected_project_status(""))
        for tag in self.project_status_tags():
            action = state_menu.addAction(tag["name"])
            action.setCheckable(True)
            status_group.addAction(action)
            action.setChecked(bool(members) and all(str(member.get("status", "")).casefold() == tag["name"].casefold() for member in members))
            action.triggered.connect(lambda checked=False, name=tag["name"]: self.set_selected_project_status(name))

        other_definitions = self.project_other_tags()
        if other_definitions:
            labels_menu = menu.addMenu("Group tags" if is_collection else "Tags")
            for tag in other_definitions:
                action = labels_menu.addAction(tag["name"])
                action.setCheckable(True)
                action.setChecked(bool(members) and all(tag["name"].casefold() in {str(value).casefold() for value in member.get("tags", [])} for member in members))
                action.triggered.connect(lambda checked, name=tag["name"]: self.set_selected_project_label(name, checked))

        menu.addSeparator()
        all_archived = bool(members) and all(member.get("archived") for member in members)
        archive = menu.addAction(
            "Restore entire group" if is_collection and all_archived else
            "Archive entire group" if is_collection else
            "Restore from archive" if all_archived else "Archive project"
        )
        archive.triggered.connect(self.toggle_archive_selected)
        if is_collection:
            menu.exec(self.project_list.viewport().mapToGlobal(point))
            return
        menu.addSeparator()
        menu.addAction("Open project", self.open_library_project)
        menu.addAction("Edit project details", self.edit_library_project)
        menu.addAction("Delete project", self.delete_library_project)
        menu.exec(self.project_list.viewport().mapToGlobal(point))

    def persist_library_metadata(self, meta: dict) -> None:
        clean = {key: value for key, value in meta.items() if key not in {"kind", "members"}}
        normalize_project_labels(clean)
        root = project_library_path()
        (root / f"{clean['id']}.meta.json").write_text(json.dumps(clean, indent=2), encoding="utf-8")
        self.start_disk_job(_persist_library_archive, (copy.deepcopy(clean), root / f"{clean['id']}.meta.json"),
                            lambda _result: None,
                            lambda message: QMessageBox.warning(self, "Project metadata save failed", message), serialized=True)
        if getattr(self, "project_properties_panel", None) and str(clean["id"]) == self.current_project_id:
            self.project_properties_panel.set_project(clean)

    def selected_project_members(self) -> tuple[dict | None, list[dict]]:
        meta = self.selected_library_project()
        return meta, (meta.get("members", []) if meta and meta.get("kind") == "collection" else [meta] if meta else [])

    def set_selected_project_status(self, name: str) -> None:
        meta, members = self.selected_project_members()
        if not meta:
            return
        for member in members:
            member["status"] = name
            member["tag"] = name
            self.persist_library_metadata(member)
        self.refresh_project_library(str(meta.get("id", "")) or None)
        subject = f"group {meta.get('name', 'Collection')} ({len(members)} projects)" if meta.get("kind") == "collection" else f"project {meta.get('name', 'Untitled project')}"
        self.statusBar().showMessage(f"Status set to {name or 'No status'} for {subject}")

    def set_selected_project_label(self, name: str, enabled: bool) -> None:
        meta, members = self.selected_project_members()
        if not meta:
            return
        for member in members:
            labels = [str(value) for value in member.get("tags", []) if str(value).casefold() != name.casefold()]
            if enabled:
                labels.append(name)
            member["tags"] = labels
            self.persist_library_metadata(member)
        self.refresh_project_library(str(meta.get("id", "")) or None)
        self.statusBar().showMessage(f"Tag {'added to' if enabled else 'removed from'} {len(members)} project{'s' if len(members) != 1 else ''}: {name}")

    def toggle_archive_selected(self) -> None:
        meta, members = self.selected_project_members()
        if not meta:
            return
        archived = not (bool(members) and all(member.get("archived") for member in members))
        for member in members:
            member["archived"] = archived
            self.persist_library_metadata(member)
        self.refresh_project_library(str(meta.get("id", "")) or None)
        action = "Archived" if archived else "Restored"
        subject = f"group: {meta.get('name', 'Collection')} ({len(members)} projects)" if meta.get("kind") == "collection" else f"project: {meta.get('name', 'Untitled project')}"
        self.statusBar().showMessage(f"{action} {subject}")

    def project_is_dirty(self, project_id: str) -> bool:
        if project_id == self.current_project_id:
            return self.project_dirty
        return bool(self.project_sessions.get(project_id, {}).get("dirty"))

    def capture_workspace_state(self) -> dict:
        self.store_minimax_draft()
        return {
            "projectType": self.project_type,
            "workspaceDefinition": copy.deepcopy(self.workspace_definition),
            "downloadDirectory": self.download_directory,
            "minimaxDrafts": {key: dict(value) for key, value in self.minimax_drafts.items()},
            "minimaxCueActions": dict(self._action_descriptions),
            "segments": self.segments,
            "globalPrompt": self.global_prompt.toPlainText(),
            "directorIntent": self.intent.toPlainText(),
            "requestedLength": self.requested_length.value(),
            "speakerLanguage": self.speaker_language.currentText(),
            "speakerAccent": self.speaker_accent.currentText(),
            "sfx": self.sfx.isChecked(),
            "spokenDialog": self.spoken_dialog.isChecked(),
            "hdr": self.hdr.isChecked(),
            "reduceMusic": self.reduce_music.isChecked(),
            "outputWidth": self.output_width.value(),
            "outputHeight": self.output_height.value(),
            "timelineScale": self.pixels_per_second,
            "timelineAutoFit": self.timeline_fit_mode,
            "timelineHeight": self.timeline_height,
            "minimaxPrompt": self.minimax_prompt_text,
            "minimaxRefinementInstructions": self.minimax_refinement_instructions,
            "minimaxPromptCacheKey": self.minimax_prompt_cache_key,
            "minimaxPromptUpdatedAt": self.minimax_prompt_updated_at,
            "minimaxPromptMode": self.minimax_prompt_mode,
            "minimaxReferenceImages": reference_slots(self.minimax_reference_images),
        }

    def cache_current_workspace(self) -> None:
        if not self.current_project_id:
            return
        self.project_sessions[self.current_project_id] = {
            "name": self.current_project_name,
            "dirty": self.project_dirty,
            "state": self.capture_workspace_state(),
        }

    def restore_workspace_state(self, state: dict) -> None:
        self._loading = True
        self.workspace_revision += 1
        self.segments = state.get("segments", [])
        self.download_directory = str(state.get("downloadDirectory", ""))
        self.global_prompt.setPlainText(str(state.get("globalPrompt", "")))
        self.intent.setPlainText(str(state.get("directorIntent", "")))
        render_prompt_notes(self.intent)
        self.requested_length.setValue(requested_length_value(state.get("requestedLength")))
        self.speaker_language.setCurrentText(str(state.get("speakerLanguage", "(Image/context provided)")))
        self.speaker_accent.setCurrentText(str(state.get("speakerAccent", state.get("speakerNationality", "(Image/context provided)"))))
        self.sfx.setChecked(bool(state.get("sfx")))
        self.spoken_dialog.setChecked(bool(state.get("spokenDialog")))
        self.hdr.setChecked(bool(state.get("hdr")))
        self.reduce_music.setChecked(bool(state.get("reduceMusic")))
        self.output_width.setValue(int(state.get("outputWidth", 1280)))
        self.output_height.setValue(int(state.get("outputHeight", 704)))
        self.timeline_height = max(184, min(430, int(state.get("timelineHeight", 184))))
        self.minimax_prompt_text = str(state.get("minimaxPrompt", ""))
        self.minimax_refinement_instructions = str(state.get("minimaxRefinementInstructions", ""))
        self.minimax_prompt_cache_key = str(state.get("minimaxPromptCacheKey", ""))
        self.minimax_prompt_updated_at = str(state.get("minimaxPromptUpdatedAt", ""))
        self.minimax_prompt_mode = "references" if state.get("minimaxPromptMode") == "references" else "frames"
        self.minimax_reference_images = reference_slots(state.get("minimaxReferenceImages"))
        self.restore_project_type(state.get("projectType"), state.get("minimaxDrafts"))
        self.timeline_height_handle.current_height = self.timeline_height
        self.set_timeline_height(self.timeline_height)
        auto_fit = bool(state.get("timelineAutoFit", False))
        scale = max(1, min(160, int(state.get("timelineScale", 65))))
        self.timeline_scale.blockSignals(True)
        self.timeline_scale.setValue(0 if auto_fit else scale)
        self.timeline_scale.blockSignals(False)
        self.pixels_per_second = scale
        self.timeline_fit_mode = auto_fit
        self.ruler.set_scale(scale)
        self._loading = False
        self._timeline_signature = tuple((item.id, item.duration, item.prompt, item.kind, item.role, item.name) for item in self.segments)
        self._action_segment_ids = [item.id for item in self.segments]
        self._action_descriptions = {str(key): str(value) for key, value in (state.get("minimaxCueActions") or self._action_descriptions or {}).items()}
        if self._action_descriptions and "[TIMED ACTION]" in self.minimax_prompt_text:
            self.minimax_prompt_text = compose_actions(self.minimax_prompt_text, self.segments,
                                                      [self._action_descriptions.get(segment.id, segment.prompt) for segment in self.segments])
        self.sync_minimax_panel()
        self.refresh_timeline()
        if auto_fit:
            self.apply_timeline_fit()
        self.queue_project_panel_width_restore()

    def leave_collection(self) -> None:
        self.current_collection = None
        self.refresh_project_library(preserve_scroll=False)

    def save_library_project(self, automatic: bool = False, source_filename: str | None = None) -> None:
        if not self.segments and not self.current_project_id:
            if not automatic:
                QMessageBox.information(self, "Nothing to save", "Add at least one image, WebM, MP4, or text segment first.")
            return
        root = project_library_path()
        meta = None
        if self.current_project_id:
            meta_path = root / f"{self.current_project_id}.meta.json"
            if meta_path.exists():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    normalize_project_labels(meta)
                except (OSError, ValueError):
                    meta = None
        if not meta:
            project_id = self.current_project_id or uuid4().hex
            if automatic:
                intent = " ".join(self.intent.toPlainText().split())
                source_name = Path(self.segments[0].name).stem if self.segments else "Sequence"
                suggested = Path(source_filename).stem.strip() if source_filename else (re.split(r"[.!?]", intent, maxsplit=1)[0].strip() if intent else source_name)
                suggested = suggested[:52].rstrip(" -—,:;") or "Magic Build"
                existing_names = {str(record.get("name", "")).casefold() for record in self.library_records()}
                name = suggested
                suffix = 2
                while name.casefold() in existing_names:
                    name = f"{suggested} ({suffix})"
                    suffix += 1
                meta = {
                    "id": project_id,
                    "name": name,
                    "description": f"Imported from {Path(source_filename).name}." if source_filename else (intent or f"Magic Build sequence generated from {source_name}."),
                    "collection": self.current_collection or "",
                    "projectPath": str(root / f"{project_id}.LTXD"),
                    "status": "", "tags": [], "tag": "", "archived": False, "notes": [],
                }
            else:
                collections = [str(record.get("collection")) for record in self.library_records() if record.get("collection")]
                dialog = ProjectDetailsDialog(self.intent.toPlainText(), self, collection=self.current_collection or "", collections=collections, download_directory=self.download_directory)
                if not dialog.exec():
                    return
                self.download_directory = dialog.download_folder.text().strip()
                meta = {
                    "id": project_id,
                    "name": dialog.name.text().strip(),
                    "description": dialog.description.toPlainText().strip(),
                    "collection": dialog.collection_name(),
                    "projectPath": str(root / f"{project_id}.LTXD"),
                    "status": "", "tags": [], "tag": "", "archived": False, "notes": dialog.notes_value(),
                }
            self.current_project_id = project_id
            self.current_project_name = meta["name"]
            if "downloadDirectory" in meta:
                self.download_directory = str(meta["downloadDirectory"])
            self.update_window_title()
        meta["downloadDirectory"] = self.download_directory
        meta["savedAt"] = datetime.now(timezone.utc).isoformat()
        meta["duration"] = self.total_duration()
        meta["segmentCount"] = len(self.segments)
        if not meta.get("thumbnailSource"):
            visual = next((segment for segment in self.segments if segment.kind != "text" and segment.preview_path), None)
            meta["thumbnailData"] = data_url(visual.preview_path, max_edge=360, quality=84) if visual else ""
        payload = self.project_payload(include_media=False)
        normalize_project_labels(meta)
        payload["library"] = {key: meta.get(key, "") for key in ("id", "name", "description", "collection", "savedAt", "status", "tags", "tag", "archived", "notes", "previewVideoPath", "previewVideoName", "projectFiles", "workflowFiles", "downloadDirectory")}
        project_id = str(meta["id"])
        save_id = uuid4().hex
        self._latest_save_id[project_id] = save_id
        edit_serial = self._edit_serial
        snapshot = copy.deepcopy(self.segments)
        workspace = self.capture_workspace_state()
        self.statusBar().showMessage(f"Saving project in background: {meta['name']}…")

        def saved(_result):
            if self._latest_save_id.get(project_id) != save_id:
                return
            if self.current_project_id == project_id and self._edit_serial == edit_serial:
                self.project_dirty = False
                self.project_sessions[project_id] = {"name": meta["name"], "dirty": False, "state": workspace}
            elif self.current_project_id != project_id:
                session = self.project_sessions.get(project_id)
                if session and session.get("state") == workspace:
                    session["dirty"] = False
            self.refresh_project_library(self.current_project_id)
            if self.current_project_id == project_id:
                self.update_project_preview()
                self.settings.setValue("last_project_id", project_id)
                self.queue_settings_sync()
            self.statusBar().showMessage(f"Project saved to library: {meta['name']}")

        def failed(message):
            self._close_after_jobs = False
            self._close_saves_queued = False
            if self._closing_progress:
                self._closing_progress.close()
                self._closing_progress = None
                self.show()
            self.project_dirty = True
            QMessageBox.critical(self, "Save failed", message)

        self.start_disk_job(_write_library_archive,
                            (str(meta["projectPath"]), payload, snapshot, root / f"{project_id}.meta.json", copy.deepcopy(meta)),
                            saved, failed, serialized=True)

    def open_library_project(self, checked: bool = False, project_id: str | None = None) -> None:
        self._project_open_timer.stop()
        self._pending_project_id = None
        if project_id:
            meta = next((record for record in self.library_records() if str(record.get("id", "")) == project_id), None)
        else:
            meta = self.selected_library_project()
        if not meta:
            return
        if meta.get("kind") == "collection":
            self._open_serial += 1
            self.current_collection = str(meta["name"])
            self.project_search.clear()
            self.refresh_project_library(preserve_scroll=False)
            return
        project_id = str(meta["id"])
        if project_id == self.current_project_id:
            self._open_serial += 1
            return
        self._open_serial += 1
        request = self._open_serial
        self.stage_current_workspace()
        self.cache_current_workspace()

        def apply_project(payload=None):
            if request != self._open_serial:
                return
            try:
                session = self.project_sessions.get(project_id)
                if payload is None and session and session.get("state"):
                    self.restore_workspace_state(session["state"])
                    dirty = bool(session.get("dirty"))
                else:
                    self.load_project_payload(payload)
                    dirty = False
                self.download_directory = str(meta.get("downloadDirectory", self.download_directory))
                self.current_project_id = project_id
                self.current_project_name = str(meta["name"])
                self.project_dirty = dirty
                self.project_sessions[project_id] = {
                    "name": self.current_project_name,
                    "dirty": dirty,
                    "state": self.capture_workspace_state(),
                }
                self.update_window_title()
                self.refresh_project_library(project_id)
                self.update_project_preview()
                self.settings.setValue("last_project_id", project_id)
                self.queue_settings_sync()
                self.statusBar().showMessage(f"Project opened: {meta['name']}")
            except Exception as error:
                self._loading = False
                QMessageBox.critical(self, "Project open failed", str(error))

        session = self.project_sessions.get(project_id)
        if session and session.get("state"):
            apply_project()
            return
        self.statusBar().showMessage(f"Opening project in background: {meta['name']}…")
        self.start_disk_job(read_project, (meta["projectPath"],), apply_project,
                            lambda message: QMessageBox.critical(self, "Project open failed", message))

    def delete_library_project(self) -> None:
        meta = self.selected_library_project()
        if not meta:
            return
        if meta.get("kind") == "collection":
            QMessageBox.information(self, "Collection contains projects", "Open the collection and move or delete its projects individually.")
            return
        answer = QMessageBox.question(
            self,
            "Delete project",
            f"Delete ‘{meta.get('name', 'this project')}’ from the local project library?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        project_path = Path(meta.get("projectPath", ""))
        meta_path = project_library_path() / f"{meta.get('id')}.meta.json"
        if self.current_project_id == meta.get("id"):
            self.project_preview_panel.player.stop()
            self.project_preview_panel.player.setSource(QUrl())
        attached_paths = [Path(str(meta.get("previewVideoPath", "")))]
        attached_paths.extend(Path(str(value.get("path", ""))) for value in meta.get("projectFiles", meta.get("workflowFiles", [])) if isinstance(value, dict))
        for attached in attached_paths:
            if attached.is_file() and attached.parent in {project_library_path() / "previews", project_library_path() / "project_files", project_library_path() / "workflows"}:
                attached.unlink()
        if project_path.is_file():
            project_path.unlink()
        if meta_path.is_file():
            meta_path.unlink()
        self.project_sessions.pop(str(meta.get("id", "")), None)
        if self.current_project_id == meta.get("id"):
            self.current_project_id = None
            self.project_dirty = True
            self.update_project_preview()
        self.refresh_project_library()
        self.statusBar().showMessage(f"Project deleted: {meta.get('name', 'Untitled project')}")

    def restore_last_project(self) -> None:
        """Open the saved library project that was active at the previous shutdown."""
        project_id = str(self.settings.value("last_project_id", "") or "")
        if not project_id:
            return
        meta = next((record for record in self.library_records() if str(record.get("id", "")) == project_id), None)
        if not meta:
            self.settings.remove("last_project_id")
            return
        self.current_collection = str(meta.get("collection", "")) or None
        self.refresh_project_library(project_id, preserve_scroll=False)
        for row in range(self.project_list.count()):
            item = self.project_list.item(row)
            value = item.data(Qt.ItemDataRole.UserRole) or {}
            if value.get("kind") == "project" and str(value.get("id", "")) == project_id:
                self.project_list.setCurrentItem(item)
                self.open_library_project()
                return

    def edit_library_project(self) -> None:
        meta = self.selected_library_project()
        if not meta or meta.get("kind") != "project":
            return
        collections = [str(record.get("collection")) for record in self.library_records() if record.get("collection")]
        try:
            thumbnail_options = project_thumbnail_data(meta["projectPath"])
        except (OSError, ValueError, TypeError):
            thumbnail_options = []
        dialog = ProjectDetailsDialog(
            str(meta.get("description", "")), self, name=str(meta.get("name", "")),
            collection=str(meta.get("collection", "")), collections=collections,
            thumbnail_options=thumbnail_options, thumbnail_data=str(meta.get("thumbnailData", "")),
            thumbnail_source=str(meta.get("thumbnailSource", "")),
            notes=meta.get("notes", []),
            download_directory=self.download_directory if meta["id"] == self.current_project_id else str(meta.get("downloadDirectory", "")),
        )
        if not dialog.exec():
            return
        thumbnail_source, thumbnail_data = dialog.selected_thumbnail()
        meta.update({
            "name": dialog.name.text().strip(),
            "description": dialog.description.toPlainText().strip(),
            "collection": dialog.collection_name(),
            "thumbnailSource": thumbnail_source,
            "thumbnailData": thumbnail_data,
            "notes": dialog.notes_value(),
            "downloadDirectory": dialog.download_folder.text().strip(),
            "savedAt": datetime.now(timezone.utc).isoformat(),
        })
        self.persist_library_metadata(meta)
        if self.current_project_id == meta["id"]:
            self.current_project_name = meta["name"]
            if "downloadDirectory" in meta:
                self.download_directory = str(meta["downloadDirectory"])
            self.update_window_title()
            self.update_project_preview()
        if str(meta["id"]) in self.project_sessions:
            self.project_sessions[str(meta["id"])]["name"] = meta["name"]
        self.refresh_project_library(meta["id"])
        self.statusBar().showMessage(f"Project details updated: {meta['name']}")

    def update_window_title(self) -> None:
        self.setWindowTitle(application_window_title(self.current_project_name))
        self.sync_minimax_panel()

    def queue_closing_projects(self) -> None:
        """Save every dirty workspace only after the user requests app close."""
        self.stage_current_workspace()
        self.cache_current_workspace()
        active_id, active_name = self.current_project_id, self.current_project_name
        active_state = self.capture_workspace_state()
        active_dirty = self.project_dirty
        dirty = [(project_id, dict(session)) for project_id, session in self.project_sessions.items()
                 if session.get("dirty") and session.get("state")]
        for project_id, session in dirty:
            self.current_project_id = project_id
            self.current_project_name = session.get("name", "Untitled")
            self.restore_workspace_state(session["state"])
            self.project_dirty = True
            self.save_library_project(automatic=True)
        self.current_project_id, self.current_project_name = active_id, active_name
        if dirty:
            self.restore_workspace_state(active_state)
            self.project_dirty = active_dirty
            self.update_window_title()
        self._close_saves_queued = True

    def update_closing_progress(self) -> None:
        if not self._closing_progress:
            return
        progress = self._closing_progress.findChild(QProgressBar, "closeProgressBar")
        if progress:
            progress.setMaximum(max(1, self._closing_total))
            progress.setValue(self._closing_total - self._pending_disk_jobs)
        label = self._closing_progress.findChild(QLabel, "closeProgressLabel")
        if label:
            label.setText(f"Saving projects… {self._closing_total - self._pending_disk_jobs} of {self._closing_total} complete")
        if self._closing_progress.isVisible():
            if label:
                label.repaint()
            if progress:
                progress.repaint()
            self._closing_progress.repaint()

    def show_closing_progress(self) -> None:
        if not self.isVisible() or self._closing_progress:
            return
        dialog = QDialog(None)
        dialog.setWindowTitle("Finishing project saves")
        dialog.setModal(True)
        dialog.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.CustomizeWindowHint | Qt.WindowType.WindowTitleHint)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 18, 22, 18)
        layout.setSpacing(10)
        label = QLabel("Saving projects…")
        label.setObjectName("closeProgressLabel")
        layout.addWidget(label)
        bar = QProgressBar()
        bar.setObjectName("closeProgressBar")
        bar.setTextVisible(True)
        bar.setMinimumHeight(24)
        layout.addWidget(bar)
        # Use a consistent window size while allowing large system fonts to fit.
        hint = dialog.sizeHint()
        dialog.setFixedSize(max(420, hint.width()), max(112, hint.height()))
        self._closing_progress = dialog
        self._closing_total = self._pending_disk_jobs
        self.update_closing_progress()
        dialog.show()
        self.hide()
        dialog.raise_()
        dialog.repaint()
        # Saving snapshots may take time on the GUI thread; paint before it starts.
        QApplication.processEvents(QEventLoop.ProcessEventsFlag.ExcludeUserInputEvents)

    def closeEvent(self, event) -> None:
        if not self._close_saves_queued:
            needs_save = self.project_dirty or any(session.get("dirty") for session in self.project_sessions.values())
            if needs_save or self._pending_disk_jobs:
                self.show_closing_progress()
            self.queue_closing_projects()
            self._closing_total = self._pending_disk_jobs
            self.update_closing_progress()
        if self._pending_disk_jobs:
            self._close_after_jobs = True
            self.statusBar().showMessage("Finishing background project saves before closing…")
            self.show_closing_progress()
            event.ignore()
            return
        if self._closing_progress:
            self._closing_progress.close()
            self._closing_progress = None
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        if hasattr(self, "project_preview_panel"):
            self.project_preview_panel.player.stop()
            if self.project_preview_panel.fullscreen_window.isVisible():
                self.project_preview_panel.fullscreen_window.reject()
        if hasattr(self, "project_dock"):
            self.settings.setValue("project_panel_width", self.project_panel_width)
            self.settings.setValue("project_panel_height", self.project_panel_height)
        if self.current_project_id:
            self.settings.setValue("last_project_id", self.current_project_id)
        else:
            self.settings.remove("last_project_id")
        self.settings.setValue("window/geometry", self.saveGeometry())
        self.settings.setValue("window/state", self.saveState())
        self.settings.sync()
        super().closeEvent(event)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if hasattr(self, "magic_overlay") and self.magic_overlay.isVisible():
            self.magic_overlay.setGeometry(self.rect())
        if getattr(self, "timeline_fit_mode", False) and hasattr(self, "_timeline_fit_timer"):
            self._timeline_fit_timer.start()

    def mark_dirty(self, *_args) -> None:
        if not self._loading:
            self._edit_serial += 1
            was_dirty = self.project_dirty
            self.project_dirty = True
            signature = tuple((item.id, item.duration, item.prompt, item.kind, item.role, item.name) for item in self.segments)
            timeline_changed = signature != self._timeline_signature
            if timeline_changed:
                previous = {item[0]: item[2] for item in self._timeline_signature}
                for item in self.segments:
                    if item.id in previous and item.prompt != previous[item.id]:
                        self._changed_action_sources.add(item.id)
                        self._action_descriptions[item.id] = item.prompt.strip()
            self._timeline_signature = signature
            if timeline_changed and self.unified_workspace and self.minimax_prompt_text.strip():
                self.sync_timed_actions(timeline_changed=True)
            if self.current_project_id:
                session = self.project_sessions.setdefault(self.current_project_id, {"name": self.current_project_name})
                session["dirty"] = True
                if not was_dirty and hasattr(self, "project_list"):
                    self.refresh_project_library(self.current_project_id)

    def new_project(self) -> None:
        self.download_directory = ""
        self._open_serial += 1
        self.stage_current_workspace()
        if self.current_project_id:
            self.cache_current_workspace()
        self._loading = True
        self.segments = []
        self.current_project_id = None
        self.current_project_name = "Untitled"
        self.update_project_preview()
        self.intent.clear()
        self.requested_length.setValue(0)
        self.speaker_language.setCurrentText("(Image/context provided)")
        self.speaker_accent.setCurrentText("(Image/context provided)")
        self.segment_prompt.clear()
        self.global_prompt.clear()
        self.minimax_prompt_text = ""
        self.minimax_refinement_instructions = ""
        self.minimax_prompt_cache_key = ""
        self.minimax_prompt_updated_at = ""
        self.minimax_prompt_mode = "frames"
        self.minimax_reference_images = [None, None]
        self.minimax_drafts = {}
        self.project_type = "ltx" if "ltx" in self.workspace_definitions else next(iter(self.workspace_definitions), "")
        self.workspace_revision += 1
        self.apply_project_type_ui()
        self.sfx.setChecked(False)
        self.spoken_dialog.setChecked(False)
        self.hdr.setChecked(False)
        self.reduce_music.setChecked(False)
        self.output_width.setValue(1280)
        self.output_height.setValue(704)
        self._loading = False
        self.project_dirty = False
        self.refresh_timeline()
        self.update_window_title()
        self.statusBar().showMessage("New project ready")

    def set_timeline_scale(self, value: int) -> None:
        if value == 0:
            self.autofit_timeline()
            return
        self.timeline_fit_mode = False
        self.autofit_tail_extension = 0
        self.pixels_per_second = float(value)
        self.ruler.set_scale(value)
        self.update_timeline_layout()
        self.mark_dirty()

    def preserve_timeline_scale_for_growth(self, target_total: float) -> None:
        """Keep expanded AI/manual segments visibly wider instead of squeezing Auto fit."""
        if not self.timeline_fit_mode or target_total <= self.total_duration() + .005:
            return
        self.timeline_fit_mode = False
        scale = max(1, round(self.pixels_per_second))
        self.timeline_scale.blockSignals(True)
        self.timeline_scale.setMaximum(max(self.timeline_scale.maximum(), scale))
        self.timeline_scale.setValue(scale)
        self.timeline_scale.blockSignals(False)
        self.timeline_scale.setToolTip('Timeline scale; Auto fit is available from the button when you want all segments visible')

    def autofit_timeline(self) -> None:
        self.timeline_fit_mode = True
        self.timeline_scale.blockSignals(True)
        self.timeline_scale.setValue(0)
        self.timeline_scale.blockSignals(False)
        self.apply_timeline_fit()
        self.mark_dirty()

    def apply_timeline_fit(self) -> None:
        if not self.timeline_fit_mode:
            return
        total = self.total_duration()
        if total <= 0:
            return
        available = max(1, self.timeline.viewport().width() - 6)
        self.pixels_per_second = available / total
        self.ruler.set_scale(self.pixels_per_second)
        self.autofit_tail_extension = 0
        self.update_timeline_layout()
        self.timeline.horizontalScrollBar().setValue(0)

    def timeline_item_widths(self, durations: list[float] | None = None) -> list[int]:
        values = durations if durations is not None else [segment.duration for segment in self.segments]
        if not self.timeline_fit_mode:
            widths = [max(48, int(value * self.pixels_per_second)) for value in values]
            if widths:
                widths[-1] += self.autofit_tail_extension
            return widths
        available = max(1, self.timeline.viewport().width() - 6)
        total = sum(max(MIN_DURATION, value) for value in values)
        if durations is None and total > 0:
            self.pixels_per_second = available / total
            self.ruler.set_scale(self.pixels_per_second)
        boundaries = [0]
        elapsed = 0.0
        for value in values:
            elapsed += max(MIN_DURATION, value)
            boundaries.append(round(available * elapsed / total))
        widths = [max(1, boundaries[index + 1] - boundaries[index]) for index in range(len(values))]
        overflow = sum(widths) - available
        for index in range(len(widths) - 1, -1, -1):
            if overflow <= 0:
                break
            reduction = min(overflow, widths[index] - 1)
            widths[index] -= reduction
            overflow -= reduction
        return widths

    def maximum_safe_timeline_height(self) -> int:
        """Keep timeline growth inside the current desktop-sized client area."""
        if not hasattr(self, "timeline") or not self.centralWidget():
            return 430
        central = self.centralWidget()
        current = max(1, self.timeline.height())
        other_minimum = max(0, central.minimumSizeHint().height() - current)
        available_client_height = central.height()
        screen = self.screen() or QApplication.primaryScreen()
        if screen:
            window_overhead = max(0, self.frameGeometry().height() - central.height())
            desktop_client_height = max(0, screen.availableGeometry().height() - window_overhead)
            available_client_height = min(available_client_height, desktop_client_height)
        return max(184, min(430, available_client_height - other_minimum))

    def set_timeline_height(self, value: int) -> None:
        value = max(184, min(int(value), self.maximum_safe_timeline_height()))
        self.timeline_height = value
        self.timeline_height_handle.current_height = value
        self.timeline.setFixedHeight(value)
        self.add_tile_wrap.setFixedHeight(max(152, value - 32))
        self.update_timeline_layout()
        self.mark_dirty()

    def restore_timeline_panel_height(self) -> None:
        previous_loading = self._loading
        self._loading = True
        try:
            self.set_timeline_height(self.settings.value("timeline_panel_height", self.timeline_height, int))
        finally:
            self._loading = previous_loading

    def finish_timeline_height_resize(self) -> None:
        self.settings.setValue("timeline_panel_height", self.timeline_height)
        self.queue_settings_sync()
        self.update_timeline_layout()

    def apply_global_prefixes(self) -> None:
        text = self.global_prompt.toPlainText().strip()
        quality = "(4K, HDR, Realistic)"
        if self.hdr.isChecked() and not text.startswith(quality):
            text = f"{quality}\n{text}".strip()
        elif not self.hdr.isChecked() and text.startswith(quality):
            text = text[len(quality):].lstrip("\n ")
        self.global_prompt.setPlainText(text)

    def total_duration(self) -> float:
        return sum(item.duration for item in self.segments)

    def normalize_output_dimensions(self) -> None:
        for field in (self.output_width, self.output_height):
            normalized = max(256, min(4096, round(field.value() / 32) * 32))
            if field.value() != normalized:
                field.setValue(normalized)

    def add_media(self) -> None:
        paths = choose_media_files(self, True, self.settings.value("last_media_dir", str(Path.home())))
        if not paths:
            return
        self.add_media_paths(paths)

    def add_text_segment(self) -> None:
        number = sum(segment.kind == "text" for segment in self.segments) + 1
        segment = Segment(f"Text {number}", "", "", "text", "text", "", 5.0)
        self.segments.append(segment)
        self._extend_timed_actions_for_added_segments([segment])
        self.mark_dirty()
        self.refresh_timeline(len(self.segments) - 1)
        self.segment_prompt.setFocus()
        self.statusBar().showMessage("Text-only segment added; enter its prompt or use Magic Build")

    def _extend_timed_actions_for_added_segments(self, added: list[Segment]) -> bool:
        """Insert blank, linked cue blocks for new timeline items when the existing plan is sound."""
        if not added or not self.unified_workspace or not SECTION.search(self.minimax_prompt_text):
            return False
        added_ids = {item.id for item in added}
        previous_segments = [item for item in self.segments if item.id not in added_ids]
        descriptions, _ = split_actions(self.minimax_prompt_text)
        plan = parse_timed_plan(self.minimax_prompt_text)
        if (
            len(descriptions) != len(previous_segments)
            or len(plan) != len(previous_segments)
            or not all(cue["valid"] for cue in plan)
            or any(item.prompt_detached for item in previous_segments)
            or any(abs((cue["end"] - cue["start"]) - item.duration) > .5 / FPS + 1e-6
                   for cue, item in zip(plan, previous_segments))
        ):
            return False
        tagged = cue_cells(self.minimax_panel.editor) if self.minimax_panel else {}
        old_actions = [
            tagged.get(item.id, self._action_descriptions.get(item.id, descriptions[index]))
            for index, item in enumerate(previous_segments)
        ]
        old_by_id = dict(zip((item.id for item in previous_segments), old_actions))
        actions = [old_by_id.get(item.id, item.prompt.strip()) for item in self.segments]
        self.minimax_prompt_text = compose_actions(self.minimax_prompt_text, self.segments, actions)
        for item in added:
            self._action_descriptions[item.id] = item.prompt.strip()
        return True

    def add_media_paths(self, paths: list[str], insert_index: int | None = None) -> None:
        paths = [path for path in paths if Path(path).is_file()]
        if not paths:
            return
        options = self.workspace_definition.get("references", {})
        if not options.get("enabled", False):
            QMessageBox.information(self, "Workspace references", "This workspace accepts text segments only.")
            return
        kinds = options.get("kinds", [])
        allowed_paths = [path for path in paths if ("video" if Path(path).suffix.lower() in TIMELINE_VIDEO_SUFFIXES else "image") in kinds]
        if len(allowed_paths) != len(paths):
            self.statusBar().showMessage("Media types unsupported by this workspace were skipped.")
        paths = allowed_paths
        if not paths:
            return
        self.settings.setValue("last_media_dir", str(Path(paths[0]).parent))
        target = len(self.segments) if insert_index is None else max(0, min(insert_index, len(self.segments)))
        before_id = self.segments[target].id if target < len(self.segments) else None
        workspace = (self.workspace_revision, self.current_project_id)
        self.statusBar().showMessage(f"Preparing {len(paths)} media file(s) in background…")

        def ready(result):
            if workspace != (self.workspace_revision, self.current_project_id):
                return
            prepared, errors = result
            index = next((i for i, segment in enumerate(self.segments) if segment.id == before_id), len(self.segments))
            for path, kind, preview, frames, trim in prepared:
                duration = 1.0 if kind == "video" else 5.0
                self.segments.insert(index, Segment(Path(path).name, path, preview, kind, "end" if index % 2 else "start", duration=duration, media_duration_frames=frames, trim_start=trim))
                index += 1
            if prepared:
                self._extend_timed_actions_for_added_segments(self.segments[max(0, index - len(prepared)):index])
                self.mark_dirty()
                self.refresh_timeline(max(0, index - 1))
            if errors:
                QMessageBox.warning(self, "Media error", "\n".join(errors))
            self.statusBar().showMessage(f"Added {len(prepared)} media file{'s' if len(prepared) != 1 else ''}")

        self.start_disk_job(_prepare_media_batch, (paths,), ready,
                            lambda message: QMessageBox.warning(self, "Media error", message))

    def refresh_timeline(self, selected: int = 0) -> None:
        self.autofit_tail_extension = 0
        indicator = getattr(self, "timeline_loading", None) if self.segments else None
        if indicator:
            indicator.show_loading()
            indicator.repaint()
        self._loading = True
        try:
            self.timeline.clear()
            card_height = max(152, self.timeline_height - 32)
            preview_height = max(80, card_height - 55)
            widths = self.timeline_item_widths()
            start_time = 0.0
            for index, segment in enumerate(self.segments):
                item = QListWidgetItem()
                item.setData(Qt.ItemDataRole.UserRole, segment.id)
                item.setSizeHint(QSize(widths[index], card_height))
                self.timeline.addItem(item)
                card = SegmentCard(segment, start_time, preview_height, self.pixels_per_second)
                card.duration_changed.connect(lambda value, sid=segment.id: self.change_duration(sid, value))
                card.delete_requested.connect(lambda sid=segment.id: self.delete_by_id(sid))
                card.resize_finished.connect(lambda sid=segment.id: self.finish_resize(sid))
                card.set_timeline_edges(index == 0, index == len(self.segments) - 1)
                self.timeline.setItemWidget(item, card)
                start_time += segment.duration
            self._loading = False
            if self.segments:
                self.timeline.setCurrentRow(max(0, min(selected, len(self.segments) - 1)))
            self.update_summary()
        finally:
            self._loading = False
            if indicator:
                indicator.hide_loading()

    def update_timeline_layout(self) -> None:
        """Resize existing cards in place without rebuilding media-backed widgets."""
        if not hasattr(self, "timeline"):
            return
        self.timeline._cancel_smooth_scroll()
        previous_loading = self._loading
        self._loading = True
        try:
            card_height = max(152, self.timeline_height - 32)
            preview_height = max(80, card_height - 55)
            by_id = {segment.id: segment for segment in self.segments}
            widths = self.timeline_item_widths()
            start_time = 0.0
            for row in range(self.timeline.count()):
                item = self.timeline.item(row)
                segment = by_id.get(item.data(Qt.ItemDataRole.UserRole))
                if not segment:
                    continue
                width = widths[row] if row < len(widths) else 1
                item.setSizeHint(QSize(width, card_height))
                card = self.timeline.itemWidget(item)
                if isinstance(card, SegmentCard):
                    card.set_timeline_edges(row == 0, row == self.timeline.count() - 1)
                    card.set_start_time(start_time)
                    card.update_layout(preview_height, self.pixels_per_second)
                start_time += segment.duration
            self.timeline.doItemsLayout()
            self.update_summary()
        finally:
            self._loading = previous_loading

    def update_timeline_selection_style(self, selected_row: int) -> None:
        """Render selection on the card, not the QListWidget item beneath it."""
        for row in range(self.timeline.count()):
            card = self.timeline.itemWidget(self.timeline.item(row))
            if not isinstance(card, SegmentCard):
                continue
            detached = self.unified_workspace and self.segments[row].prompt_detached
            card.setEnabled(not detached)
            if detached and card.graphicsEffect() is None:
                effect = QGraphicsOpacityEffect(card)
                effect.setOpacity(0.4)
                card.setGraphicsEffect(effect)
            elif not detached and card.graphicsEffect() is not None:
                card.setGraphicsEffect(None)
            self.timeline.item(row).setFlags(self.timeline.item(row).flags() & ~Qt.ItemFlag.ItemIsEnabled if detached else self.timeline.item(row).flags() | Qt.ItemFlag.ItemIsEnabled)
            card.setToolTip("Detached from prompt: correct or refine the timed ranges to reconnect." if detached else "")
            selected = row == selected_row
            if card.property("selected") == selected:
                continue
            card.setProperty("selected", selected)
            card.style().unpolish(card)
            card.style().polish(card)
            card.update()

    def sync_order(self) -> None:
        if self._loading:
            return
        ordered_ids = [self.timeline.item(row).data(Qt.ItemDataRole.UserRole) for row in range(self.timeline.count())]
        self.segments = order_segments_by_ids(self.segments, ordered_ids)
        self.update_timeline_layout()
        self.mark_dirty()

    def update_segment_start_times(self) -> None:
        start_time = 0.0
        by_id = {segment.id: segment for segment in self.segments}
        for row in range(self.timeline.count()):
            item = self.timeline.item(row)
            segment = by_id.get(item.data(Qt.ItemDataRole.UserRole))
            if not segment:
                continue
            card = self.timeline.itemWidget(item)
            if isinstance(card, SegmentCard):
                card.set_start_time(start_time)
            start_time += segment.duration

    def current_segment(self) -> Segment | None:
        row = self.timeline.currentRow()
        return self.segments[row] if 0 <= row < len(self.segments) else None

    def load_editor(self, row: int) -> None:
        self._loading = True
        segment = self.current_segment()
        self.duration_spin.setMaximum(sys.float_info.max)
        self.duration_spin.setToolTip("Segment duration in seconds")
        self.duration_spin.setEnabled(bool(segment) and not (self.unified_workspace and segment.prompt_detached))
        self.refresh_shared_editor()
        visual = bool(segment and segment.kind != "text")
        self.start_button.setEnabled(visual)
        self.end_button.setEnabled(visual)
        self.start_button.setVisible(visual and self.workspace_engine != "minimax_frames")
        self.end_button.setVisible(visual and self.workspace_engine != "minimax_frames")
        self.refine_timing_button.setEnabled(not self.ai_busy and bool(segment))
        self.refine_prompt_button.setEnabled(not self.ai_busy and bool(self.segment_prompt.toPlainText().strip()) and (self.unified_workspace or self.prompt_scope.currentData() == "segment"))
        if segment:
            self.start_button.setChecked(segment.role == "start" if visual else False)
            self.end_button.setChecked(segment.role == "end" if visual else False)
            self.duration_spin.setValue(segment.duration)
            self.frame_number.setText(f"{'Text' if segment.kind == 'text' else 'Frame'} {row + 1}")
        else:
            self.frame_number.setText("Frame —")
        self._loading = False
        self.update_counts()
        if segment and self.unified_workspace:
            focus_cue(self.segment_prompt, segment.id)

    def reload_clicked_segment(self, item: QListWidgetItem) -> None:
        """Refresh prompt text when the clicked segment is already selected."""
        self.refresh_segment_prompt_box(self.timeline.row(item))
        if self.unified_workspace and self.current_segment():
            focus_cue(self.segment_prompt, self.current_segment().id)

    def refresh_segment_prompt_box(self, row: int) -> None:
        """Update only the segment prompt box, preserving all other editor state."""
        if not 0 <= row < len(self.segments):
            return
        previous_loading = self._loading
        self._loading = True
        try:
            self.refresh_shared_editor()
        finally:
            self._loading = previous_loading
        self.update_counts()

    def sync_selected_duration_control(self) -> None:
        """Keep the selected duration control synchronized with AI timing changes."""
        segment = self.current_segment()
        if not segment:
            return
        self.duration_spin.blockSignals(True)
        self.duration_spin.setMaximum(sys.float_info.max)
        self.duration_spin.setToolTip("Segment duration in seconds")
        self.duration_spin.setValue(segment.duration)
        self.duration_spin.blockSignals(False)

    def save_prompt(self) -> None:
        if self._loading:
            return
        if self.unified_workspace:
            self.minimax_editor_changed()
            self.update_counts()
            return
        if self.prompt_scope.currentData() == "global":
            self.global_prompt.blockSignals(True)
            self.global_prompt.setPlainText(self.segment_prompt.toPlainText())
            self.global_prompt.blockSignals(False)
            self.mark_dirty()
            self.update_counts()
            return
        if self.current_segment():
            self.current_segment().prompt = self.segment_prompt.toPlainText()
            self.refine_prompt_button.setEnabled(bool(self.current_segment().prompt.strip()))
            if self.current_segment().kind == "text":
                item = self.timeline.currentItem()
                card = self.timeline.itemWidget(item) if item else None
                if isinstance(card, SegmentCard):
                    card.set_text_preview(self.current_segment().prompt)
            self.mark_dirty()
            self.update_counts()

    def refresh_text_segment_previews(self) -> None:
        by_id = {segment.id: segment for segment in self.segments}
        for row in range(self.timeline.count()):
            item = self.timeline.item(row)
            segment = by_id.get(item.data(Qt.ItemDataRole.UserRole))
            card = self.timeline.itemWidget(item)
            if segment and segment.kind == "text" and isinstance(card, SegmentCard):
                card.set_text_preview(segment.prompt)

    def editor_duration_changed(self, value: float) -> None:
        if not self._loading and self.current_segment():
            self.change_duration(self.current_segment().id, value)
            self.update_timeline_layout()

    def set_role(self, role: str) -> None:
        segment = self.current_segment()
        if not segment or segment.kind == "text":
            return
        segment.role = role
        row = self.timeline.currentRow()
        item = self.timeline.item(row)
        card = self.timeline.itemWidget(item) if item else None
        if isinstance(card, SegmentCard):
            card.set_role(role)
        self.start_button.blockSignals(True)
        self.end_button.blockSignals(True)
        self.start_button.setChecked(role == "start")
        self.end_button.setChecked(role == "end")
        self.start_button.blockSignals(False)
        self.end_button.blockSignals(False)
        self.mark_dirty()

    def change_duration(self, segment_id: str, value: float) -> None:
        self.autofit_tail_extension = 0
        segment = next(item for item in self.segments if item.id == segment_id)
        self.preserve_timeline_scale_for_growth(sum(item.duration for item in self.segments) - segment.duration + value)
        segment.duration = max(MIN_DURATION, round(value, 2))
        self.mark_dirty()
        for row in range(self.timeline.count()):
            item = self.timeline.item(row)
            if item.data(Qt.ItemDataRole.UserRole) == segment_id:
                self.timeline.setUpdatesEnabled(False)
                try:
                    item.setSizeHint(QSize(max(48, int(segment.duration * self.pixels_per_second)), max(152, self.timeline_height - 32)))
                    self.timeline.doItemsLayout()
                finally:
                    self.timeline.setUpdatesEnabled(True)
                card = self.timeline.itemWidget(item)
                if isinstance(card, SegmentCard):
                    card.resize_handle.duration = segment.duration
                    card.duration_label.setText(f"{segment.duration:.2f}s")
                    card.update()
                    card.content.update()
                break
        self.timeline.viewport().update()
        self.update_segment_start_times()
        self.update_summary()

    def finish_resize(self, segment_id: str) -> None:
        self.update_timeline_layout()

    def update_summary(self) -> None:
        if self.minimax_panel:
            self.minimax_panel.refresh_references()
        total = self.total_duration()
        self.sequence_bar.setText(f"Sequence     Start: 0.00s  |  End: {total:.2f}s  |  Length: {total:.2f}s")
        self.add_tile.setText("＋\nAdd media")
        self.add_tile.setEnabled(True)
        self.add_text_tile.setEnabled(True)
        self.applied_label.setText(f"Applied across all {len(self.segments)} segments")
        visual_count = sum(segment.kind != "text" for segment in self.segments)
        text_count = len(self.segments) - visual_count
        self.statusBar().showMessage(f"{visual_count} visual · {text_count} text · {total:.2f}s")

    def update_counts(self) -> None:
        self.segment_count.setText(f"{len(self.segment_prompt.toPlainText())} characters")
        self.global_count.setText(f"{len(self.global_prompt.toPlainText())} characters")

    def update_provider_button(self) -> None:
        provider = self.settings.value("provider", "gemini")
        label = self.settings.value("gemini_model", GEMINI_MODELS[0]) if provider == "gemini" else "OpenAI"
        self.provider_button.setText(f"✦ {label.replace('gemini-', 'Gemini ').replace('-', ' ').title() if provider == 'gemini' else label}")

    def timeline_menu(self, point) -> None:
        item = self.timeline.itemAt(point)
        if not item:
            return
        target = self.segments[self.timeline.row(item)]
        if self.unified_workspace and target.prompt_detached:
            menu = QMenu(self)
            message = menu.addAction("Detached — correct the timed prompt to reconnect")
            message.setEnabled(False)
            menu.addAction("Refine prompt", self.refine_minimax_prompt)
            menu.exec(self.timeline.mapToGlobal(point))
            return
        self.timeline.setCurrentItem(item)
        segment = self.current_segment()
        menu = QMenu(self)
        if segment and segment.kind == "text":
            if not self.unified_workspace:
                menu.addAction("Edit text prompt", self.focus_segment_prompt)
            menu.addAction("Convert to image segment…", self.convert_text_segment_to_image)
        else:
            menu.addAction("Replace media", self.replace_selected)
            if segment and segment.kind == "image":
                menu.addAction("Copy image", self.copy_selected_image)
                paste_action = menu.addAction("Paste image to replace", self.paste_image_to_replace)
                paste_action.setEnabled(QApplication.clipboard().mimeData().hasImage())
            menu.addAction("Export video" if segment and segment.kind == "video" else "Export image", self.export_selected_segment)
            menu.addAction("Set as start frame", lambda: self.set_role("start"))
            menu.addAction("Set as end frame", lambda: self.set_role("end"))
        menu.addSeparator()
        menu.addAction("Delete segment", self.delete_selected)
        menu.exec(self.timeline.mapToGlobal(point))

    def focus_segment_prompt(self) -> None:
        self.prompt_scope.setCurrentIndex(0)
        self.segment_prompt.setFocus()

    def copy_selected_image(self) -> None:
        segment = self.current_segment()
        if not segment or segment.kind != "image":
            return
        source = Path(materialize_source(segment))
        if not source.is_file():
            QMessageBox.warning(self, "Image missing", "The full-resolution source image could not be found.")
            return
        reader = QImageReader(str(source))
        reader.setAutoTransform(True)
        image = reader.read()
        if image.isNull():
            QMessageBox.warning(self, "Copy failed", "The full-resolution source image could not be decoded.")
            return
        QApplication.clipboard().setImage(image)
        self.statusBar().showMessage(f"Full-resolution image copied: {image.width()} × {image.height()}")

    def paste_image_to_replace(self) -> None:
        segment = self.current_segment()
        if not segment or segment.kind != "image":
            return
        image = QApplication.clipboard().image()
        if image.isNull():
            QMessageBox.information(self, "No clipboard image", "Copy an image to the clipboard first.")
            return
        destination = APP_CACHE / f"clipboard-{uuid4().hex}.png"
        if not image.save(str(destination), "PNG"):
            QMessageBox.warning(self, "Paste failed", "The clipboard image could not be saved.")
            return
        row = self.timeline.currentRow()
        segment.name = f"clipboard-{datetime.now().strftime('%Y%m%d-%H%M%S')}.png"
        segment.media_path = str(destination)
        segment.preview_path = thumbnail_for_image(str(destination))
        segment.media_duration_frames = None
        segment.trim_start = None
        self.mark_dirty()
        self.refresh_timeline(row)
        self.statusBar().showMessage(f"Image replaced from clipboard at full resolution: {image.width()} × {image.height()}")

    def convert_text_segment_to_image(self) -> None:
        segment = self.current_segment()
        if not segment or segment.kind != "text":
            return
        initial = str(self.settings.value("last_media_dir", str(Path.home())))
        path = choose_document_open(self, "Choose image for text segment", initial, "Images (*.png *.jpg *.jpeg *.webp *.gif)")
        if not path:
            return
        try:
            kind, preview, frames, trim = prepare_media(path)
        except Exception as error:
            QMessageBox.warning(self, "Image error", f"{Path(path).name}: {error}")
            return
        if kind != "image":
            QMessageBox.warning(self, "Image required", "Choose a PNG, JPEG, WebP, or GIF image.")
            return
        row = self.timeline.currentRow()
        segment.name = Path(path).name
        segment.media_path = path
        segment.preview_path = preview
        segment.kind = "image"
        segment.role = "end" if row % 2 else "start"
        segment.media_duration_frames = frames
        segment.trim_start = trim
        self.settings.setValue("last_media_dir", str(Path(path).parent))
        self.mark_dirty()
        self.refresh_timeline(row)
        self.statusBar().showMessage(f"Text segment converted to image: {segment.name}; prompt preserved")

    def export_selected_segment(self) -> None:
        segment = self.current_segment()
        if not segment:
            return
        suffix = segment_media_suffix(segment)
        row = max(0, self.timeline.currentRow()) + 1
        target = self.next_export_path(f"{self.current_project_name} - Segment {row:02d}{suffix}")
        self.start_disk_job(_export_segment_source, (copy.deepcopy(segment), target), lambda _result: self.record_export(target),
                            lambda message: self.export_failed(target, message), serialized=True)

    def replace_selected(self) -> None:
        segment = self.current_segment()
        if not segment:
            return
        paths = choose_media_files(self, False, self.settings.value("last_media_dir", str(Path.home())))
        if not paths:
            return
        path = paths[0]
        self.settings.setValue("last_media_dir", str(Path(path).parent))
        try:
            kind, preview, frames, trim = prepare_media(path)
            segment.name, segment.media_path, segment.preview_path, segment.kind = Path(path).name, path, preview, kind
            segment.media_duration_frames, segment.trim_start = frames, trim
            self.mark_dirty()
            self.refresh_timeline(self.timeline.currentRow())
            self.statusBar().showMessage("Media replaced; timing, role and prompt preserved")
        except Exception as error:
            QMessageBox.critical(self, "Replace failed", str(error))

    def delete_selected(self) -> None:
        row = self.timeline.currentRow()
        if 0 <= row < len(self.segments):
            self.segments.pop(row)
            self.mark_dirty()
            self.refresh_timeline(max(0, row - 1))

    def delete_by_id(self, segment_id: str) -> None:
        row = next((index for index, segment in enumerate(self.segments) if segment.id == segment_id), -1)
        if row >= 0:
            self.segments.pop(row)
            self.mark_dirty()
            self.refresh_timeline(max(0, row - 1))

    def open_settings(self) -> None:
        if SettingsDialog(self.settings, self).exec():
            value = self.settings.value("ui_text_scale", 100, int)
            self.ui_scale_spin.blockSignals(True)
            self.ui_scale_spin.setValue(value)
            self.ui_scale_spin.blockSignals(False)
            self._apply_theme()
            self.update_provider_button()
            self.rebuild_project_filter_buttons()
            self.refresh_project_library()

    def set_ui_text_scale(self, value: int) -> None:
        value = max(75, min(200, value))
        self.settings.setValue("ui_text_scale", value)
        self._apply_theme()

    def update_spoken_dialog_controls(self, checked: bool) -> None:
        self.update_spoken_dialog_visibility()
        self.speaker_language.setEnabled(checked)
        self.speaker_accent.setEnabled(checked)
        self.mark_dirty()

    def build_director_request(self, *, include_requested_length: bool = True) -> str:
        """Compose focused planning controls into the authoritative model request."""
        lines = []
        creative_intent = self.intent.toPlainText().strip()
        if creative_intent:
            lines.append(creative_intent)
        if self.unified_workspace and self.hdr.isChecked():
            lines.append("HDR: preserve a high dynamic range cinematic look and visible highlight and shadow detail.")
        if not self.unified_workspace and not self.workspace_definition.get("global_prompt", True):
            lines.append("This workspace uses per-segment prompts only. Return an empty globalPrompt and keep required continuity in each segment prompt.")
        if not self.workspace_definition.get("audio_generation", True):
            lines.append("This workspace does not generate audio. Omit sound, music, speech and dialogue generation instructions.")
        requested_length = self.requested_length.value()
        if include_requested_length and requested_length > 0:
            if len(self.segments) == 1:
                item_label = "single text-only segment" if self.segments[0].kind == "text" else "single-frame sequence"
                lines.append(
                    f"Requested total sequence length: {requested_length:.1f} seconds. "
                    f"Because this is a {item_label}, return this exact duration for its one segment."
                )
            else:
                lines.append(
                    f"Requested total sequence length: {requested_length:.1f} seconds. "
                    "Distribute this duration across the supplied segments according to action complexity; the returned segment durations must add up to exactly this total."
                )
        if self.spoken_dialog.isChecked():
            context_default = "(Image/context provided)"
            language = self.speaker_language.currentText().strip() or context_default
            accent = self.speaker_accent.currentText().strip() or context_default
            lines.append(f"Speaker language selection: {language}. Speaker accent selection: {accent}.")
            if language.casefold() == context_default.casefold():
                lines.append(
                    "Determine the spoken language only from reliable context explicitly visible in the image or stated in Director's Intent, such as readable language or an unambiguous setting; otherwise use a culturally neutral language appropriate to the request."
                )
            if accent.casefold() == context_default.casefold():
                lines.append(
                    "Determine the accent only from reliable explicit context, never from physical appearance alone; when context is insufficient, use a neutral natural accent for the selected language."
                )
            lines.append(
                "In every Spoken Dialog clause, state the selected or context-supported language and accent directly beside the quoted words. Do not leave language or accent inference to the video model, and avoid stereotypes or caricature."
            )
        return "\n\n".join(lines)

    def build_refinement_request(self) -> str:
        lines = [self.build_director_request(include_requested_length=False)]
        lines.append(
            "SFX option is ON: preserve and improve the selected prompt's required `SFX:` clause."
            if self.sfx.isChecked() else
            "SFX option is OFF: do not invent a new SFX clause, but do not delete deliberate existing prompt content."
        )
        lines.append(
            "Spoken Dialog option is ON: preserve or improve appropriate `Spoken Dialog:` wording, explicit language and accent, performance, and accurate lip-sync direction."
            if self.spoken_dialog.isChecked() else
            "Spoken Dialog option is OFF: do not invent new spoken dialog, but do not delete deliberate existing prompt content."
        )
        return "\n\n".join(line for line in lines if line)

    def ai_credentials(self) -> tuple[str, str, str] | None:
        provider = self.settings.value("provider", "gemini")
        key = self.session_keys.get(provider) or self.settings.value(f"{provider}_key", "")
        if not key:
            self.open_settings()
            key = self.session_keys.get(provider) or self.settings.value(f"{provider}_key", "")
        if not key:
            return None
        return provider, self.settings.value("gemini_model", GEMINI_MODELS[0]), key

    def set_ai_controls_enabled(self, enabled: bool) -> None:
        self.magic_button.setEnabled(enabled)
        self.ai_busy = not enabled
        segment = self.current_segment()
        self.refine_timing_button.setEnabled(enabled and bool(segment))
        self.refine_prompt_button.setEnabled(enabled and bool(self.segment_prompt.toPlainText().strip()) and (self.unified_workspace or self.prompt_scope.currentData() == "segment"))
        if self.minimax_panel:
            self.minimax_panel.set_busy(not enabled)

    def start_ai_worker(self, operation, args: tuple, activity: str, finished, show_main_overlay: bool = True) -> None:
        if self.ai_busy:
            return
        retries = self.settings.value("api_retries", 2, int)
        retry_cooldown = self.settings.value("api_retry_cooldown", 10, int)
        self.set_ai_controls_enabled(False)
        self.ai_activity_title = (
            "Generic Generate" if operation in {build_generic_prompt, build_generic_segments} else
            "Generic Refine" if operation in {refine_generic_prompt, refine_generic_segment} else
            "Magic Build" if operation is build_prompts else
            "MiniMax H3 Reference Generate" if operation is build_minimax_h3_reference_prompt else
            "MiniMax H3 Frame Generate" if operation is build_minimax_h3_prompt else
            "MiniMax H3 Reference Refine" if operation is refine_minimax_h3_reference_prompt else
            "MiniMax H3 Frame Refine" if operation is refine_minimax_h3_prompt else
            "Refine Timing" if operation is refine_timing else
            "Refine Prompt"
        )
        self.ai_activity_in_minimax = not show_main_overlay
        if show_main_overlay:
            self.magic_overlay.update_attempt(1, retries + 1, activity)
            self.magic_overlay.show_overlay()
        instructions = copy.deepcopy(self.workspace_definition.get("generation_prompts", {}))
        def workspace_operation(*values):
            token = WORKSPACE_INSTRUCTIONS.set(instructions)
            try:
                return operation(*values)
            finally:
                WORKSPACE_INSTRUCTIONS.reset(token)
        worker = MagicWorker(workspace_operation, args, retries, retry_cooldown, activity)
        worker.signals.progress.connect(self.magic_progress)
        self.ai_request_workspace = (self.workspace_revision, self.current_project_id, self.project_type)
        self.ai_finished_callback = finished
        # Bound QObject receivers keep all UI updates on the main Qt thread.
        worker.signals.finished.connect(self.ai_result_received)
        worker.signals.failed.connect(self.ai_failure_received)
        self.thread_pool.start(worker)

    def start_disk_job(self, operation, args: tuple, finished, failed, *, serialized: bool = False) -> None:
        """Execute filesystem work without touching widgets outside the GUI thread."""
        worker = BackgroundWorker(operation, args)
        self._pending_disk_jobs += 1
        callbacks = BackgroundCallbacks(self, finished, failed)
        worker.signals.finished.connect(callbacks.on_finished)
        worker.signals.failed.connect(callbacks.on_failed)
        (self.disk_pool if serialized else self.media_pool).start(worker)

    def ai_request_is_current(self) -> bool:
        return getattr(self, "ai_request_workspace", None) == (self.workspace_revision, self.current_project_id, self.project_type)

    def discard_obsolete_ai_result(self) -> None:
        self.set_ai_controls_enabled(True)
        self.magic_overlay.hide_overlay()
        self.statusBar().showMessage("AI result discarded because the project or workflow changed.")

    def ai_result_received(self, result) -> None:
        if not self.ai_request_is_current():
            self.discard_obsolete_ai_result()
            return
        self.ai_finished_callback(result)

    def ai_failure_received(self, error: str) -> None:
        if not self.ai_request_is_current():
            self.discard_obsolete_ai_result()
            return
        self.magic_failed(error)

    def refine_selected_timing(self) -> None:
        segment = self.current_segment()
        if not segment:
            return
        credentials = self.ai_credentials()
        if not credentials:
            return
        provider, model, key = credentials
        row = self.timeline.currentRow()
        self.refinement_segment_id = segment.id
        timeout = self.settings.value("api_timeout", 400, int)
        self.statusBar().showMessage(f"Refining timing for segment {row + 1}…")
        self.start_ai_worker(
            refine_timing,
            (self.segments.copy(), row, provider, model, key, self.build_refinement_request(), self.requested_length.value(), timeout),
            "Analyzing sequence context and refining selected timing…",
            self.refine_timing_finished,
        )

    def refine_selected_prompt(self) -> None:
        segment = self.current_segment()
        if not segment:
            return
        # Commit the editor value synchronously before snapshotting the timeline
        # for the background refinement worker.
        segment.prompt = self.segment_prompt.toPlainText()
        if not segment.prompt.strip():
            QMessageBox.information(self, "Refine Prompt", "Write or generate a segment prompt before refining it.")
            return
        credentials = self.ai_credentials()
        if not credentials:
            return
        provider, model, key = credentials
        row = self.timeline.currentRow()
        self.refinement_segment_id = segment.id
        timeout = self.settings.value("api_timeout", 400, int)
        self.statusBar().showMessage(f"Refining prompt for segment {row + 1}…")
        self.start_ai_worker(
            refine_generic_segment if self.workspace_engine == "generic" else refine_segment_prompt,
            (self.segments.copy(), row, provider, model, key, self.build_refinement_request(), self.requested_length.value(), timeout) + ((self.active_reference_images(),) if self.workspace_engine == "generic" else ()),
            "Refining the selected prompt with adjacent-frame context…",
            self.refine_prompt_finished,
        )

    def refinement_target(self) -> tuple[int, Segment] | None:
        segment_id = getattr(self, "refinement_segment_id", "")
        for index, segment in enumerate(self.segments):
            if segment.id == segment_id:
                return index, segment
        return None

    def refine_timing_finished(self, result: dict) -> None:
        target = self.refinement_target()
        if target:
            index, segment = target
            durations = [item.duration for item in self.segments]
            durations[index] = float(result["duration"])
            self.animate_timeline_durations(durations)
            self.statusBar().showMessage(f"Segment {index + 1} timing refined to {durations[index]:.2f}s; prompt text unchanged")
        self.set_ai_controls_enabled(True)
        self.magic_overlay.hide_overlay()

    def refine_prompt_finished(self, result: dict) -> None:
        target = self.refinement_target()
        if target:
            index, segment = target
            segment.prompt = consume_global_refinements(str(result["prompt"]))
            segment.image_prompt = str(result.get("imagePrompt") or segment.image_prompt).strip()
            durations = [item.duration for item in self.segments]
            durations[index] = float(result["duration"])
            if self.timeline.currentRow() == index:
                self.refresh_segment_prompt_box(index)
            self.refresh_text_segment_previews()
            self.animate_timeline_durations(durations)
            self.statusBar().showMessage(f"Segment {index + 1} prompt refined")
        self.set_ai_controls_enabled(True)
        self.magic_overlay.hide_overlay()

    def magic_build(self) -> None:
        if not self.segments:
            self.add_media()
            return
        credentials = self.ai_credentials()
        if not credentials:
            return
        provider, model, key = credentials
        self.statusBar().showMessage("Magic Build is analyzing ordered timeline items…")
        timeout = self.settings.value("api_timeout", 400, int)
        self.start_ai_worker(build_generic_segments if self.workspace_engine == "generic" else build_prompts, (
            self.segments.copy(), provider, model, key,
            self.build_director_request(), self.sfx.isChecked(), self.spoken_dialog.isChecked(), self.hdr.isChecked(), self.reduce_music.isChecked(), timeout,
        ) + ((self.active_reference_images(),) if self.workspace_engine == "generic" else ()), "Analyzing timeline context and directing motion…", self.magic_finished)

    def magic_progress(self, attempt: int, total: int, detail: str) -> None:
        if not self.ai_request_is_current():
            return
        if attempt > 1:
            self.statusBar().showMessage(f"{self.ai_activity_title}: {detail} (attempt {attempt}/{total})")
        if getattr(self, "ai_activity_in_minimax", False) and self.minimax_panel:
            action = "Refining" if str(getattr(self, "minimax_operation_kind", "")).startswith("refine_") else "Generating"
            self.minimax_panel.set_busy(True, f"{detail}  •  attempt {attempt}/{total}")
            self.minimax_panel.set_cache_state(f"{action}… attempt {attempt}/{total}")
        else:
            self.magic_overlay.update_attempt(attempt, total, detail)

    def magic_finished(self, result: dict) -> None:
        target_durations = []
        generated_segments = result["segments"]
        for segment, generated in zip(self.segments, generated_segments):
            segment.prompt = str(generated.get("prompt", segment.prompt))
            segment.image_prompt = str(generated.get("imagePrompt") or segment.image_prompt).strip()
            recommended = max(MIN_DURATION, round(float(generated.get("duration", segment.duration)), 2))
            target_durations.append(recommended)
        global_prompt = str(result.get("globalPrompt", "")).strip()
        quality = "(4K, HDR, Realistic)"
        if self.hdr.isChecked() and not global_prompt.startswith(quality):
            global_prompt = f"{quality}\n{global_prompt}"
        if self.reduce_music.isChecked() and "[SOUND]:" not in global_prompt:
            lines = global_prompt.splitlines()
            insertion = 1 if lines and lines[0].strip() == quality else 0
            lines.insert(insertion, "[SOUND]: Ambient environmental room tone matching the visible setting.")
            global_prompt = "\n".join(lines)
        self.global_prompt.setPlainText(global_prompt)
        self.refresh_segment_prompt_box(self.timeline.currentRow())
        current = self.current_segment()
        self.refresh_text_segment_previews()
        self.mark_dirty()
        self.set_ai_controls_enabled(True)
        self.magic_overlay.hide_overlay()
        self.animate_timeline_durations(target_durations)
        self.statusBar().showMessage("Magic Build complete")

    def store_minimax_draft(self) -> None:
        self.minimax_drafts[self.workspace_draft_key] = {
            "prompt": self.minimax_prompt_text,
            "instructions": self.minimax_refinement_instructions,
            "sourceHash": self.minimax_prompt_cache_key,
            "updatedAt": self.minimax_prompt_updated_at,
            "cueActions": dict(self._action_descriptions),
        }

    def restore_project_type(self, value, drafts) -> None:
        self.minimax_drafts = {
            key: {**{field: str(item.get(field, "")) for field in ("prompt", "instructions", "sourceHash", "updatedAt")},
                  "cueActions": dict(item.get("cueActions") or {})}
            for key, item in (drafts.items() if isinstance(drafts, dict) else [])
            if isinstance(item, dict)
        }
        self.store_minimax_draft()
        legacy = "minimax_" + self.minimax_prompt_mode if self.minimax_prompt_text else "ltx"
        self.project_type = value if value in self.workspace_definitions else (legacy if legacy in self.workspace_definitions else next(iter(self.workspace_definitions), ""))
        if self.unified_workspace:
            self.load_minimax_draft(("frames" if self.workspace_engine == "generic" else self.workspace_engine.removeprefix("minimax_")))
        self.prompt_scope.setCurrentIndex(0)
        self.sync_reference_panel_visibility()

    def load_minimax_draft(self, mode: str) -> None:
        self.minimax_prompt_mode = mode
        draft = self.minimax_drafts.get(self.workspace_draft_key, {})
        self.minimax_prompt_text = draft.get("prompt", "")
        self.minimax_refinement_instructions = draft.get("instructions", "")
        self.minimax_prompt_cache_key = draft.get("sourceHash", "")
        self.minimax_prompt_updated_at = draft.get("updatedAt", "")
        self._action_descriptions = dict(draft.get("cueActions") or {})

    def project_type_changed(self, _index: int) -> None:
        if not self._loading:
            self.set_project_type(self.project_type_combo.currentData())

    @property
    def workspace_definition(self) -> dict:
        return self.workspace_definitions.get(self.project_type, {})

    @property
    def workspace_engine(self) -> str:
        return self.workspace_definition.get("engine", "ltx")

    @property
    def unified_workspace(self) -> bool:
        return self.workspace_definition.get("prompt_mode") == "unified"

    @property
    def workspace_draft_key(self) -> str:
        return self.minimax_prompt_mode if self.project_type in {"minimax_frames", "minimax_references", "ltx"} else self.project_type

    def reload_workspace_definitions(self, previous_id=None, new_id=None) -> None:
        self.store_minimax_draft()
        old_draft_key = self.workspace_draft_key
        if previous_id == self.project_type and new_id:
            self.project_type = new_id
            if new_id not in {"ltx", "minimax_frames", "minimax_references"} and old_draft_key in self.minimax_drafts:
                self.minimax_drafts[new_id] = self.minimax_drafts.pop(old_draft_key)
        self.workspace_definitions = self.workspace_store.load()
        self.project_type_combo.blockSignals(True)
        self.project_type_combo.clear()
        for key, value in self.workspace_definitions.items():
            self.project_type_combo.addItem(value["name"], key)
        self.project_type_combo.blockSignals(False)
        if self.project_type not in self.workspace_definitions:
            self.project_type = next(iter(self.workspace_definitions), "")
        if self.unified_workspace:
            self.load_minimax_draft(("frames" if self.workspace_engine == "generic" else self.workspace_engine.removeprefix("minimax_")))
        self.workspace_revision += 1
        self.apply_project_type_ui()
        self.mark_dirty()
        if self.workspace_store.errors:
            self.statusBar().showMessage("Some workspace definitions could not be loaded. Review Settings → Workspaces.")

    def set_project_type(self, project_type: str) -> None:
        if project_type not in self.workspace_definitions or project_type == self.project_type:
            return
        if getattr(self, "duration_animation", None):
            self.duration_animation.stop()
        self.store_minimax_draft()
        self.project_type = project_type
        self.workspace_revision += 1
        if self.unified_workspace:
            self.load_minimax_draft(("frames" if self.workspace_engine == "generic" else self.workspace_engine.removeprefix("minimax_")))
        self._action_segment_ids = []
        self._action_descriptions = {}
        self._changed_action_sources.clear()
        self.prompt_scope.blockSignals(True)
        self.prompt_scope.setCurrentIndex(0)
        self.prompt_scope.blockSignals(False)
        self.minimax_panel.clear_message()
        self.sync_minimax_panel()
        self.sync_reference_panel_visibility()
        self.sync_timed_actions()
        self.mark_dirty()

    def apply_project_type_ui(self) -> None:
        ltx = not self.unified_workspace
        references = self.workspace_definition.get("references", {})
        refs = (not ltx or self.workspace_engine == "generic") and references.get("enabled", False) and references.get("untimed_slots", 0) > 0
        self.project_type_combo.blockSignals(True)
        self.project_type_combo.setCurrentIndex(self.project_type_combo.findData(self.project_type))
        self.project_type_combo.blockSignals(False)
        self.prompt_label.setText(self.workspace_definition.get("name", "Workspace").upper() + " PROMPT")
        self.segment_prompt.inline_cue_mode = not ltx
        self.prompt_scope.setVisible(ltx and self.workspace_definition.get("global_prompt", False))
        if not self.workspace_definition.get("global_prompt", False):
            self.prompt_scope.setCurrentIndex(0)
        self.minimax_panel.setVisible(not ltx)
        self.references_button.setVisible(refs)
        self.minimax_panel.reference_dock.toggleViewAction().setVisible(refs)
        self.sync_reference_panel_visibility()
        audio = self.workspace_definition.get("audio_generation", True)
        for control in (self.sfx, self.spoken_dialog, self.reduce_music):
            control.setVisible(audio)
        if not audio:
            for control in (self.sfx, self.spoken_dialog, self.reduce_music):
                control.setChecked(False)
        self.hdr.setVisible(True)
        self.requested_length.setVisible(True)
        self.length_label.setVisible(True)
        self.output_size_control.setVisible(ltx)
        self.output_label.setVisible(ltx)
        self.refine_timing_button.setVisible(ltx)
        self.magic_button.setText("✦ Magic Build" if ltx else "✦ Generate Prompt")
        self.magic_button.setToolTip("Build all LTX segment prompts" if ltx else "Generate the full MiniMax production prompt for this workflow")
        self.workflow_export_action.setVisible(ltx)
        self.magic_button.setEnabled(not self.ai_busy and bool(self.workspace_definition))
        visual = bool(self.current_segment() and self.current_segment().kind != "text")
        self.start_button.setVisible(visual and self.workspace_engine != "minimax_frames")
        self.end_button.setVisible(visual and self.workspace_engine != "minimax_frames")
        self.update_spoken_dialog_visibility()
        self.minimax_panel.refresh_references()
        reference_options = self.workspace_definition.get("references", {})
        for index, target in enumerate(self.minimax_panel.reference_targets):
            target.setVisible(reference_options.get("enabled", False) and index < reference_options.get("untimed_slots", 0))
            for row in range(target.role.count()):
                target.role.model().item(row).setEnabled(target.role.itemData(row) in reference_options.get("kinds", []))
        self.refresh_shared_editor()

        self.queue_project_panel_width_restore()

    def prompt_scope_changed(self, _index: int) -> None:
        self.refresh_shared_editor()

    def refresh_shared_editor(self) -> None:
        if self.unified_workspace:
            value = self.minimax_prompt_text
        elif self.prompt_scope.currentData() == "global":
            value = self.global_prompt.toPlainText()
        else:
            segment = self.current_segment()
            value = segment.prompt if segment else ""
        if self.segment_prompt.toPlainText() != value:
            caret = self.segment_prompt.textCursor().position()
            scroll = self.segment_prompt.verticalScrollBar().value()
            self.segment_prompt.blockSignals(True)
            self.segment_prompt.setPlainText(value)
            if self.unified_workspace:
                insert_cue_cells(self.segment_prompt, value, self.segments)
            render_prompt_notes(self.segment_prompt)
            if self.unified_workspace:
                cursor = self.segment_prompt.textCursor()
                cursor.setPosition(min(caret, len(value)))
                self.segment_prompt.setTextCursor(cursor)
                self.segment_prompt.verticalScrollBar().setValue(scroll)
            self.segment_prompt.blockSignals(False)
        self.segment_prompt.setPlaceholderText("Select a timeline segment to edit its prompt…" if not self.unified_workspace else "Generate a production prompt or write your own…")
        self.highlight_inline_actions()
        self.refine_prompt_button.setEnabled(not self.ai_busy and bool(value.strip()) and (self.unified_workspace or self.prompt_scope.currentData() == "segment"))
        self.update_counts()

    def global_prompt_changed(self) -> None:
        self.mark_dirty()
        if not self.unified_workspace and self.prompt_scope.currentData() == "global":
            self.refresh_shared_editor()

    def update_spoken_dialog_visibility(self) -> None:
        if not hasattr(self, "language_label"):
            return
        self.planning_label.setVisible(not self.unified_workspace or self.spoken_dialog.isChecked())
        for widget in (self.speaker_language, self.speaker_accent, self.language_label, self.accent_label):
            widget.setVisible(self.spoken_dialog.isChecked())

    def set_reference_panel_open(self, opened: bool) -> None:
        self.settings.setValue("reference_panel_open", bool(opened))
        self.queue_settings_sync()
        self.sync_reference_panel_visibility()

    def sync_reference_panel_visibility(self) -> None:
        references = self.workspace_definition.get("references", {})
        available = (self.unified_workspace or self.workspace_engine == "generic") and references.get("enabled", False) and references.get("untimed_slots", 0) > 0
        opened = self.settings.value("reference_panel_open", False, bool)
        dock = self.minimax_panel.reference_dock
        if dock.isHidden() == bool(available and opened):
            dock.setVisible(bool(available and opened))
            self.queue_project_panel_width_restore()

    def show_reference_images(self) -> None:
        self.set_reference_panel_open(True)
        self.minimax_panel.reference_dock.raise_()

    def generate_project_prompt(self) -> None:
        if self.ai_busy:
            return
        if not self.unified_workspace:
            self.magic_build()
        else:
            self._generate_minimax_prompt(self.minimax_prompt_mode)

    def refine_project_prompt(self) -> None:
        if self.ai_busy:
            return
        if not self.unified_workspace:
            if self.prompt_scope.currentData() == "segment":
                self.refine_selected_prompt()
        else:
            self.refine_minimax_prompt()

    def export_workflow(self) -> None:
        if not self.unified_workspace:
            self.export_ltx()
        else:
            self.copy_minimax_prompt()

    def ensure_minimax_panel(self) -> MiniMaxPromptPanel:
        return self.minimax_panel

    def sync_minimax_panel(self, cache_state: str | None = None) -> None:
        if not self.minimax_panel:
            return
        if self.minimax_refinement_instructions.strip():
            # Migrate older drafts' hidden refinement notes into visible, editable instructions.
            note = self.minimax_refinement_instructions.strip().replace('\n', ' ')
            directive = f'/refine-global {note}'
            if directive not in self.minimax_prompt_text:
                self.minimax_prompt_text = directive + '\n\n' + self.minimax_prompt_text
            self.minimax_refinement_instructions = ''
        self.apply_project_type_ui()
        mode_name = "reference" if self.minimax_prompt_mode == "references" else "frame"
        state = cache_state or (f"Saved {mode_name} prompt" if self.minimax_prompt_text else "Not generated")
        self.minimax_panel.set_project(self.current_project_name, self.minimax_prompt_text,
                                       self.minimax_refinement_instructions, state)
        self.sync_timed_actions()

    def show_minimax_panel(self, cache_state: str | None = None) -> MiniMaxPromptPanel:
        if not self.unified_workspace:
            self.set_project_type("minimax_" + self.minimax_prompt_mode)
        self.sync_minimax_panel(cache_state)
        self.minimax_panel.focus_prompt_editor()
        return self.minimax_panel

    def minimax_editor_changed(self) -> None:
        if self._loading or not self.minimax_panel or not self.unified_workspace:
            return
        self.minimax_prompt_text = self.minimax_panel.editor.toPlainText()
        tagged = cue_cells(self.minimax_panel.editor)
        if tagged:
            self._action_descriptions.update(tagged)
        self._actions_refresh_timer.start()
        self.highlight_inline_actions()
        self.minimax_prompt_updated_at = datetime.now(timezone.utc).isoformat()
        self.minimax_panel.update_actions()
        self.mark_dirty()

    def active_reference_images(self) -> list:
        options = self.workspace_definition.get("references", {})
        if not options.get("enabled"):
            return [None, None]
        count = options.get("untimed_slots", 0)
        kinds = options.get("kinds", [])
        return [value if index < count and value and value.get("role", "identity") in kinds else None
                for index, value in enumerate(reference_slots(self.minimax_reference_images))]

    def set_minimax_reference_image(self, slot: int, value: dict | None) -> None:
        if self._loading:
            return
        refs = reference_slots(self.minimax_reference_images)
        refs[slot] = dict(value) if value else None
        image_changed = (self.minimax_reference_images[slot] or {}).get("image") != (value or {}).get("image")
        self.minimax_reference_images = reference_slots(refs)
        self.minimax_prompt_cache_key = ""
        self.mark_dirty()
        if self.minimax_panel:
            self.minimax_panel.refresh_references(update_images=image_changed)
            if not self.minimax_panel.busy:
                self.minimax_panel.set_cache_state("References changed · generate when ready")

    def paste_timed_prompt(self, text: str) -> None:
        if SECTION.search(text) or re.search(r"(?m)^\[[A-Z ]+\]", text):
            prompt = text
        else:
            section = SECTION.search(self.minimax_prompt_text)
            following = NEXT.search(self.minimax_prompt_text, section.end()) if section else None
            prefix = self.minimax_prompt_text[:section.end()] if section else self.minimax_prompt_text.rstrip() + "\n\n[TIMED ACTION]\n"
            suffix = self.minimax_prompt_text[following.start():] if following else ""
            prompt = prefix.rstrip() + "\n" + text.strip() + ("\n\n" + suffix if suffix else "")
        self.conform_timed_prompt(prompt)

    def conform_timed_prompt(self, prompt: str) -> None:
        """Apply a prompt plan in order, retaining media and IDs of existing segments."""
        if not SECTION.search(prompt):
            first = re.search(r"(?m)^[ \t]*\d{2}:\d{2}:", prompt)
            if first:
                prompt = prompt[:first.start()].rstrip() + "\n\n[TIMED ACTION]\n" + prompt[first.start():]
        plan = parse_timed_plan(prompt)
        previous_loading = self._loading
        self._loading = True
        targets = [segment.duration for segment in self.segments]
        self.minimax_prompt_text = prompt
        for index, cue in enumerate(plan):
            if index >= len(self.segments):
                if not cue["valid"]:
                    break
                self.segments.append(Segment(f"Text {index + 1}", "", "", "text", "text"))
                targets.append(self.segments[-1].duration)
            segment = self.segments[index]
            segment.prompt_detached = not cue["valid"]
            if cue["valid"]:
                segment.prompt = cue["description"]
                targets[index] = round(cue["end"] - cue["start"], 6)
        for segment in self.segments[len(plan):]:
            segment.prompt_detached = True
        self._action_segment_ids = [segment.id for segment in self.segments]
        self._action_descriptions = {segment.id: segment.prompt for segment in self.segments if not segment.prompt_detached}
        self.refresh_shared_editor()
        # Force re-render even when serialized text compares equal to the new source.
        self.segment_prompt.blockSignals(True)
        self.segment_prompt.setPlainText(prompt)
        self.segment_prompt.blockSignals(False)
        self.refresh_timeline(max(0, self.timeline.currentRow()))
        self._loading = previous_loading
        self.update_timeline_selection_style(self.timeline.currentRow())
        self._conforming_prompt = True
        try:
            self.animate_timeline_durations(targets)
        finally:
            self._conforming_prompt = False
        self.segment_prompt.blockSignals(True)
        insert_cue_cells(self.segment_prompt, prompt, self.segments)
        render_prompt_notes(self.segment_prompt)
        self.segment_prompt.blockSignals(False)
        self.highlight_inline_actions()
        detached = sum(segment.prompt_detached for segment in self.segments)
        self.minimax_panel.show_message(
            f"{detached} segment(s) detached. Use contiguous SMPTE ranges beginning at 00:00:00:00 to reconnect them." if detached else "Timed prompt and timeline are connected.",
            "timeline" if detached else "success")

    def sync_timed_actions(self, timeline_changed: bool = False) -> None:
        panel = self.minimax_panel
        if not panel or not self.unified_workspace:
            if panel:
                panel.editor.setExtraSelections([])
            return
        ids = [item.id for item in self.segments]
        tagged = cue_cells(panel.editor)
        if tagged:
            self._action_descriptions.update(tagged)
        descriptions, _ = split_actions(self.minimax_prompt_text)
        if not tagged and len(descriptions) == len(self._action_segment_ids):
            self._action_descriptions.update((sid, description) for sid, description in zip(self._action_segment_ids, descriptions)
                                             if sid not in self._changed_action_sources)
        elif not tagged and not timeline_changed and len(descriptions) == len(ids):
            self._action_descriptions.update(zip(ids, descriptions))
        if timeline_changed and not getattr(self, "_conforming_prompt", False) and not any(segment.prompt_detached for segment in self.segments) and "[TIMED ACTION]" in self.minimax_prompt_text:
            if len(descriptions) != len(ids):
                panel.show_message("Timeline and timed cue counts differ. Review the extra cues before refining; none were removed.", "timeline")
            else:
                values = [self._action_descriptions.get(item.id, item.prompt.strip()) for item in self.segments]
                updated = compose_actions(self.minimax_prompt_text, self.segments, values)
                if updated != self.minimax_prompt_text:
                    self.minimax_prompt_text = updated
                    self.refresh_shared_editor()
                    panel.show_message("Timeline changed. Cue times are synced; refine the prompt to review the action and continuity.", "timeline")
        if not timeline_changed and (tagged or len(descriptions) == len(ids)):
            if not tagged and self.minimax_prompt_text.strip():
                editor = panel.editor
                caret, scroll = editor.textCursor().position(), editor.verticalScrollBar().value()
                editor.blockSignals(True)
                insert_cue_cells(editor, self.minimax_prompt_text, self.segments)
                cursor = editor.textCursor()
                cursor.setPosition(min(caret, editor.document().characterCount() - 1))
                editor.setTextCursor(cursor)
                editor.verticalScrollBar().setValue(scroll)
                editor.blockSignals(False)
            for index, segment in enumerate(self.segments):
                description = tagged.get(segment.id) if tagged else descriptions[index]
                if description is not None and not segment.prompt_detached and segment.prompt != description:
                    segment.prompt = description
            self._timeline_signature = tuple((item.id, item.duration, item.prompt, item.kind, item.role, item.name) for item in self.segments)
            self.refresh_text_segment_previews()
        self._action_segment_ids = ids
        self._changed_action_sources.clear()
        self.highlight_inline_actions()

    def highlight_inline_actions(self) -> None:
        """Only native timed-action cells have background shading."""
        segment = self.current_segment()
        if not self.unified_workspace or not segment or not focus_cue(self.segment_prompt, segment.id, focus=False):
            self.segment_prompt.setExtraSelections([])

    def replace_timeline_media(self, paths: list[str], index: int) -> None:
        paths = [path for path in paths if Path(path).is_file()]
        if not paths or not 0 <= index < len(self.segments):
            return
        target_id = self.segments[index].id
        workspace = (self.workspace_revision, self.current_project_id)
        def ready(result):
            if workspace != (self.workspace_revision, self.current_project_id):
                return
            prepared, errors = result
            location = next((i for i, item in enumerate(self.segments) if item.id == target_id), -1)
            if prepared and location >= 0:
                old = self.segments[location]
                path, kind, preview, frames, trim = prepared[0]
                self.segments[location] = Segment(Path(path).name, path, preview, kind, old.role, old.prompt,
                                                   old.duration, frames, trim, old.id, old.image_prompt, old.prompt_detached)
                self.mark_dirty()
                self.refresh_timeline(location)
                if len(prepared) > 1:
                    self.add_media_paths(paths[1:], location + 1)
            if errors:
                QMessageBox.warning(self, "Media error", "\n".join(errors))
        self.start_disk_job(_prepare_media_batch, (paths,), ready,
                            lambda message: QMessageBox.warning(self, "Media error", message))

    def stage_current_workspace(self) -> None:
        """Keep an unsaved project in memory when switching tabs or starting anew."""
        if self.segments and self.project_dirty and not self.current_project_id:
            self.current_project_id = uuid4().hex
            self.current_project_name = Path(self.segments[0].name).stem or "Untitled"
            self.update_window_title()

    def current_minimax_cache_key(self, provider: str | None = None, model: str | None = None) -> str:
        provider = provider or str(self.settings.value("provider", "gemini"))
        model = model or str(self.settings.value("gemini_model", GEMINI_MODELS[0]))
        return f"{self.workspace_revision}:{self.project_type}:" + minimax_h3_cache_key(
            self.segments,
            provider,
            model,
            self.build_director_request(),
            self.global_prompt.toPlainText(),
            self.sfx.isChecked(),
            self.spoken_dialog.isChecked(),
            self.reduce_music.isChecked(),
            self.active_reference_images(),
        )

    def copy_minimax_prompt(self) -> None:
        self.minimax_editor_changed()
        if not self.minimax_prompt_text.strip():
            return
        QApplication.clipboard().setText(self.minimax_prompt_text)
        message = "MiniMax H3 prompt copied to clipboard"
        self.minimax_panel.show_message(message, "success")

    def generate_minimax_prompt_frames(self) -> None:
        """Manually generate the continuous frame-timeline prompt."""
        if self.workspace_engine == "generic":
            self._generate_minimax_prompt(self.minimax_prompt_mode)
            return
        if self.workspace_engine != "minimax_frames":
            self.set_project_type("minimax_frames")
        self._generate_minimax_prompt("frames")

    def generate_minimax_prompt_references(self) -> None:
        """Manually generate a reference prompt for the detected workflow."""
        if self.workspace_engine == "generic":
            self._generate_minimax_prompt(self.minimax_prompt_mode)
            return
        if self.workspace_engine != "minimax_references":
            self.set_project_type("minimax_references")
        self._generate_minimax_prompt("references")

    def _generate_minimax_prompt(self, mode: str) -> None:
        if self.ai_busy:
            return
        self.minimax_editor_changed()
        if not self.segments:
            window = self.show_minimax_panel("Not generated")
            window.show_message("Add at least one timeline item before generating a MiniMax H3 prompt.", "warning")
            return
        reference_mode = mode == "references"
        mode_label = "reference" if reference_mode else "frame"
        window = self.show_minimax_panel(f"Generating {mode_label} prompt manually…")
        credentials = self.ai_credentials()
        if not credentials:
            window.set_busy(False, "Generation cancelled")
            window.show_message("Generation cancelled because no API credentials are configured.", "warning")
            return
        provider, model, key = credentials
        signature = self.current_minimax_cache_key(provider, model)
        self.minimax_operation_signature = signature
        self.minimax_operation_kind = f"generate_{mode}"
        self.minimax_operation_editor_snapshot = (
            self.minimax_prompt_text,
            self.minimax_refinement_instructions,
        )
        timeout = self.settings.value("api_timeout", 400, int)
        window.set_busy(True, f"Generating {mode_label} prompt…")
        operation = build_generic_prompt if self.workspace_engine == "generic" else (build_minimax_h3_reference_prompt if reference_mode else build_minimax_h3_prompt)
        self.start_ai_worker(
            operation,
            (
                self.segments.copy(), provider, model, key, self.build_director_request(),
                self.global_prompt.toPlainText(), self.sfx.isChecked(), self.spoken_dialog.isChecked(),
                self.reduce_music.isChecked(), timeout,
            ) + (self.active_reference_images(),),
            "Writing the generic workspace prompt…" if self.workspace_engine == "generic" else
            "Writing the MiniMax H3 prompt for " + WORKFLOW_NAMES[detect_workflow(self.segments, self.minimax_reference_images)] + "…"
            if reference_mode else
            "Boiling the complete sequence down to one MiniMax H3 frame prompt…",
            self.minimax_h3_finished,
            show_main_overlay=False,
        )

    def minimax_h3_finished(self, prompt: str) -> None:
        signature = str(getattr(self, "minimax_operation_signature", ""))
        if not signature or signature != self.current_minimax_cache_key():
            self.set_ai_controls_enabled(True)
            self.magic_overlay.hide_overlay()
            if self.minimax_panel:
                self.minimax_panel.set_busy(False, "Inputs changed • generate again")
                self.minimax_panel.show_message("The MiniMax result was not applied because the timeline or references changed while it was running. Generate again.", "warning")
            return
        editor_snapshot = (
            self.minimax_prompt_text,
            self.minimax_refinement_instructions,
        )
        if editor_snapshot != getattr(self, "minimax_operation_editor_snapshot", editor_snapshot):
            self.set_ai_controls_enabled(True)
            self.magic_overlay.hide_overlay()
            if self.minimax_panel:
                self.minimax_panel.set_busy(False, "Editor changed • result not applied")
                self.minimax_panel.show_message("The MiniMax result was not applied because you edited the prompt while it was running. Refine again when ready.", "warning")
            return
        operation = str(getattr(self, "minimax_operation_kind", "generate_frames"))
        if operation.startswith("refine_"):
            prompt = consume_global_refinements(prompt)
        self.conform_timed_prompt(prompt)
        self._action_segment_ids = [item.id for item in self.segments]
        descriptions, _ = split_actions(prompt)
        if len(descriptions) == len(self.segments):
            self._action_descriptions = dict(zip(self._action_segment_ids, descriptions))
        self.minimax_prompt_cache_key = signature
        self.minimax_prompt_updated_at = datetime.now(timezone.utc).isoformat()
        self.set_ai_controls_enabled(True)
        self.magic_overlay.hide_overlay()
        if operation.startswith("refine_"):
            self.minimax_refinement_instructions = ""
        if operation.endswith("references"):
            self.minimax_prompt_mode = "references"
        elif operation.endswith("frames"):
            self.minimax_prompt_mode = "frames"
        mode_label = "reference" if self.minimax_prompt_mode == "references" else "frame"
        state = f"Cached • {mode_label} {'refined' if operation.startswith('refine_') else 'generated'}"
        window = self.show_minimax_panel(state)
        self.mark_dirty()
        if any(segment.prompt_detached for segment in self.segments):
            window.show_message("Some timeline segments could not be conformed. Correct the timed ranges or refine again to reconnect them.", "timeline")
            return
        window.show_message(
            f"{self.workspace_definition.get('name', 'Production')} prompt refined. Save it from the toolbar or when closing."
            if operation.startswith("refine_") else
            f"{self.workspace_definition.get('name', 'Production')} prompt generated. Save it from the toolbar or when closing.",
            "success",
        )

    def refine_minimax_prompt(self) -> None:
        if self.ai_busy:
            return
        self.minimax_editor_changed()
        if not self.minimax_prompt_text.strip():
            if self.minimax_panel:
                self.minimax_panel.show_message("Write or generate a MiniMax H3 prompt before refining it.", "warning")
            return
        credentials = self.ai_credentials()
        if not credentials:
            if self.minimax_panel:
                self.minimax_panel.show_message("Refinement cancelled because no API credentials are configured.", "warning")
            return
        provider, model, key = credentials
        signature = self.current_minimax_cache_key(provider, model)
        self.minimax_operation_signature = signature
        reference_mode = self.minimax_prompt_mode == "references"
        self.minimax_operation_kind = "refine_references" if reference_mode else "refine_frames"
        self.minimax_operation_editor_snapshot = (
            self.minimax_prompt_text,
            self.minimax_refinement_instructions,
        )
        timeout = self.settings.value("api_timeout", 400, int)
        if self.minimax_panel:
            self.minimax_panel.set_busy(True, "Refining edited prompt…")
        operation = refine_generic_prompt if self.workspace_engine == "generic" else (refine_minimax_h3_reference_prompt if reference_mode else refine_minimax_h3_prompt)
        self.start_ai_worker(
            operation,
            (
                self.segments.copy(), provider, model, key, self.build_director_request(),
                self.global_prompt.toPlainText(), self.sfx.isChecked(), self.spoken_dialog.isChecked(),
                self.reduce_music.isChecked(), self.minimax_prompt_text,
                self.minimax_refinement_instructions, timeout,
            ) + (self.active_reference_images(),),
            "Refining the edited MiniMax prompt with timeline continuity context…",
            self.minimax_h3_finished,
            show_main_overlay=False,
        )

    def retry_minimax_operation(self) -> None:
        """Repeat the failed MiniMax operation using current inline controls."""
        if self.minimax_panel:
            self.minimax_panel.clear_message()
        self.minimax_prompt_cache_key = ""
        operation = str(getattr(self, "minimax_operation_kind", "generate_frames"))
        if operation.startswith("refine_"):
            self.refine_minimax_prompt()
        elif operation.endswith("references"):
            self.generate_minimax_prompt_references()
        else:
            self.generate_minimax_prompt_frames()

    def show_toast(self, message: str, duration: int = 3200) -> None:
        toast = getattr(self, "_toast_label", None)
        if toast is None:
            toast = QLabel(self)
            toast.setObjectName("toastMessage")
            toast.setAlignment(Qt.AlignmentFlag.AlignCenter)
            toast.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            toast.setStyleSheet(
                "#toastMessage{background:#17242c;color:#e8f7ff;border:1px solid #68b9ee;"
                "border-radius:7px;padding:9px 16px;font-weight:bold;}"
            )
            self._toast_label = toast
        self._toast_generation = getattr(self, "_toast_generation", 0) + 1
        generation = self._toast_generation
        toast.setText(message)
        toast.adjustSize()
        toast.resize(max(280, toast.width()), toast.height())
        toast.move(max(12, (self.width() - toast.width()) // 2), max(12, self.height() - self.statusBar().height() - toast.height() - 18))
        toast.show()
        toast.raise_()

        def hide_current_toast() -> None:
            if getattr(self, "_toast_generation", 0) == generation:
                toast.hide()

        QTimer.singleShot(duration, hide_current_toast)

    def animate_timeline_durations(self, target_durations: list[float]) -> None:
        self.autofit_tail_extension = 0
        if getattr(self, 'duration_animation', None):
            self.duration_animation.stop()
        self.preserve_timeline_scale_for_growth(sum(target_durations))
        if not self.segments or self.timeline.count() != len(self.segments):
            for segment, target in zip(self.segments, target_durations):
                segment.duration = target
            self.refresh_timeline(self.timeline.currentRow())
            self.mark_dirty()
            return
        start_widths = [self.timeline.item(row).sizeHint().width() for row in range(self.timeline.count())]
        target_widths = self.timeline_item_widths(target_durations)
        for segment, target in zip(self.segments, target_durations):
            segment.duration = target
        self.mark_dirty()
        for row, target in enumerate(target_durations):
            card = self.timeline.itemWidget(self.timeline.item(row))
            if isinstance(card, SegmentCard):
                card.resize_handle.duration = target
        self.sync_selected_duration_control()
        self.update_segment_start_times()
        self.update_summary()
        animation = QVariantAnimation(self)
        animation.setDuration(950)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        def resize_tiles(progress: float) -> None:
            for row, (start, target) in enumerate(zip(start_widths, target_widths)):
                item = self.timeline.item(row)
                item.setSizeHint(QSize(round(start + (target - start) * progress), max(152, self.timeline_height - 32)))
                card = self.timeline.itemWidget(item)
                if card and hasattr(card, "duration_label"):
                    card.duration_label.setText(f"{target_durations[row]:.2f}s")
            self.timeline.doItemsLayout()
            self.timeline.viewport().update()

        animation.valueChanged.connect(resize_tiles)
        def finish_resize_animation() -> None:
            self.update_timeline_layout()
            self.sync_selected_duration_control()

        animation.finished.connect(finish_resize_animation)
        self.duration_animation = animation
        animation.start()

    def magic_failed(self, message: str) -> None:
        self.set_ai_controls_enabled(True)
        self.magic_overlay.hide_overlay()
        title = getattr(self, "ai_activity_title", "AI operation")
        overloaded = message.startswith("Google Gemini is temporarily overloaded")
        if title.startswith("MiniMax") or (self.workspace_engine == "generic" and self.unified_workspace):
            window = self.show_minimax_panel("AI request failed")
            window.set_busy(False, "Gemini overloaded • try again" if overloaded else "AI request failed")
            window.show_message(message, "warning" if overloaded else "error", retry=True)
            return
        if overloaded:
            QMessageBox.warning(self, f"{title}: Gemini overloaded", message)
            self.statusBar().showMessage("Google Gemini is overloaded; try again shortly or choose another model", 8000)
        else:
            QMessageBox.critical(self, f"{title} failed", message)
            self.statusBar().showMessage(f"{title} failed")

    def export_ltx(self) -> None:
        if not self.segments:
            return
        comfy_root = self.resolve_comfy_root()
        if comfy_root is None:
            return
        path = str(self.next_export_path(f"{self.current_project_name}.json"))
        self.normalize_output_dimensions()
        self.statusBar().showMessage(f"Exporting LTX Director JSON in background: {path}…")
        self.start_disk_job(_export_ltx_snapshot,
                            (copy.deepcopy(self.segments), self.global_prompt.toPlainText(),
                             self.output_width.value(), self.output_height.value(), comfy_root / "input" / "whatdreamscost", path),
                            lambda _result: self.record_export(path),
                            lambda message: self.export_failed(path, message), serialized=True)

    def resolve_comfy_root(self) -> Path | None:
        configured = str(self.settings.value("comfy_root_dir", "") or "").strip()
        configured_path = Path(configured).expanduser() if configured else None
        if configured_path and configured_path.is_dir():
            return configured_path.resolve()
        selected = choose_directory(self, "Choose ComfyUI root directory", configured or str(Path.home()))
        if not selected:
            return None
        root = Path(selected).expanduser().resolve()
        self.settings.setValue("comfy_root_dir", str(root))
        self.settings.sync()
        return root

    def import_ltx(self, checked: bool = False, path: str | None = None) -> None:
        path = path or choose_document_open(self, "Import LTX Director JSON", self.settings.value("last_document_dir", str(Path.home())), "LTX Director JSON (*.json)")
        if not path:
            return
        self.settings.setValue("last_document_dir", str(Path(path).parent))
        self.stage_current_workspace()
        self.cache_current_workspace()
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
            fps = float(payload.get("settings", {}).get("frame_rate", FPS))
            loaded = []
            configured_root = str(self.settings.value("comfy_root_dir", "") or "").strip()
            comfy_input = Path(configured_root).expanduser() / "input" if configured_root else None
            raw_segments = list(payload["timeline"]["segments"])
            raw_segments = [raw for _, raw in sorted(enumerate(raw_segments), key=lambda item: (float(item[1].get("start", 0)), item[0]))]
            for index, raw in enumerate(raw_segments):
                if raw.get("type") not in ("image", "video", "text"):
                    continue
                if raw.get("type") == "text":
                    loaded.append(text_segment_from_ltx(raw, index, fps))
                    continue
                cache = APP_CACHE / f"import-{index}-{Path(path).stem}.jpg"
                preview = raw.get("imageB64")
                media_reference = str(raw.get("imageFile") or raw.get("fileName") or "")
                media_candidate = Path(media_reference).expanduser()
                if media_reference and not media_candidate.is_absolute() and comfy_input:
                    media_candidate = comfy_input / Path(media_reference)
                if preview and preview.startswith("data:image/"):
                    write_data_url(preview, cache)
                elif media_candidate.is_file() and raw.get("type") == "image":
                    cache = media_candidate
                else:
                    continue
                media_path = str(media_candidate) if media_candidate.is_file() else str(cache)
                if raw.get("type") == "video" and str(raw.get("videoB64", "")).startswith(("data:video/webm", "data:video/mp4")):
                    video_path = APP_CACHE / f"import-{index}-{Path(raw.get('fileName', 'clip.webm')).name}"
                    write_data_url(raw["videoB64"], video_path)
                    media_path = str(video_path)
                loaded.append(Segment(raw.get("fileName", f"Segment {index + 1}"), str(media_path), str(cache), raw.get("type", "image"), "end" if raw.get("isEndFrame") else "start", raw.get("prompt", ""), max(MIN_DURATION, round(float(raw.get("length", FPS)) / fps, 2)), raw.get("videoDurationFrames"), raw.get("trimStart"), raw.get("id", "")))
            if not loaded:
                raise ValueError("No supported embedded image, video, or text segments were found.")
            self.segments = loaded
            self.minimax_reference_images = [None, None]
            self.minimax_prompt_text = ""
            self.minimax_refinement_instructions = ""
            self.minimax_prompt_cache_key = ""
            self.minimax_prompt_updated_at = ""
            self.minimax_prompt_mode = "frames"
            self.minimax_drafts = {}
            self.project_type = "ltx" if "ltx" in self.workspace_definitions else next(iter(self.workspace_definitions), "")
            self.workspace_revision += 1
            self.prompt_scope.setCurrentIndex(0)
            self.apply_project_type_ui()
            settings = payload.get("settings", {})
            self.output_width.setValue(int(settings.get("custom_width", 1280)))
            self.output_height.setValue(int(settings.get("custom_height", 704)))
            self.normalize_output_dimensions()
            self.global_prompt.setPlainText(payload.get("global_prompt") or payload.get("timeline", {}).get("global_prompt", ""))
            self.intent.clear()
            self.requested_length.setValue(0)
            self.speaker_language.setCurrentText("(Image/context provided)")
            self.speaker_accent.setCurrentText("(Image/context provided)")
            self.current_project_id = None
            self.current_project_name = Path(path).stem
            self.update_window_title()
            self.refresh_timeline()
            self.project_dirty = False
            self.mark_dirty()
            self.statusBar().showMessage(f"Imported: {self.current_project_name} · save to Library from toolbar or when closing")
        except Exception as error:
            QMessageBox.critical(self, "Import failed", str(error))

    def project_payload(self, include_media: bool = True) -> dict:
        self.store_minimax_draft()
        frames = []
        for segment in self.segments:
            value = segment.to_dict()
            if include_media:
                value["previewData"] = data_url(segment.preview_path) if segment.kind != "text" and segment.preview_path and Path(segment.preview_path).exists() else None
                source = Path(materialize_source(segment)) if segment.kind != "text" and segment.media_path else None
                value["sourceData"] = data_url(str(source)) if source and source.exists() else None
            frames.append(value)
        return {
            "app": "ltx-director-director",
            "projectVersion": 8,
            "projectType": self.project_type,
            "workspaceDefinition": copy.deepcopy(self.workspace_definition),
            "downloadDirectory": self.download_directory,
            "globalPrompt": self.global_prompt.toPlainText(),
            "directorIntent": self.intent.toPlainText(),
            "directionOptions": {
                "requestedLength": self.requested_length.value(),
                "speakerLanguage": self.speaker_language.currentText(),
                "speakerAccent": self.speaker_accent.currentText(),
            },
            "magicBuild": {
                "sfx": self.sfx.isChecked(),
                "spokenDialog": self.spoken_dialog.isChecked(),
                "hdr": self.hdr.isChecked(),
                "reduceMusic": self.reduce_music.isChecked(),
            },
            "minimaxH3": {
                "prompt": self.minimax_prompt_text,
                "refinementInstructions": self.minimax_refinement_instructions,
                "sourceHash": self.minimax_prompt_cache_key,
                "updatedAt": self.minimax_prompt_updated_at,
                "mode": self.minimax_prompt_mode,
                "referenceImages": reference_slots(self.minimax_reference_images),
                "cueActions": dict(self._action_descriptions),
                "drafts": {key: dict(value) for key, value in self.minimax_drafts.items()},
            },
            "output": {"width": self.output_width.value(), "height": self.output_height.value()},
            "timelineView": {"scale": self.pixels_per_second, "autoFit": self.timeline_fit_mode, "height": self.timeline_height},
            "frames": frames,
        }

    def load_project_payload(self, payload: dict) -> None:
        if payload.get("app") not in {"ltx-director-director", "ltx-prompt-director-python"}:
            raise ValueError("This is not an LTX Director - Director project file.")
        definition = payload.get("workspaceDefinition")
        if isinstance(definition, dict) and definition.get("id") not in self.workspace_definitions:
            self.workspace_store.save(definition)
            self.reload_workspace_definitions()
        self._loading = True
        self.download_directory = str(payload.get("library", {}).get("downloadDirectory", payload.get("downloadDirectory", "")))
        loaded = []
        cache_key = uuid4().hex[:10]
        for index, original in enumerate(payload.get("frames", [])):
            raw = dict(original)
            is_text = raw.get("kind") == "text"
            preview_path = APP_CACHE / f"project-{cache_key}-{index}.jpg"
            if raw.get("_archivePath"):
                preview_path = Path(raw["_archivePreviewPath"])
                media_path = Path(raw["_archiveMediaPath"])
            else:
                if raw.get("previewData"):
                    write_data_url(raw["previewData"], preview_path)
                media_path = "" if is_text else preview_path
            if not raw.get("_archivePath") and raw.get("sourceData"):
                original_suffix = Path(raw.get("name", "")).suffix.lower()
                suffix = (
                    original_suffix if raw.get("kind") == "video" and original_suffix in TIMELINE_VIDEO_SUFFIXES else
                    ".webm" if raw.get("kind") == "video" else
                    original_suffix or ".png"
                )
                media_path = APP_CACHE / f"project-source-{cache_key}-{index}{suffix}"
                write_data_url(raw["sourceData"], media_path)
            if not raw.get("_archivePath") and not is_text and preview_path.is_file():
                preview_path = Path(thumbnail_for_image(str(preview_path)))
            raw.update({"preview_path": "" if is_text else str(preview_path), "media_path": str(media_path)})
            for key in ("previewData", "sourceData"):
                raw.pop(key, None)
            segment = Segment.from_dict(raw)
            if raw.get("_archivePath"):
                segment._archive_source = (raw["_archivePath"], raw["archiveSource"])
                segment._media_digest = raw.get("mediaDigest", "")
                segment._source_size = raw.get("sourceSize")
            loaded.append(segment)
        if not loaded:
            raise ValueError("Project contains no supported main-track segments.")
        self.segments = loaded
        self.global_prompt.setPlainText(payload.get("globalPrompt", ""))
        self.intent.setPlainText(payload.get("directorIntent", ""))
        render_prompt_notes(self.intent)
        direction_options = payload.get("directionOptions", {})
        self.requested_length.setValue(requested_length_value(direction_options.get("requestedLength")))
        self.speaker_language.setCurrentText(str(direction_options.get("speakerLanguage", "(Image/context provided)")))
        self.speaker_accent.setCurrentText(str(direction_options.get("speakerAccent", direction_options.get("speakerNationality", "(Image/context provided)"))))
        self.sfx.setChecked(bool(payload.get("magicBuild", {}).get("sfx")))
        magic = payload.get("magicBuild", {})
        self.spoken_dialog.setChecked(bool(magic.get("spokenDialog", magic.get("vocals", False))))
        self.hdr.setChecked(bool(payload.get("magicBuild", {}).get("hdr")))
        self.reduce_music.setChecked(bool(payload.get("magicBuild", {}).get("reduceMusic")))
        minimax = payload.get("minimaxH3", {})
        if isinstance(minimax, str):
            minimax = {"prompt": minimax}
        if not isinstance(minimax, dict):
            minimax = {}
        self.minimax_prompt_text = str(minimax.get("prompt", ""))
        self.minimax_refinement_instructions = str(minimax.get("refinementInstructions", ""))
        self.minimax_prompt_cache_key = str(minimax.get("sourceHash", ""))
        self.minimax_prompt_updated_at = str(minimax.get("updatedAt", ""))
        self.minimax_prompt_mode = "references" if minimax.get("mode") == "references" else "frames"
        self.minimax_reference_images = reference_slots(minimax.get("referenceImages"))
        self.workspace_revision += 1
        self.restore_project_type(payload.get("projectType"), minimax.get("drafts"))
        self._action_descriptions = {str(key): str(value) for key, value in (minimax.get("cueActions") or self._action_descriptions or {}).items()}
        if self._action_descriptions and "[TIMED ACTION]" in self.minimax_prompt_text:
            self.minimax_prompt_text = compose_actions(self.minimax_prompt_text, self.segments,
                                                      [self._action_descriptions.get(segment.id, segment.prompt) for segment in self.segments])
        output = payload.get("output", {})
        self.output_width.setValue(int(output.get("width", 1280)))
        self.output_height.setValue(int(output.get("height", 704)))
        self.normalize_output_dimensions()
        view = payload.get("timelineView", {})
        self.timeline_height = max(184, min(430, int(view.get("height", self.timeline_height))))
        self.timeline_height_handle.current_height = self.timeline_height
        self.set_timeline_height(self.timeline_height)
        auto_fit = bool(view.get("autoFit", False))
        self.timeline_scale.setValue(0 if auto_fit else max(1, min(160, int(view.get("scale", self.pixels_per_second)))))
        self.timeline_fit_mode = auto_fit
        self._loading = False
        self.sync_minimax_panel()
        self.refresh_timeline()
        if auto_fit:
            self.apply_timeline_fit()
        self.project_dirty = False

    def export_directory(self) -> Path:
        fallback = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation) or str(Path.home())
        return Path(self.download_directory or str(self.settings.value("segment_export_dir", fallback) or fallback)).expanduser()

    def next_export_path(self, filename: str) -> Path:
        directory = self.export_directory()
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / safe_export_name(Path(filename).name)
        base, suffix = target.stem, target.suffix
        counter = 1
        while target.exists() or str(target) in self._reserved_exports:
            target = directory / f"{base} ({counter}){suffix}"
            counter += 1
        self._reserved_exports.add(str(target))
        self.statusBar().showMessage(f"Exporting {target.name}…")
        return target

    def record_export(self, path) -> None:
        path = Path(path)
        self._reserved_exports.discard(str(path))
        self.download_tray.add(path)
        self.downloads_button.setText("•")
        self.downloads_button.setToolTip(f"Export ready: {path.name}\nClick for recent exports; drag files from the tray.")
        self.download_tray.list.setCurrentRow(0)
        if getattr(self, "_download_feedback_animation", None):
            self._download_feedback_animation.stop()
        animation = QVariantAnimation(self)
        animation.setDuration(900)
        animation.setLoopCount(3)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        def pulse(value):
            alpha = round(70 + 130 * math.sin(value * math.pi))
            self.downloads_button.setStyleSheet(f"QPushButton {{background:rgba(59, 153, 115, {alpha}); border:1px solid #77d3a7; border-radius:6px; padding:5px 10px;}}")
        animation.valueChanged.connect(pulse)
        animation.finished.connect(lambda: self.downloads_button.setStyleSheet(""))
        self._download_feedback_animation = animation
        animation.start()
        if self.isVisible():
            QToolTip.showText(self.downloads_button.mapToGlobal(self.downloads_button.rect().bottomLeft()),
                             f"Export ready: {path.name}\nFind it in ↓ Recent exports", self.downloads_button, self.downloads_button.rect(), 3500)
        self.statusBar().showMessage(f"Exported: {path}")

    def export_failed(self, path, message: str) -> None:
        self._reserved_exports.discard(str(path))
        QMessageBox.critical(self, "Export failed", message)

    def open_download_folder(self) -> None:
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.export_directory())))

    def toggle_downloads(self) -> None:
        if self.download_tray.isVisible():
            self.download_tray.hide()
            return
        self.download_tray.refresh()
        position = self.downloads_button.mapToGlobal(self.downloads_button.rect().bottomRight())
        position.setX(position.x() - self.download_tray.width())
        screen = self.screen().availableGeometry()
        position.setX(max(screen.left(), min(position.x(), screen.right() - self.download_tray.width())))
        position.setY(min(position.y(), screen.bottom() - self.download_tray.height()))
        self.download_tray.move(position)
        self.download_tray.show()
        self.downloads_button.setText("")

    def export_project(self) -> None:
        if not self.segments:
            return
        path = str(self.next_export_path(f"{self.current_project_name}.LTXD"))
        payload = self.project_payload(include_media=False)
        serial = self._edit_serial
        project_id = self.current_project_id
        self.statusBar().showMessage(f"Saving project in background: {path}…")

        def saved(_result):
            if self.current_project_id == project_id and self._edit_serial == serial:
                self.project_dirty = False
            self.record_export(path)

        self.start_disk_job(save_project_archive, (path, payload, copy.deepcopy(self.segments)), saved,
                            lambda message: self.export_failed(path, message), serialized=True)

    def open_project(self, checked: bool = False, path: str | None = None) -> None:
        path = path or choose_document_open(self, "Open Project", self.settings.value("last_document_dir", str(Path.home())), "LTX Director - Director Project (*.LTXD *.ltxd)")
        if not path:
            return
        self.settings.setValue("last_document_dir", str(Path(path).parent))
        self.stage_current_workspace()
        self.cache_current_workspace()
        self._open_serial += 1
        request = self._open_serial
        self.statusBar().showMessage(f"Opening project in background: {Path(path).name}…")

        def opened(payload):
            if request != self._open_serial:
                return
            try:
                self.load_project_payload(payload)
                self.current_project_id = None
                self.current_project_name = Path(path).stem
                self.update_window_title()
                self.project_dirty = False
                self.mark_dirty()
                self.statusBar().showMessage(f"Opened: {self.current_project_name} · save to Library from toolbar or when closing")
            except Exception as error:
                self._loading = False
                QMessageBox.critical(self, "Open project failed", str(error))

        self.start_disk_job(read_project, (path,), opened,
                            lambda message: QMessageBox.critical(self, "Open project failed", message))
